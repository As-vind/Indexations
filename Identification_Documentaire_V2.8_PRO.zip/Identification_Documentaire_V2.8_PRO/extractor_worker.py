from __future__ import annotations
import argparse, json, re, subprocess, tempfile
from pathlib import Path
import fitz

OCR_MIN_CHARS=40
OCR_DPI=120

def useful(s:str)->int: return len(re.sub(r"\W+","",s or "",flags=re.UNICODE))

def page_count(path:Path)->int:
    with fitz.open(path) as d: return d.page_count

def extract(path:Path, page_idx:int)->dict:
    with fitz.open(path) as d:
        p=d.load_page(page_idx)
        try: text=p.get_text("text", sort=True) or ""
        except Exception: text=""
        if useful(text)>=OCR_MIN_CHARS:
            return {"text":text,"ocr":False}
        # Render only the current page. OCR runs as a separate native process.
        scale=OCR_DPI/72.0
        pix=p.get_pixmap(matrix=fitz.Matrix(scale,scale), colorspace=fitz.csGRAY, alpha=False)
        with tempfile.TemporaryDirectory(prefix="idxocr_") as td:
            img=Path(td)/"page.png"; pix.save(img); del pix
            cp=subprocess.run(["tesseract",str(img),"stdout","-l","fra+eng","--oem","1","--psm","6"],
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=75,check=False)
            ocr=cp.stdout or ""
        return {"text":ocr if useful(ocr)>useful(text) else text,"ocr":useful(ocr)>useful(text)}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("path"); ap.add_argument("--count",action="store_true"); ap.add_argument("--page",type=int)
    a=ap.parse_args(); p=Path(a.path)
    if a.count: print(json.dumps({"pages":page_count(p)})); return
    if a.page is None: raise SystemExit(2)
    print(json.dumps(extract(p,a.page),ensure_ascii=False))
if __name__=="__main__": main()
