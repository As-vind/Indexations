# Identification Documentaire V2.8 Pro — par Asvind

V2.8 privilégie l’indexation maximale pour des recherches quotidiennes rapides.

- Base produits structurée : désignation, référence, prix HT, finition, dimensions, coloris, éco/autre, texte brut, catalogue/page/ligne.
- Recherche prioritaire : référence exacte → préfixe (`COL7070` → variantes) → FTS produits → FTS lignes → fuzzy.
- E-mail client : extraction ponctuelle et résolution contre le référentiel fournisseur, sans pollution de la base permanente.
- Devis PDF : rapprochement contre la même base produits.
- Affichage recherche : Référence | Prix HT | Page | Ligne | Catalogue | PDF / Page.
- PDF/page reste cliquable et localisable.
- OCR local, reprise d’indexation, backup/restauration, purge client.
- Docker : 3 Go RAM / 4 CPU.

## Démarrage
```powershell
docker compose down
docker compose build --no-cache
docker compose up -d
```

Conserver le dossier `data` de V2.7 pour réutiliser l’index existant.
