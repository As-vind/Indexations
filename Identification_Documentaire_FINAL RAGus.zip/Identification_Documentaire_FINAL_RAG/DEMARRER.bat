@echo off
cd /d "%~dp0"
docker compose up -d --build
if errorlevel 1 (
  echo Erreur Docker. Verifiez que Docker Desktop est demarre.
  pause
  exit /b 1
)
timeout /t 3 /nobreak >nul
start "" "http://ID:1979"
