# Identification Documentaire — FINAL RAG

Application locale Docker/Streamlit pour indexer les catalogues fournisseurs, rechercher les références, dialoguer avec un assistant RAG local et transformer une demande client en Excel.

## Démarrage Windows

1. Conserver votre dossier `data` existant si vous mettez à jour une installation déjà indexée.
2. Lancer **`CONFIGURER_ID_WINDOWS.bat` une seule fois**. Windows demandera les droits administrateur afin d'ajouter le nom local `ID` dans le fichier hosts et de créer un raccourci sur le Bureau.
3. Vérifier que Docker Desktop est démarré.
4. Lancer **`DEMARRER.bat`**.
5. Ouvrir : **http://ID:1979**.

Pour arrêter les conteneurs : **`ARRETER.bat`**.

> Le premier démarrage d'Ollama peut être plus long car le modèle `qwen2.5:3b` est téléchargé automatiquement dans `data/ollama`.

## Mise à jour depuis la version précédente

Ne supprimez pas le dossier `data`. Il contient les catalogues, l'index SQLite, les sauvegardes et le modèle Ollama. La couche RAG FINAL se reconstruit à partir de l'index SQLite existant : elle ne relit pas tous les PDF lorsqu'une reconstruction RAG suffit.

## Fonctions FINAL

- Recherche structurée priorisant **Description → Gamme → Dimensions**, puis les attributs (plateau, panneau, chant, finition, coloris, options).
- Assistant RAG local qui distingue **nouvelle recherche** et **affinage conversationnel**.
- Le pool actif reste filtré : `affiche tout` ne réintroduit pas les résultats déjà éliminés.
- Contrôle de cohérence : une recherche `table` ne doit pas être remplie par des chauffeuses ou dessertes simplement parce qu'un attribut secondaire correspond.
- Réponses volumineuses présentées en tableau compact, avec sources PDF.
- Chat défilant avec zone de saisie séparée en bas.
- Demande client → références → Excel utilisant le **même moteur RAG** que Recherche et Assistant.
- Une ligne ambiguë est marquée **À confirmer** et n'est pas chiffrée automatiquement.
- Suppression complète du module **Rapprochement Devis PDF**.
- Thèmes **Clair** et **Bleu nuit**, mémorisés.
- Colonnes par défaut : **Description → Dimensions → Plateau → Panneau → Chant → GEN. LAFA → Référence → Prix HT → Éco → Options de gamme → Source**.
- Colonnes affichables/masquables et réordonnables, avec mémorisation et remise à zéro.
- Détection des nouveaux documents ou documents modifiés dans `data/catalogues` avec choix **Indexer / Plus tard / Ignorer**.
- Indexation incrémentale : les fichiers inchangés sont ignorés.
- Sauvegarde SQLite automatique quotidienne avec historique des 14 dernières sauvegardes automatiques.
- Bandeau d'état pendant indexation, sauvegarde et optimisation.
- SQLite/FTS5 optimisé (WAL, cache, mmap, index spécialisés, `ANALYZE`, `PRAGMA optimize`).

## Dossiers utiles

- `data/catalogues/` : documents fournisseurs à indexer.
- `data/backups/` : sauvegardes SQLite.
- `data/ollama/` : modèle IA local.
- `data/catalogue_fts.db` : base principale (créée automatiquement).

## Formats pris en charge

PDF, XLSX/XLSM, CSV, TXT et DOCX. L'OCR Tesseract FR/EN est inclus dans l'image Docker pour les pages PDF nécessitant un fallback OCR.

## Sauvegardes

La sauvegarde quotidienne utilise l'API de backup SQLite et vérifie l'intégrité de la copie. Une sauvegarde ne démarre pas automatiquement pendant une autre opération longue signalée comme active. Les sauvegardes automatiques les plus anciennes sont supprimées au-delà des 14 dernières.

## Réindexation

- Modification du moteur RAG ou des préférences : **pas de réindexation complète des PDF**.
- Nouveau catalogue ou catalogue modifié : indexation du document concerné, puis mise à jour de la projection RAG.
- Le bouton **Optimiser l’index IA** reconstruit uniquement la couche RAG depuis SQLite.
