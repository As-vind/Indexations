from __future__ import annotations

import gc
import io
from io import BytesIO
import json
import urllib.request
import urllib.error
import os
import re
import sqlite3
import shutil
import subprocess
import sys
import threading
from urllib.parse import quote
import time
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
import streamlit as st
from openpyxl.styles import Font, PatternFill
import fitz
from rapidfuzz import fuzz, process

APP_DIR = Path(os.getenv("APP_DIR", str(Path(__file__).resolve().parent))).resolve()
DATA_DIR = Path(os.getenv("DATA_DIR", str(APP_DIR / "data"))).resolve()
CATALOGUE_DIR = DATA_DIR / "catalogues"
DB_PATH = DATA_DIR / "catalogue_fts.db"
BACKUP_DIR = DATA_DIR / "backups"
APP_VERSION = 'FINAL'
INDEX_VERSION = 32
OCR_MIN_CHARS = 40
OCR_DPI = 120
PAGE_TIMEOUT = 100
COUNT_TIMEOUT = 30

SEARCH_LIMIT = 500
FUZZY_CANDIDATE_LIMIT = 20_000
FUZZY_RESULT_LIMIT = 250
COMMIT_EVERY_PAGES = 10
MIN_FUZZY_SCORE = 75

PRICE_RE = re.compile(r"(?<!\d)(\d{1,6}(?:[ .]\d{3})*(?:[,.]\d{2})?)\s*(?:€|EUR|euros?|HT|TTC)\b", re.I)
BARE_PRICE_RE = re.compile(r"(?<![\w/.-])(\d{1,5}(?:[ .]\d{3})*[,.]\d{2})(?!\d)")
REF_RE = re.compile(r"\b(?=[A-Z0-9._/-]{4,}\b)(?=[A-Z0-9._/-]*\d)[A-Z0-9][A-Z0-9._/-]{2,}[A-Z0-9]\b", re.I)
QTY_RE = re.compile(r"(?<!\w)(\d{1,4})\s*(?:x|×|pcs?\.?|pi[eè]ces?|unit[eé]s?)?\b", re.I)
STOPWORDS = {
    "bonjour", "bonsoir", "merci", "cordialement", "svp", "besoin", "faudrait", "voudrais", "souhaite",
    "nous", "vous", "avec", "pour", "dans", "des", "les", "une", "un", "du", "de", "la", "le", "et",
    "ainsi", "que", "est", "sont", "client", "demande", "prix", "quantite", "quantité", "article", "articles",
}

st.set_page_config(page_title="Identification documentaire", page_icon="🔎", layout="wide")


def ensure_dirs() -> None:
    # /app/data is a Docker bind mount. Create the mount root first, then all children.
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CATALOGUE_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    # Fail early with an explicit message instead of sqlite3 "unable to open database file".
    probe = DATA_DIR / ".write_test"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
    except Exception as exc:
        raise RuntimeError(
            f"Le dossier {DATA_DIR} n'est pas accessible en écriture par le conteneur. "
            "V3.0.1 doit être lancé avec les droits prévus dans docker-compose.yml."
        ) from exc


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower().replace("’", "'")
    return re.sub(r"\s+", " ", text).strip()


def clean_line(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").replace("\x00", " ")).strip()


def _price_value(raw: str) -> float | None:
    raw = raw.replace(" ", "").replace(",", ".")
    try:
        value = float(raw)
        return value if 0.01 <= value <= 999999 else None
    except ValueError:
        return None

def detect_price(text: str, allow_bare: bool = True) -> float | None:
    """Detect supplier prices, including decimal price columns without € / HT / TTC."""
    text = clean_line(text)
    explicit = PRICE_RE.findall(text)
    if explicit:
        return _price_value(explicit[-1])
    if not allow_bare:
        return None
    # Most furniture price lists use 2 decimal digits even when the currency symbol is absent.
    # Reject obvious dimension/ratio/date contexts and reference-like tokens.
    candidates = []
    for m in BARE_PRICE_RE.finditer(text):
        left = text[max(0, m.start()-5):m.start()].lower()
        right = text[m.end():m.end()+5].lower()
        if re.search(r"[x×/]\s*$", left) or re.match(r"^\s*[x×/]", right):
            continue
        v = _price_value(m.group(1))
        if v is not None:
            candidates.append(v)
    return candidates[-1] if candidates else None


def detect_reference(text: str) -> str | None:
    refs = REF_RE.findall(text or "")
    if not refs:
        return None
    refs.sort(key=len, reverse=True)
    return refs[0][:128]


PRODUCT_MONEY_RE = re.compile(r"(?<![A-Za-z0-9])(\d{1,6}(?:[ .]\d{3})*[,.]\d{2})\s*(?:€|EUR)", re.I)
PRODUCT_DIM_RE = re.compile(r"\b\d{2,4}\s*[x×X]\s*\d{2,4}(?:\s*[x×X]\s*\d{2,4})?\b", re.I)
PRODUCT_RAL_RE = re.compile(r"\bRAL\s*\d{4}(?:[-/]\d{2,4})?\b", re.I)
# Supplier refs such as COL2684-T0E. RAL codes are explicitly excluded later.
PRODUCT_REF_RE = re.compile(r"\b(?=[A-Z0-9_-]{5,}\b)(?=[A-Z0-9_-]*[A-Z])(?=[A-Z0-9_-]*\d)[A-Z]{2,}[A-Z0-9]*(?:[-_][A-Z0-9]+)*\b", re.I)

def parse_product_line(raw: str) -> dict | None:
    """Parse ONE commercial row only. A price is verified only when ref+price are on this same row."""
    text=clean_line(raw)
    if not text: return None
    money=list(PRODUCT_MONEY_RE.finditer(text))
    refs=[m for m in PRODUCT_REF_RE.finditer(text) if not m.group(0).upper().startswith('RAL')]
    if not refs and not money: return None
    refm=refs[-1] if refs else None
    dim=PRODUCT_DIM_RE.search(text)
    rals=PRODUCT_RAL_RE.findall(text)
    def val(m): return _price_value(m.group(1)) if m else None
    prix=val(money[0]) if money else None
    eco=val(money[1]) if len(money)>1 else None
    cut=min([m.start() for m in (dim,refm,money[0] if money else None) if m] or [len(text)])
    designation=text[:cut].strip(' -;|') or None
    between=''
    if refm:
        start=dim.end() if dim and dim.end() < refm.start() else cut
        between=text[start:refm.start()].strip(' -;|')
    tokens=between.split()
    gen_lafa=None; plateau=None; panneau=None; chant=None; finition=None
    # Supplier rows normally finish with GEN.LAFA immediately before REF.
    if tokens:
        if re.fullmatch(r'(?i)[A-Z]{2,6}\d{2,6}[A-Z0-9]*',tokens[-1]):
            gen_lafa=tokens.pop()
        # Recognise common commercial columns without inventing values.
        for tok in list(tokens):
            if re.fullmatch(r'(?i)\d{1,3}\s*mm',tok): panneau=tok; tokens.remove(tok); break
        for tok in list(tokens):
            if normalize(tok) in {'abs','hnv','surmoule','surmoulé','htv'}: chant=tok; tokens.remove(tok); break
        for tok in list(tokens):
            if normalize(tok) in {'melamine','mélaminé','stratifie','stratifié','bois','compact'}: plateau=tok; tokens.remove(tok); break
        finition=' '.join(tokens).strip() or None
    verified_price=bool(refm and prix is not None and refm.start() < money[0].start())
    confidence=(40 if refm else 0)+(35 if verified_price else 0)+(10 if designation else 0)+(10 if dim else 0)+(5 if gen_lafa else 0)
    return {'designation':designation,'dimensions':dim.group(0).replace('×','x') if dim else None,
            'plateau':plateau,'panneau':panneau,'chant':chant,'gen_lafa':gen_lafa,'finition':finition,
            'reference':refm.group(0) if refm else None,'prix_ht':prix if verified_price else None,
            'eco_autre':eco if verified_price else None,'price_verified':verified_price,
            'coloris':' '.join(rals) or None,'raw_text':text,'confidence':confidence}

def ensure_products_schema(conn):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY, line_id INTEGER NOT NULL UNIQUE REFERENCES lines(id) ON DELETE CASCADE,
      catalogue_id INTEGER NOT NULL REFERENCES catalogues(id) ON DELETE CASCADE,
      page INTEGER NOT NULL,line_no INTEGER NOT NULL,designation TEXT,dimensions TEXT,finition TEXT,
      reference TEXT,prix_ht REAL,eco_autre REAL,coloris TEXT,raw_text TEXT NOT NULL,confidence INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_products_ref ON products(reference);
    CREATE INDEX IF NOT EXISTS idx_products_cat ON products(catalogue_id,page,line_no);
    CREATE INDEX IF NOT EXISTS idx_products_price ON products(prix_ht);
    CREATE INDEX IF NOT EXISTS idx_products_designation ON products(designation COLLATE NOCASE);
    CREATE INDEX IF NOT EXISTS idx_products_finition ON products(finition COLLATE NOCASE);
    CREATE VIRTUAL TABLE IF NOT EXISTS products_fts USING fts5(designation,dimensions,finition,reference,coloris,raw_text,
      content='products',content_rowid='id',tokenize='unicode61 remove_diacritics 2');
    CREATE TRIGGER IF NOT EXISTS products_ai AFTER INSERT ON products BEGIN
      INSERT INTO products_fts(rowid,designation,dimensions,finition,reference,coloris,raw_text)
      VALUES(new.id,coalesce(new.designation,''),coalesce(new.dimensions,''),coalesce(new.finition,''),coalesce(new.reference,''),coalesce(new.coloris,''),new.raw_text);
    END;
    CREATE TRIGGER IF NOT EXISTS products_ad AFTER DELETE ON products BEGIN
      INSERT INTO products_fts(products_fts,rowid,designation,dimensions,finition,reference,coloris,raw_text)
      VALUES('delete',old.id,coalesce(old.designation,''),coalesce(old.dimensions,''),coalesce(old.finition,''),coalesce(old.reference,''),coalesce(old.coloris,''),old.raw_text);
    END;
    """)

def rebuild_products(catalogue_id: int | None=None) -> int:
    """Build structured commercial rows from already extracted raw lines; no PDF reread."""
    n=0
    with db() as conn:
        ensure_products_schema(conn)
        if catalogue_id is None: conn.execute('DELETE FROM products')
        else: conn.execute('DELETE FROM products WHERE catalogue_id=?',(catalogue_id,))
        sql='SELECT id,catalogue_id,page,line_no,text FROM lines' + (' WHERE catalogue_id=?' if catalogue_id is not None else '') + ' ORDER BY id'
        rows=conn.execute(sql,(catalogue_id,) if catalogue_id is not None else ()).fetchall()
        for r in rows:
            x=parse_product_line(r['text'])
            if not x: continue
            conn.execute("INSERT OR REPLACE INTO products(line_id,catalogue_id,page,line_no,designation,dimensions,finition,reference,prix_ht,eco_autre,coloris,raw_text,confidence) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(r['id'],r['catalogue_id'],r['page'],r['line_no'],x['designation'],x['dimensions'],x['finition'],x['reference'],x['prix_ht'],x['eco_autre'],x['coloris'],x['raw_text'],x['confidence']))
            n+=1
            if n%1000==0: conn.commit()
        conn.commit()
        conn.execute("INSERT INTO products_fts(products_fts) VALUES('rebuild')"); conn.commit()
    return n

def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH, timeout=60)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=FILE")
    conn.execute("PRAGMA cache_size=-65536")  # ~64 MiB: fast while remaining lightweight
    conn.execute("PRAGMA mmap_size=134217728") # 128 MiB memory map, bounded well below the app budget
    conn.execute("PRAGMA busy_timeout=60000")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()


def init_db() -> None:
    ensure_dirs()
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS catalogues (
            id INTEGER PRIMARY KEY,
            path TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            mtime_ns INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            indexed_pages INTEGER NOT NULL DEFAULT 0,
            total_pages INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            error TEXT
        );
        CREATE TABLE IF NOT EXISTS lines (
            id INTEGER PRIMARY KEY,
            catalogue_id INTEGER NOT NULL REFERENCES catalogues(id) ON DELETE CASCADE,
            page INTEGER NOT NULL,
            line_no INTEGER NOT NULL,
            text TEXT NOT NULL,
            norm_text TEXT NOT NULL,
            reference TEXT,
            price REAL
        );
        CREATE TABLE IF NOT EXISTS index_errors (
            id INTEGER PRIMARY KEY,
            catalogue_id INTEGER REFERENCES catalogues(id) ON DELETE CASCADE,
            page INTEGER, error TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_lines_catalogue ON lines(catalogue_id, page, line_no);
        CREATE INDEX IF NOT EXISTS idx_lines_reference ON lines(reference);
        CREATE VIRTUAL TABLE IF NOT EXISTS lines_fts USING fts5(
            text, norm_text, reference,
            content='lines', content_rowid='id',
            tokenize='unicode61 remove_diacritics 2'
        );
        CREATE TRIGGER IF NOT EXISTS lines_ai AFTER INSERT ON lines BEGIN
            INSERT INTO lines_fts(rowid,text,norm_text,reference)
            VALUES (new.id,new.text,new.norm_text,coalesce(new.reference,''));
        END;
        CREATE TRIGGER IF NOT EXISTS lines_ad AFTER DELETE ON lines BEGIN
            INSERT INTO lines_fts(lines_fts,rowid,text,norm_text,reference)
            VALUES('delete',old.id,old.text,old.norm_text,coalesce(old.reference,''));
        END;
        CREATE TRIGGER IF NOT EXISTS lines_au AFTER UPDATE ON lines BEGIN
            INSERT INTO lines_fts(lines_fts,rowid,text,norm_text,reference)
            VALUES('delete',old.id,old.text,old.norm_text,coalesce(old.reference,''));
            INSERT INTO lines_fts(rowid,text,norm_text,reference)
            VALUES (new.id,new.text,new.norm_text,coalesce(new.reference,''));
        END;
        """)
        cols = {r[1] for r in conn.execute("PRAGMA table_info(catalogues)")}
        if "index_version" not in cols:
            conn.execute("ALTER TABLE catalogues ADD COLUMN index_version INTEGER NOT NULL DEFAULT 0")
        if "ocr_pages" not in cols:
            conn.execute("ALTER TABLE catalogues ADD COLUMN ocr_pages INTEGER NOT NULL DEFAULT 0")
        ensure_products_schema(conn)
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS product_blocks(
          id INTEGER PRIMARY KEY, catalogue_id INTEGER NOT NULL, page INTEGER NOT NULL,
          anchor_line INTEGER NOT NULL, text TEXT NOT NULL, norm_text TEXT NOT NULL,
          reference TEXT, designation TEXT, dimensions TEXT, prix_ht REAL, eco_autre REAL,
          UNIQUE(catalogue_id,page,anchor_line)
        );
        CREATE INDEX IF NOT EXISTS idx_blocks_ref ON product_blocks(reference);
        CREATE INDEX IF NOT EXISTS idx_blocks_page ON product_blocks(catalogue_id,page,anchor_line);
        CREATE VIRTUAL TABLE IF NOT EXISTS product_blocks_fts USING fts5(
          text,norm_text,reference,designation,dimensions,content='product_blocks',content_rowid='id',
          tokenize='unicode61 remove_diacritics 2'
        );
        CREATE TRIGGER IF NOT EXISTS blocks_ai AFTER INSERT ON product_blocks BEGIN
          INSERT INTO product_blocks_fts(rowid,text,norm_text,reference,designation,dimensions)
          VALUES(new.id,new.text,new.norm_text,coalesce(new.reference,''),coalesce(new.designation,''),coalesce(new.dimensions,''));
        END;
        CREATE TRIGGER IF NOT EXISTS blocks_ad AFTER DELETE ON product_blocks BEGIN
          INSERT INTO product_blocks_fts(product_blocks_fts,rowid,text,norm_text,reference,designation,dimensions)
          VALUES('delete',old.id,old.text,old.norm_text,coalesce(old.reference,''),coalesce(old.designation,''),coalesce(old.dimensions,''));
        END;
        CREATE TABLE IF NOT EXISTS assistant_memory(
          query_key TEXT NOT NULL, reference TEXT NOT NULL, designation TEXT, hits INTEGER NOT NULL DEFAULT 1,
          last_used TEXT NOT NULL, PRIMARY KEY(query_key,reference)
        );
        CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY,value TEXT);
        """)
        conn.commit()


SUPPORTED_CATALOGUE_EXTENSIONS = {".pdf", ".xlsx", ".xlsm", ".csv", ".txt", ".docx"}

def source_files(folder: Path) -> list[Path]:
    """V12: source fournisseur récursive PDF + Office/texte."""
    return sorted(
        (p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_CATALOGUE_EXTENSIONS),
        key=lambda p: str(p.relative_to(folder)).lower()
    )

def pdf_files(folder: Path) -> list[Path]:
    return source_files(folder)


def catalogue_signature(path: Path) -> tuple[int, int]:
    s = path.stat()
    return s.st_size, s.st_mtime_ns


def _worker(args: list[str], timeout: int) -> dict:
    cmd = [sys.executable, str(APP_DIR / "extractor_worker.py"), *args]
    cp = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, check=False)
    if cp.returncode != 0:
        raise RuntimeError((cp.stderr or f"worker rc={cp.returncode}")[-1500:])
    import json
    return json.loads(cp.stdout)


def worker_page_count(path: Path) -> int:
    return int(_worker([str(path), "--count"], COUNT_TIMEOUT)["pages"])


def worker_extract_page(path: Path, page_idx: int) -> tuple[str, bool]:
    r = _worker([str(path), "--page", str(page_idx)], PAGE_TIMEOUT)
    return str(r.get("text") or ""), bool(r.get("ocr"))


def page_rows_with_context(text: str, cat_id: int, page_no: int):
    """Index raw extracted lines without borrowing prices from neighbouring rows.

    V12.3 rule: a price stored on a raw line must physically exist on that line.
    Split-table reconstruction is handled later by product_blocks, where reference
    boundaries prevent a price from leaking to another product.
    """
    lines = [(i, clean_line(x)) for i, x in enumerate(text.splitlines(), 1)]
    lines = [(i, x) for i, x in lines if len(x) >= 2]
    return [(cat_id, page_no, line_no, line, normalize(line), detect_reference(line), detect_price(line))
            for line_no, line in lines]

def index_catalogue(path: Path, progress=None, status=None) -> tuple[int, int]:
    size, mtime = catalogue_signature(path)
    with db() as conn:
        old = conn.execute("SELECT * FROM catalogues WHERE path=?", (str(path),)).fetchone()
        same = bool(old and old["size_bytes"] == size and old["mtime_ns"] == mtime and old["index_version"] == INDEX_VERSION)
        if same and str(old["status"]).startswith("ready"):
            return old["indexed_pages"], old["total_pages"]
        if old:
            cat_id = old["id"]
            if same:
                # Resume exactly after the last committed page; never destroy completed work after a crash.
                resume = int(old["indexed_pages"] or 0)
                conn.execute("UPDATE catalogues SET status='indexing',updated_at=?,error=NULL WHERE id=?", (utcnow(), cat_id))
            else:
                resume = 0
                conn.execute("DELETE FROM lines WHERE catalogue_id=?", (cat_id,))
                conn.execute("UPDATE catalogues SET name=?,size_bytes=?,mtime_ns=?,status='indexing',indexed_pages=0,total_pages=0,ocr_pages=0,index_version=?,updated_at=?,error=NULL WHERE id=?",
                             (path.name,size,mtime,INDEX_VERSION,utcnow(),cat_id))
        else:
            resume = 0
            cur=conn.execute("INSERT INTO catalogues(path,name,size_bytes,mtime_ns,status,index_version,updated_at) VALUES(?,?,?,?,?,?,?)",
                             (str(path),path.name,size,mtime,"indexing",INDEX_VERSION,utcnow()))
            cat_id=cur.lastrowid
        conn.commit()

    try:
        total = worker_page_count(path)
    except Exception as exc:
        with db() as conn:
            conn.execute("UPDATE catalogues SET status='error',updated_at=?,error=? WHERE id=?",(utcnow(),f"Ouverture document: {exc}"[:2000],cat_id)); conn.commit()
        return 0, 0

    with db() as conn:
        conn.execute("UPDATE catalogues SET total_pages=?,updated_at=? WHERE id=?",(total,utcnow(),cat_id)); conn.commit()
    errors=0
    with db() as conn:
        row=conn.execute("SELECT ocr_pages FROM catalogues WHERE id=?",(cat_id,)).fetchone(); ocr_count=int(row[0] or 0)
    for page_idx in range(min(resume,total), total):
        page_no=page_idx+1
        try:
            text, used_ocr = worker_extract_page(path,page_idx)
            rows=page_rows_with_context(text,cat_id,page_no)
            with db() as conn:
                # A page is atomic. If killed here, it is safely replayed on next run.
                conn.execute("DELETE FROM lines WHERE catalogue_id=? AND page=?",(cat_id,page_no))
                if rows: conn.executemany("INSERT INTO lines(catalogue_id,page,line_no,text,norm_text,reference,price) VALUES(?,?,?,?,?,?,?)",rows)
                if used_ocr: ocr_count += 1
                conn.execute("UPDATE catalogues SET indexed_pages=?,ocr_pages=?,updated_at=? WHERE id=?",(page_no,ocr_count,utcnow(),cat_id)); conn.commit()
        except subprocess.TimeoutExpired:
            errors += 1
            with db() as conn:
                conn.execute("INSERT INTO index_errors(catalogue_id,page,error,created_at) VALUES(?,?,?,?)",(cat_id,page_no,"Timeout extraction/OCR",utcnow()))
                conn.execute("UPDATE catalogues SET indexed_pages=?,updated_at=? WHERE id=?",(page_no,utcnow(),cat_id)); conn.commit()
        except Exception as exc:
            errors += 1
            with db() as conn:
                conn.execute("INSERT INTO index_errors(catalogue_id,page,error,created_at) VALUES(?,?,?,?)",(cat_id,page_no,str(exc)[:2000],utcnow()))
                conn.execute("UPDATE catalogues SET indexed_pages=?,updated_at=? WHERE id=?",(page_no,utcnow(),cat_id)); conn.commit()
        if progress: progress.progress(page_no/max(total,1), text=f"{path.name} — page {page_no}/{total}" + (f" — {errors} erreur(s)" if errors else ""))
        if page_idx % 10 == 0: gc.collect()
    final_status="ready_with_errors" if errors else "ready"
    with db() as conn:
        conn.execute("UPDATE catalogues SET status=?,updated_at=?,error=? WHERE id=?",(final_status,utcnow(),f"{errors} page(s) ignorée(s)" if errors else None,cat_id)); conn.commit()
    rebuild_products(cat_id)
    return total,total


def update_index() -> dict[str,int]:
    files=source_files(CATALOGUE_DIR); seen={str(p) for p in files}
    stats={"indexed":0,"unchanged":0,"removed":0,"errors":0}
    with db() as conn:
        for row in conn.execute("SELECT id,path FROM catalogues").fetchall():
            if row["path"] not in seen: conn.execute("DELETE FROM catalogues WHERE id=?",(row["id"],)); stats["removed"]+=1
        conn.commit()
    outer=st.progress(0,text="Préparation de l'indexation"); status=st.empty()
    for i,path in enumerate(files):
        size,mtime=catalogue_signature(path)
        with db() as conn: old=conn.execute("SELECT size_bytes,mtime_ns,status,index_version FROM catalogues WHERE path=?",(str(path),)).fetchone()
        if old and old["size_bytes"]==size and old["mtime_ns"]==mtime and str(old["status"]).startswith("ready") and old["index_version"]==INDEX_VERSION:
            stats["unchanged"]+=1
        else:
            status.info(f"Document {i+1}/{len(files)} : {path.name}")
            pp=st.progress(0,text=path.name)
            try:
                before=0
                with db() as conn:
                    r=conn.execute("SELECT indexed_pages FROM catalogues WHERE path=?",(str(path),)).fetchone(); before=int(r[0] or 0) if r else 0
                index_catalogue(path,pp,status); stats["indexed"]+=1
            except Exception as exc:
                # Never abort the global corpus because of one supplier PDF.
                stats["errors"]+=1; status.warning(f"Ignoré : {path.name} — {exc}")
            pp.empty()
        outer.progress((i+1)/max(len(files),1),text=f"Documents {i+1}/{len(files)} — indexation résiliente")
    outer.empty(); return stats


def fts_query(q: str) -> str:
    tokens = re.findall(r"[\w.-]+", normalize(q), flags=re.UNICODE)
    tokens = [t.replace('"', '') for t in tokens if t]
    return " AND ".join(f'"{t}"*' for t in tokens[:12])


def catalogue_options() -> list[str]:
    with db() as conn:
        return [r[0] for r in conn.execute("SELECT name FROM catalogues WHERE status LIKE 'ready%' ORDER BY name COLLATE NOCASE")]


ADMIN_PAGE_WORDS=("conditions generales de vente","conditions générales de vente","cgv","mentions legales","mentions légales","conditions de livraison","modalites de paiement","modalités de paiement")
PREFACE_PAGE_WORDS=("sommaire","table des matieres","table des matières","edito","édito","qui sommes nous","qui sommes-nous","notre histoire")

def ensure_page_meta(conn):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS page_meta(catalogue_id INTEGER NOT NULL,page INTEGER NOT NULL,page_type TEXT NOT NULL DEFAULT 'UNKNOWN',product_score INTEGER NOT NULL DEFAULT 0,searchable_product INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(catalogue_id,page));
    CREATE INDEX IF NOT EXISTS idx_page_meta_search ON page_meta(searchable_product,page_type);
    """)
    if conn.execute("SELECT count(*) FROM page_meta").fetchone()[0]: return
    pages=conn.execute("SELECT catalogue_id,page,group_concat(text,' ') txt FROM lines GROUP BY catalogue_id,page").fetchall()
    for r in pages:
        txt=r["txt"] or ""; nt=normalize(txt)
        refs=len(re.findall(r"\b[A-Z]{2,}[A-Z0-9]*(?:[-_][A-Z0-9]+)*\d[A-Z0-9_-]*\b",txt.upper()))
        euros=len(re.findall(r"\d+[,.]\d{2}\s*€",txt)); dims=len(re.findall(r"\b\d{2,4}\s*[x×X]\s*\d{2,4}",txt))
        headers=sum(1 for w in ("description","dimensions","ref","prix","eco") if w in nt); score=min(100,refs*8+euros*10+dims*7+headers*6)
        admin=any(normalize(w) in nt for w in ADMIN_PAGE_WORDS); preface=any(normalize(w) in nt for w in PREFACE_PAGE_WORDS) and score<35
        if admin and score<45: typ,ok="CGV",0
        elif preface: typ,ok="PREFACE",0
        elif score>=25: typ,ok="PRODUIT",1
        elif len(nt)<60: typ,ok="VIDE",0
        else: typ,ok="AUTRE",0
        conn.execute("INSERT OR REPLACE INTO page_meta VALUES(?,?,?,?,?)",(r["catalogue_id"],r["page"],typ,score,ok))
    conn.commit()

def repair_commercial_values_v6(conn):
    ensure_products_schema(conn)
    rows=conn.execute("SELECT id,catalogue_id,page,line_no,text FROM lines WHERE text IS NOT NULL AND trim(text)<>''").fetchall()
    fixed=0
    for r in rows:
        p=parse_product_line(r["text"])
        if not p or not p.get("reference"):
            continue
        conn.execute("""INSERT INTO products(line_id,catalogue_id,page,line_no,designation,dimensions,finition,
                         reference,prix_ht,eco_autre,coloris,raw_text,confidence)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(line_id) DO UPDATE SET
                          designation=excluded.designation,dimensions=excluded.dimensions,finition=excluded.finition,
                          reference=excluded.reference,prix_ht=excluded.prix_ht,eco_autre=excluded.eco_autre,
                          coloris=excluded.coloris,raw_text=excluded.raw_text,confidence=excluded.confidence""",
                     (r["id"],r["catalogue_id"],r["page"],r["line_no"],p.get("designation"),p.get("dimensions"),
                      p.get("finition"),p.get("reference"),p.get("prix_ht"),p.get("eco_autre"),p.get("coloris"),
                      p.get("raw_text"),p.get("confidence",0)))
        fixed+=1
    conn.commit()
    return fixed


def commercial_fields_from_row(raw):
    """V5 safety gate: never attach a price from a neighbouring product block."""
    p=parse_product_line(str(raw or '')) or {}
    return p if p.get('price_verified') else p

def enrich_product_result(row):
    d=dict(row); raw=str(d.get("_hit") or d.get("Référence / Libellé exact") or "")
    p=commercial_fields_from_row(raw)
    mapping={"Description":"designation","Dimensions":"dimensions","Plateau":"plateau","Panneau":"panneau","Chant":"chant",
             "GEN. LAFA":"gen_lafa","Référence":"reference","Prix HT":"prix_ht","Éco":"eco_autre",
             "Désignation":"designation","Éco./Autre":"eco_autre","Coloris":"coloris"}
    # V6: exact raw commercial row overrides any legacy structured value.
    for col,key in mapping.items():
        if p.get(key) is not None:
            d[col]=p.get(key)
    if raw and not p.get('price_verified'):
        d['Prix HT']=None; d['Éco']=None; d['Éco./Autre']=None
    d['_price_verified']=bool(p.get('price_verified'))
    return d

def enrich_results(df):
    if df is None or df.empty: return df
    return pd.DataFrame([enrich_product_result(r) for _,r in df.iterrows()])

def is_product_result(row):
    cat=normalize(str(row.get("Catalogue","") or ""))
    raw=normalize(str(row.get("_hit",row.get("Référence / Libellé exact","")) or ""))
    if any(x in cat for x in ("conditions generales","conditions de vente","cgv")):
        return False
    if any(normalize(w) in raw for w in ADMIN_PAGE_WORDS):
        return False
    return True

def is_reliable_commercial_result(row):
    """V12.3: a commercial hit shown to Search/IA must carry a real ref + verified price.

    This removes index noise such as THEOREME-2 / export helper rows / prefaces.
    Exact catalogue facts remain in SQLite, but are not presented as products.
    """
    ref=row.get("Référence")
    price=row.get("Prix HT")
    try:
        has_price=price is not None and not pd.isna(price) and float(price) >= 0
    except Exception:
        has_price=False
    has_ref=ref is not None and not pd.isna(ref) and len(str(ref).strip()) >= 4
    if not (has_ref and has_price):
        return False
    r=str(ref).strip().upper()
    # Reject obvious family/title pseudo-references created by generic parsing.
    if re.fullmatch(r"(?:THEOREME|NORMA|LITH|SIAM|SAX|ARTENSE|MATERNELLE)(?:[-_ ]?\d+)?", r, re.I):
        return False
    return is_product_result(row)

def search_products_fast(query: str, catalogue: str | None = None, limit: int = SEARCH_LIMIT) -> pd.DataFrame:
    """Fast structured search: exact/prefix reference first, then product FTS. No PDF I/O."""
    q=(query or '').strip()
    if not q: return pd.DataFrame()
    nq=re.sub(r'[^A-Z0-9]','',q.upper())
    cat_sql=' AND c.name=?' if catalogue else ''
    params=[]
    # Reference exact/prefix is the highest priority path (COL7070 -> all COL7070-* variants).
    with db() as conn:
        ensure_products_schema(conn)
        sql=f"""SELECT p.reference "Référence",p.prix_ht "Prix HT",p.page "Page",p.line_no "Ligne",c.name "Catalogue",p.raw_text "_hit",
                       CASE WHEN replace(replace(upper(p.reference),'-',''),' ','')=? THEN 100
                            WHEN replace(replace(upper(p.reference),'-',''),' ','') LIKE ? THEN 95 ELSE 80 END "_score"
                FROM products p JOIN catalogues c ON c.id=p.catalogue_id
                WHERE p.reference IS NOT NULL AND p.prix_ht IS NOT NULL AND (replace(replace(upper(p.reference),'-',''),' ','')=? OR replace(replace(upper(p.reference),'-',''),' ','') LIKE ?) {cat_sql}
                ORDER BY _score DESC,p.reference LIMIT ?"""
        vals=[nq,nq+'%',nq,nq+'%']+([catalogue] if catalogue else [])+[limit]
        df=pd.read_sql_query(sql,conn,params=vals)
        if not df.empty: return enrich_results(df)
        # Product FTS keeps designation/finish/dimensions/color/color codes searchable.
        fq=fts_query(q)
        if fq:
            sql=f"""SELECT p.reference "Référence",p.prix_ht "Prix HT",p.page "Page",p.line_no "Ligne",c.name "Catalogue",p.raw_text "_hit",
                           round(-bm25(products_fts),3) "_score"
                    FROM products_fts JOIN products p ON p.id=products_fts.rowid JOIN catalogues c ON c.id=p.catalogue_id
                    WHERE products_fts MATCH ? AND p.reference IS NOT NULL AND p.prix_ht IS NOT NULL {cat_sql}
                    ORDER BY bm25(products_fts) LIMIT ?"""
            vals=[fq]+([catalogue] if catalogue else [])+[limit]
            return enrich_results(pd.read_sql_query(sql,conn,params=vals))
    return pd.DataFrame()

def search_fts(query: str, catalogue: str | None = None, limit: int = SEARCH_LIMIT) -> pd.DataFrame:
    where_cat = " AND c.name=?" if catalogue else ""
    params: list[object] = []
    if query.strip():
        match = fts_query(query)
        if not match:
            return pd.DataFrame()
        sql = f"""
        SELECT c.name Catalogue,l.page Page,l.line_no Ligne,p.designation "Désignation",p.dimensions "Dimensions",p.finition "Finition",
               coalesce(p.reference,l.reference) "Référence",p.prix_ht "Prix HT",p.eco_autre "Éco./Autre",p.coloris "Coloris",
               l.text "Référence / Libellé exact", round(-bm25(lines_fts),3) "Score & Correspondance"
        FROM lines_fts JOIN lines l ON l.id=lines_fts.rowid JOIN catalogues c ON c.id=l.catalogue_id LEFT JOIN products p ON p.line_id=l.id
        WHERE lines_fts MATCH ? {where_cat}
        ORDER BY bm25(lines_fts) LIMIT ?
        """
        params.append(match)
    else:
        sql = f"""
        SELECT c.name Catalogue,l.page Page,l.line_no Ligne,p.designation "Désignation",p.dimensions "Dimensions",p.finition "Finition",
               coalesce(p.reference,l.reference) "Référence",p.prix_ht "Prix HT",p.eco_autre "Éco./Autre",p.coloris "Coloris",
               l.text "Référence / Libellé exact", 'listing' "Score & Correspondance"
        FROM lines l JOIN catalogues c ON c.id=l.catalogue_id LEFT JOIN products p ON p.line_id=l.id
        WHERE c.status LIKE 'ready%' {where_cat}
        ORDER BY c.name,l.page,l.line_no LIMIT ?
        """
    if catalogue:
        params.append(catalogue)
    params.append(limit)
    with db() as conn:
        return pd.read_sql_query(sql, conn, params=params)


def fuzzy_search(query: str, catalogue: str | None = None, limit: int = FUZZY_RESULT_LIMIT) -> pd.DataFrame:
    qn = normalize(query)
    if not qn:
        return pd.DataFrame()
    # Bound candidate set: prefix/LIKE terms first; only if empty use a capped sequential sample.
    terms = [t for t in re.findall(r"\w+", qn) if len(t) >= 3][:5]
    clauses, params = [], []
    for t in terms:
        clauses.append("l.norm_text LIKE ?")
        params.append(f"%{t[:max(3, len(t)-2)]}%")
    cat_clause = " AND c.name=?" if catalogue else ""
    if catalogue:
        params.append(catalogue)
    where = " OR ".join(clauses) if clauses else "1=1"
    sql = f"""
        SELECT l.id,c.name,l.page,l.line_no,l.price,l.text,l.norm_text
        FROM lines l JOIN catalogues c ON c.id=l.catalogue_id
        WHERE c.status LIKE 'ready%' AND ({where}) {cat_clause}
        LIMIT {FUZZY_CANDIDATE_LIMIT}
    """
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
        if not rows:
            p = [catalogue] if catalogue else []
            rows = conn.execute(f"""SELECT l.id,c.name,l.page,l.line_no,l.price,l.text,l.norm_text
                FROM lines l JOIN catalogues c ON c.id=l.catalogue_id WHERE c.status LIKE 'ready%' {cat_clause}
                ORDER BY l.id DESC LIMIT {FUZZY_CANDIDATE_LIMIT}""", p).fetchall()
    if not rows:
        return pd.DataFrame()
    choices = {r["id"]: r["norm_text"] for r in rows}
    rowmap = {r["id"]: r for r in rows}
    matches = process.extract(qn, choices, scorer=fuzz.token_set_ratio, score_cutoff=MIN_FUZZY_SCORE, limit=limit)
    out = []
    for _, score, row_id in matches:
        r = rowmap[row_id]
        out.append({"Catalogue": r["name"], "Page": r["page"], "Ligne": r["line_no"], "Prix détecté": r["price"],
                    "Référence / Libellé exact": r["text"], "Score & Correspondance": f"fuzzy {score:.0f}%"})
    return pd.DataFrame(out)


def hybrid_search(query: str, catalogue: str | None = None, limit: int = SEARCH_LIMIT) -> pd.DataFrame:
    """V12.3 commercial search: structured products first, then product blocks, then verified FTS."""
    q=(query or "").strip()
    if not q:
        df=search_fts("",catalogue,limit)
        if df is None or df.empty: return pd.DataFrame()
        df=enrich_results(df)
        return df[df.apply(is_reliable_commercial_result,axis=1)].head(limit)

    frames=[]
    fast=search_products_fast(q,catalogue,limit)
    if fast is not None and not fast.empty:
        frames.append(fast)

    try:
        blocks=search_product_blocks(q,min(limit,200))
        if blocks is not None and not blocks.empty:
            if catalogue and "Catalogue" in blocks.columns:
                blocks=blocks[blocks["Catalogue"]==catalogue]
            frames.append(blocks)
    except Exception:
        pass

    # Legacy FTS is only a safety net; unpriced pseudo-products are removed.
    legacy=search_fts(q,catalogue,min(limit,250))
    if legacy is not None and not legacy.empty:
        legacy=enrich_results(legacy)
        legacy=legacy[legacy.apply(is_reliable_commercial_result,axis=1)]
        if not legacy.empty: frames.append(legacy)

    if not frames:
        return pd.DataFrame()

    df=pd.concat(frames,ignore_index=True,sort=False)
    df=enrich_results(df)
    df=df[df.apply(is_reliable_commercial_result,axis=1)].copy()
    keys=[c for c in ["Catalogue","Page","Ligne","Référence"] if c in df.columns]
    if keys: df=df.drop_duplicates(subset=keys,keep="first")
    return df.head(limit)


# ========================= V3.0 IA LOCAL =========================
OLLAMA_URL=os.getenv("OLLAMA_URL","http://ia-local:11434").rstrip("/")
OLLAMA_MODEL=os.getenv("OLLAMA_MODEL","qwen2.5:0.5b")
AI_TIMEOUT=int(os.getenv("AI_TIMEOUT","18"))
AI_SYNONYMS={"lit":["lit","couchage","sommier"],"chaise":["chaise","siege","siège"],"fauteuil":["fauteuil","siege","siège"],"table":["table","bureau"],"armoire":["armoire","rangement"]}

def _norm_dim(v):
    nums=re.findall(r"\d+(?:[.,]\d+)?",v or "")
    if len(nums)<2:return ""
    vals=[]
    for x in nums[:3]:
        n=float(x.replace(",",".")); n=n/10.0 if n>=500 else n
        vals.append(str(int(n) if n.is_integer() else n))
    return "x".join(vals)

def _heuristic_intent(question):
    q=normalize(question); refs=re.findall(r"\b[A-Z]{2,}[A-Z0-9]*(?:[-_/][A-Z0-9]+)*\d[A-Z0-9_-]*\b",question.upper())
    dm=re.search(r"(?<!\d)(\d{2,4})\s*[x×X/]\s*(\d{2,4})(?:\s*[x×X/]\s*(\d{2,4}))?",question)
    pmax=re.search(r"(?:moins de|max(?:imum)?|sous|jusqu.?a)\s*(\d+(?:[.,]\d+)?)\s*€?",q); pmin=re.search(r"(?:plus de|min(?:imum)?|a partir de)\s*(\d+(?:[.,]\d+)?)\s*€?",q)
    product=None
    for canonical,words in AI_SYNONYMS.items():
        if any(re.search(rf"\b{re.escape(normalize(w))}\b",q) for w in words):product=canonical;break
    sort="price_asc" if any(x in q for x in ["moins cher","moins chers","prix croissant","le moins cher"]) else None
    return {"product":product,"reference":refs[0] if refs else None,"dimensions":_norm_dim("x".join(x for x in dm.groups() if x)) if dm else None,"price_min":float(pmin.group(1).replace(",",".")) if pmin else None,"price_max":float(pmax.group(1).replace(",",".")) if pmax else None,"color":None,"finish":None,"sort":sort}

def _ollama_intent(question):
    prompt="Vous êtes un parseur de recherche de catalogue mobilier. Retourne UNIQUEMENT un objet JSON. Champs: product, reference, dimensions, price_min, price_max, color, finish, sort. sort=null, price_asc ou price_desc. N invente jamais reference ni prix. null si absent. Question: "+question
    body=json.dumps({"model":OLLAMA_MODEL,"prompt":prompt,"stream":False,"options":{"temperature":0,"num_predict":120,"num_ctx":1024}}).encode()
    req=urllib.request.Request(OLLAMA_URL+"/api/generate",data=body,headers={"Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(req,timeout=AI_TIMEOUT) as r: payload=json.loads(r.read().decode())
        m=re.search(r"\{.*\}",(payload.get("response") or ""),re.S)
        if not m:return None,"IA locale: réponse non structurée"
        obj=json.loads(m.group(0)); allowed={"product","reference","dimensions","price_min","price_max","color","finish","sort"}; obj={k:obj.get(k) for k in allowed}
        if obj.get("dimensions"):obj["dimensions"]=_norm_dim(str(obj["dimensions"]))
        return obj,"IA locale · "+OLLAMA_MODEL
    except Exception:return None,"Mode rapide local (IA indisponible)"

def interpret_question(question):
    h=_heuristic_intent(question); q=normalize(question)
    need=not h.get("reference") and not (h.get("product") and h.get("dimensions") and len(q.split())<=5) and (len(q.split())>=4 or any(x in q for x in ["trouve moi","peux tu","je cherche","moins cher","similaire","avec"]))
    if not need:return h,"Moteur rapide · sans IA"
    ai,status=_ollama_intent(question)
    if not ai:return h,status
    for k in ("reference","dimensions","price_min","price_max"):
        if h.get(k) is not None:ai[k]=h[k]
    return ai,status

def natural_catalogue_search(question,limit=100):
    intent,status=interpret_question(question)
    if intent.get("reference"):return add_pdf_links(search_products_fast(str(intent["reference"]),None,limit)),intent,status
    where=["c.status LIKE 'ready%'"]; params=[]; product=(intent.get("product") or "").strip(); dim=(intent.get("dimensions") or "").strip()
    if product:
        ors=[]
        for w in AI_SYNONYMS.get(normalize(product),[product])[:4]:
            ors.append("(lower(coalesce(p.designation,'')) LIKE ? OR lower(p.raw_text) LIKE ?)"); v="%"+normalize(w)+"%"; params.extend([v,v])
        where.append("("+" OR ".join(ors)+")")
    for key,col in (("color","coloris"),("finish","finition")):
        v=(intent.get(key) or "").strip()
        if v:where.append(f"(lower(coalesce(p.{col},'')) LIKE ? OR lower(p.raw_text) LIKE ?)"); params.extend(["%"+normalize(v)+"%","%"+normalize(v)+"%"])
    if intent.get("price_min") is not None:where.append("p.prix_ht>=?");params.append(float(intent["price_min"]))
    if intent.get("price_max") is not None:where.append("p.prix_ht<=?");params.append(float(intent["price_max"]))
    order="p.confidence DESC"
    if intent.get("sort")=="price_asc":order="p.prix_ht IS NULL,p.prix_ht ASC"
    elif intent.get("sort")=="price_desc":order="p.prix_ht IS NULL,p.prix_ht DESC"
    sql=f"SELECT p.reference 'Référence',p.prix_ht 'Prix HT',p.page 'Page',p.line_no 'Ligne',c.name 'Catalogue',p.raw_text '_hit',p.dimensions '_dimensions' FROM products p JOIN catalogues c ON c.id=p.catalogue_id WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ?"
    params.append(max(limit*5,300) if dim else limit)
    with db() as conn:ensure_products_schema(conn);df=pd.read_sql_query(sql,conn,params=params)
    if dim and not df.empty:
        target=_norm_dim(dim)
        def match(r):
            vals=[_norm_dim(str(r.get("_dimensions","")))]; raw=str(r.get("_hit",""))
            for m in re.finditer(r"(\d{2,4})\s*[x×X/]\s*(\d{2,4})(?:\s*[x×X/]\s*(\d{2,4}))?",raw):vals.append(_norm_dim("x".join(x for x in m.groups() if x)))
            return target in vals
        df=df[df.apply(match,axis=1)].head(limit)
    if df.empty:
        terms=[x for x in [product,dim,intent.get("color"),intent.get("finish")] if x]
        if terms:df=hybrid_search(" ".join(terms),None,limit)
    if not df.empty:df=add_pdf_links(df)
    return df,intent,status
# ======================= FIN V3.0 IA LOCAL =======================


def item_query(text: str) -> str:
    n = normalize(text)
    n = PRICE_RE.sub(" ", n)
    words = [w for w in re.findall(r"[\w./-]+", n) if len(w) > 1 and w not in STOPWORDS and not w.isdigit()]
    refs = REF_RE.findall(text)
    if refs:
        return " ".join(refs[:2] + words[:6])
    return " ".join(words[:8])


def best_match(text: str) -> dict | None:
    q = item_query(text)
    if not q:
        return None
    df = hybrid_search(q, limit=10)
    if df.empty:
        return None
    qn = normalize(text)
    best_i, best_score = 0, -1
    for i, row in df.iterrows():
        score = fuzz.token_set_ratio(qn, normalize(str(row.get("_hit", row.get("Référence / Libellé exact", row.get("Référence", ""))))))
        if score > best_score:
            best_i, best_score = i, score
    r = df.loc[best_i].to_dict()
    r["confidence"] = best_score
    return r


def split_email_items(text: str) -> list[dict]:
    chunks = re.split(r"[\n;•]+|(?<=[.!?])\s+", text or "")
    items = []
    for chunk in chunks:
        chunk = clean_line(chunk)
        if len(chunk) < 3:
            continue
        # Split coordinated requests conservatively; preserve dimensions such as 120x60.
        parts = re.split(r"\s*,\s*|\s+et\s+(?=(?:\d+\s+)?[a-zà-ÿ])", chunk, flags=re.I)
        for part in parts:
            part = clean_line(part)
            qmatch = QTY_RE.search(part)
            qty = int(qmatch.group(1)) if qmatch else 1
            cleaned = re.sub(r"^(bonjour|bonsoir|merci)[, ]*", "", part, flags=re.I)
            cleaned = re.sub(r"\b(?:il me faudrait|je voudrais|nous souhaitons|j'ai besoin de|de|du|des)\b", " ", cleaned, flags=re.I)
            cleaned = clean_line(cleaned)
            if len(item_query(cleaned)) >= 2:
                items.append({"Quantité": qty, "Demande détectée": cleaned})
    return items[:200]


def analyze_email(text: str) -> pd.DataFrame:
    """Client text is transient: resolve against supplier index, never pollute it."""
    out=[]
    for item in split_email_items(text):
        match=best_match(item["Demande détectée"]); row=dict(item)
        if match:
            row.update({"Référence":match.get("Référence"),"Prix HT":match.get("Prix HT"),"Page":match.get("Page"),"Ligne":match.get("Ligne"),"Catalogue":match.get("Catalogue"),"Confiance":round(match.get("confidence",0),1),"Statut":"Identifié" if match.get("confidence",0)>=80 else "À vérifier"})
        else:
            row.update({"Référence":None,"Prix HT":None,"Page":None,"Ligne":None,"Catalogue":None,"Confiance":0,"Statut":"Non trouvé"})
        out.append(row)
    df=pd.DataFrame(out)
    return add_pdf_links(df) if not df.empty else df



def dataframe_xlsx(df: pd.DataFrame, sheet="Résultats") -> bytes:
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet[:31])
        ws = writer.book[sheet[:31]]
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="E5E7EB")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            width = min(max((len(str(c.value or "")) for c in col), default=10) + 2, 60)
            ws.column_dimensions[col[0].column_letter].width = width
    return bio.getvalue()


def checkpoint_db() -> None:
    with db() as conn:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def create_backup() -> Path:
    ensure_dirs(); checkpoint_db()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = BACKUP_DIR / f"catalogue_fts_{stamp}.db"
    src = sqlite3.connect(DB_PATH, timeout=60)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst, pages=1000, sleep=0.05)
        ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok": raise RuntimeError(f"Backup invalide: {ok}")
    finally:
        dst.close(); src.close()
    return target


def restore_backup(source: Path) -> None:
    test = sqlite3.connect(source)
    try:
        ok = test.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok": raise RuntimeError(f"Sauvegarde corrompue: {ok}")
    finally: test.close()
    safety = BACKUP_DIR / f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    if DB_PATH.exists():
        src=sqlite3.connect(DB_PATH); dst=sqlite3.connect(safety)
        try: src.backup(dst)
        finally: dst.close(); src.close()
    for ext in ("-wal", "-shm"):
        Path(str(DB_PATH)+ext).unlink(missing_ok=True)
    shutil.copy2(source, DB_PATH)
    init_db()



def catalogue_relpath(abs_path: str) -> str:
    try: return str(Path(abs_path).relative_to(CATALOGUE_DIR))
    except Exception: return Path(abs_path).name

def db_size() -> int:
    return sum(p.stat().st_size for p in DATA_DIR.glob("catalogue_fts.db*") if p.is_file())


def human_size(n: int) -> str:
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if n < 1024 or unit == "To":
            return f"{n:.1f} {unit}" if unit != "o" else f"{n} {unit}"
        n /= 1024
    return str(n)



def recalculate_prices() -> tuple[int, int]:
    """Repair prices in an existing index without re-reading PDFs."""
    pages_done = updated = 0
    with db() as conn:
        pages=conn.execute("SELECT DISTINCT catalogue_id,page FROM lines ORDER BY catalogue_id,page").fetchall()
    for pr in pages:
        with db() as conn:
            rows=conn.execute("SELECT id,line_no,text,price FROM lines WHERE catalogue_id=? AND page=? ORDER BY line_no", (pr["catalogue_id"],pr["page"])).fetchall()
            texts=[clean_line(r["text"]) for r in rows]
            for pos,r in enumerate(rows):
                price=detect_price(texts[pos])
                if price is None:
                    for radius in range(1,9):
                        for j in (pos+radius,pos-radius):
                            if 0 <= j < len(texts):
                                price=detect_price(texts[j])
                                if price is not None: break
                        if price is not None: break
                if price is not None and r["price"] != price:
                    conn.execute("UPDATE lines SET price=? WHERE id=?",(price,r["id"])); updated += 1
            conn.commit(); pages_done += 1
    return pages_done, updated

def _safe_int(value, default=0) -> int:
    try:
        if value is None or pd.isna(value):
            return default
        return int(float(value))
    except (TypeError, ValueError, OverflowError):
        return default

def add_pdf_links(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    with db() as conn:
        paths={r["name"]:r["path"] for r in conn.execute("SELECT name,path FROM catalogues")}
    df=df.copy()
    hits=df.get("_hit",df.get("Référence / Libellé exact",df.get("Demande détectée",pd.Series([""]*len(df),index=df.index)))).fillna("").astype(str)
    pages=df.get("Page",pd.Series([1]*len(df),index=df.index))
    lines=df.get("Ligne",pd.Series([0]*len(df),index=df.index))
    links=[]
    for n,p,ln,hit in zip(df["Catalogue"],pages,lines,hits):
        if n is None or pd.isna(n):
            links.append(None)
            continue
        page=max(1,_safe_int(p,1))
        line=max(0,_safe_int(ln,0))
        rel=catalogue_relpath(paths.get(str(n),str(n)))
        links.append(f"?pdf={quote(rel)}&page={page}&line={line}&hit={quote(hit[:180])}")
    df["PDF / Page"]=links
    return df

def render_table(df: pd.DataFrame, key_prefix: str = "search") -> None:
    if df.empty:
        st.info("Aucun résultat."); return
    df=enrich_results(df)
    df=enrich_with_options(df)
    if "_options" in df.columns:
        df["Options"] = df["_options"]
    preferred=["Description","Dimensions","Plateau","Panneau","Chant","GEN. LAFA","Référence","Prix HT","Éco","Options","Page","Ligne","Catalogue","PDF / Page"]
    available=[c for c in preferred if c in df.columns]
    default_cols=[c for c in ["Description","Dimensions","Plateau","Panneau","Chant","GEN. LAFA","Référence","Prix HT","Éco","Options","PDF / Page"] if c in available]
    with st.expander("⚙️ Colonnes affichées", expanded=False):
        selected_cols=st.multiselect(
            "Choisissez les colonnes à afficher", available,
            default=st.session_state.get(f"{key_prefix}_visible_columns",default_cols),
            key=f"{key_prefix}_visible_columns")
        if not selected_cols:
            selected_cols=default_cols or available[:1]
    shown=df[selected_cols].copy()
    st.dataframe(shown,use_container_width=True,hide_index=True,height=min(720,88+36*len(shown)),column_config={
        "Description":st.column_config.TextColumn("Description",width="large"),
        "Dimensions":st.column_config.TextColumn("Dimensions",width="medium"),
        "Plateau":st.column_config.TextColumn("Plateau",width="small"),
        "Panneau":st.column_config.TextColumn("Panneau",width="small"),
        "Chant":st.column_config.TextColumn("Chant",width="small"),
        "GEN. LAFA":st.column_config.TextColumn("GEN. LAFA",width="small"),
        "Référence":st.column_config.TextColumn("Référence",width="medium"),
        "Prix HT":st.column_config.NumberColumn("Prix HT",format="%.2f €",width="small"),
        "Éco":st.column_config.NumberColumn("Éco",format="%.2f €",width="small"),
        "Options":st.column_config.TextColumn("Options de gamme",width="large"),
        "Page":st.column_config.NumberColumn("Page",format="%d",width="small"),
        "Ligne":st.column_config.NumberColumn("Ligne",format="%d",width="small"),
        "Catalogue":st.column_config.TextColumn("Catalogue",width="large"),
        "PDF / Page":st.column_config.LinkColumn("Source",display_text="Ouvrir",width="small")})



# ========================= V4 IA ASSISTANT =========================
# V4 principle:
# - SQLite/FTS5 is the source of truth.
# - The local LLM understands/reranks/explains but cannot create catalogue facts.
# - Client e-mails become structured order lines.
# - Existing Excel templates are completed by header detection, preserving formatting.

V4_COLOR_WORDS={
    "jaune":["jaune","yellow","moutarde","ocre"],
    "bleu":["bleu","blue","azur","marine"],
    "rouge":["rouge","red","bordeaux"],
    "vert":["vert","green","olive"],
    "noir":["noir","black","anthracite"],
    "blanc":["blanc","white"],
    "gris":["gris","grey","gray","anthracite"],
}
V4_HEADER_ALIASES={
    "quantity":["qte","qté","quantite","quantité","qty","nombre"],
    "request":["demande","designation demandee","désignation demandée","article client","besoin"],
    "reference":["reference","référence","ref","code article","code","article"],
    "designation":["designation","désignation","libelle","libellé","description","produit"],
    "price":["prix ht","pu ht","prix unitaire ht","tarif ht","tarif","prix"],
    "eco":["eco","éco","eco participation","éco participation","ecoparticipation","éco-participation"],
    "total":["total ht","montant ht","total"],
    "catalogue":["catalogue","fournisseur","source"],
    "page":["page"],
    "status":["statut","status","validation"],
}

def v4_norm_header(v):
    return normalize(str(v or "")).replace("_"," ").strip()

def v4_llm_json(prompt, max_tokens=500):
    body=json.dumps({
        "model":OLLAMA_MODEL,"prompt":prompt,"stream":False,"keep_alive":-1,
        "format":"json",
        "options":{"temperature":0.1,"num_predict":max_tokens,"num_ctx":8192}
    }).encode("utf-8")
    req=urllib.request.Request(OLLAMA_URL+"/api/generate",data=body,
                               headers={"Content-Type":"application/json"})
    try:
        with urllib.request.urlopen(req,timeout=max(AI_TIMEOUT,30)) as r:
            payload=json.loads(r.read().decode("utf-8"))
        return json.loads((payload.get("response") or "{}").strip()),None
    except Exception as e:
        return None,str(e)

def v4_extract_mail_lines(text):
    """Extract quantities + client requests. LLM first, deterministic fallback."""
    prompt="""Vous extrayez une demande commerciale en lignes d'articles.
Retourne JSON: {"lines":[{"quantity":nombre_ou_null,"request":"texte utile","reference":null_ou_code}]}
Une ligne par article demandé. Ignore bonjour, merci, signatures. N'invente aucune référence.
Message:
"""+(text or "")
    obj,err=v4_llm_json(prompt,450)
    lines=[]
    if isinstance(obj,dict) and isinstance(obj.get("lines"),list):
        for x in obj["lines"]:
            if not isinstance(x,dict): continue
            req=str(x.get("request") or "").strip()
            ref=str(x.get("reference") or "").strip() or None
            qty=x.get("quantity")
            try: qty=int(qty) if qty is not None else 1
            except: qty=1
            if req or ref: lines.append({"quantity":max(1,qty),"request":req or ref,"reference":ref})
    if lines: return lines,"IA locale"
    # Fallback: split around punctuation/new lines and explicit quantities/references.
    raw=[x.strip() for x in re.split(r"[\n;]+|(?<=[.!?])\s+",text or "") if x.strip()]
    for chunk in raw:
        refs=re.findall(r"\b[A-Z]{2,}[A-Z0-9]*(?:[-_/][A-Z0-9]+)*\d[A-Z0-9_-]*\b",chunk.upper())
        qm=re.search(r"\b(\d{1,4})\s*(?:x|pcs?|pi[eè]ces?|unit[eé]s?)?\b",chunk,re.I)
        qty=int(qm.group(1)) if qm else 1
        cleaned=re.sub(r"(?i)\b(bonjour|merci|cordialement|je cherche|je voudrais|il me faut|nous souhaitons)\b"," ",chunk)
        cleaned=" ".join(cleaned.split())
        if refs or len(cleaned)>2:
            lines.append({"quantity":qty,"request":cleaned,"reference":refs[0] if refs else None})
    return lines,"Parseur local"


SEARCH_STOPWORDS={"je","j","cherche","recherche","trouve","trouver","veux","voudrais","souhaite","une","un","des","de","du","la","le","les","en","dans","pour","avec","sans","moi","me","nous","vous","peux","peut","sur","et","ou"}

def meaningful_terms(text):
    return [t for t in re.findall(r"[a-z0-9_-]{2,}",normalize(text or "")) if t not in SEARCH_STOPWORDS]

def _money_values(text):
    vals=[]
    for m in PRODUCT_MONEY_RE.finditer(text or ""):
        raw=m.group(0)
        n=re.search(r"\d{1,6}(?:[ .]\d{3})*[,.]\d{2}", raw)
        if not n: continue
        try: vals.append(float(n.group(0).replace(" ","").replace(".","").replace(",",".")))
        except Exception: pass
    return vals


def _reconstruct_block_product(rows, idx):
    """Rebuild one commercial row around an exact reference anchor.

    A price is accepted only inside the reference-bounded local segment.  This
    prevents the historical error where a neighbouring product's price was used.
    """
    anchor=rows[idx]
    ref=detect_reference(anchor['text'] or '')
    if not ref: return None
    # hard boundaries = previous/next distinct reference; keep a small table-row window
    lo=max(0,idx-7); hi=min(len(rows),idx+8)
    for j in range(idx-1,lo-1,-1):
        r=detect_reference(rows[j]['text'] or '')
        if r and r.upper()!=ref.upper(): lo=j+1; break
    for j in range(idx+1,hi):
        r=detect_reference(rows[j]['text'] or '')
        if r and r.upper()!=ref.upper(): hi=j; break
    seg=rows[lo:hi]
    texts=[clean_line(x['text'] or '') for x in seg if clean_line(x['text'] or '')]
    joined=' | '.join(texts)
    # Prefer money on anchor, then following lines in same bounded segment, then preceding.
    prices=[]
    ordered=[anchor]+rows[idx+1:hi]+list(reversed(rows[lo:idx]))
    for rr in ordered:
        vals=_money_values(rr['text'] or '')
        if vals:
            prices=vals; break
    if not prices: return None
    price=prices[0]; eco=prices[1] if len(prices)>1 else None
    # If product parser can recover richer fields, reuse them, but never its price from outside segment.
    parsed=parse_product_line(joined) or {}
    dims=parsed.get('dimensions')
    if not dims:
        dm=PRODUCT_DIM_RE.search(joined); dims=dm.group(0) if dm else None
    designation=parsed.get('designation')
    if not designation:
        # nearest descriptive text before the reference, excluding headers/options/codes
        for rr in reversed(rows[lo:idx+1]):
            t=clean_line(rr['text'] or '')
            if not t or detect_reference(t) or PRODUCT_MONEY_RE.search(t) or _is_option_start(t): continue
            if re.search(r'(?i)^(description|dimensions|plateau|panneau|chant|gen\.?\s*lafa|ref\.?|prix|eco)\b',t): continue
            if len(re.findall(r'[A-Za-zÀ-ÿ]{2,}',t))>=2:
                designation=t; break
    return {'reference':ref,'designation':designation,'dimensions':dims,'prix_ht':price,'eco_autre':eco,
            'text':joined,'anchor_line':anchor['line_no']}


def ensure_product_blocks(force=False):
    """V12.3: rebuild reference-bounded commercial blocks from the existing line index."""
    with db() as conn:
        ensure_page_meta(conn)
        current=conn.execute("SELECT value FROM app_meta WHERE key='blocks_version'").fetchone()
        if current and current[0]=='4' and not force and conn.execute("SELECT count(*) FROM product_blocks WHERE prix_ht IS NOT NULL").fetchone()[0]>0:
            return
        conn.execute("DELETE FROM product_blocks")
        pages=conn.execute("""SELECT l.catalogue_id,l.page FROM lines l
                              LEFT JOIN page_meta pm ON pm.catalogue_id=l.catalogue_id AND pm.page=l.page
                              WHERE coalesce(pm.searchable_product,1)=1 GROUP BY l.catalogue_id,l.page""").fetchall()
        for pg in pages:
            rows=conn.execute("SELECT line_no,text FROM lines WHERE catalogue_id=? AND page=? ORDER BY line_no",(pg['catalogue_id'],pg['page'])).fetchall()
            for i,r in enumerate(rows):
                if not detect_reference(r['text'] or ''): continue
                prod=_reconstruct_block_product(rows,i)
                if not prod: continue
                conn.execute("""INSERT OR IGNORE INTO product_blocks(catalogue_id,page,anchor_line,text,norm_text,reference,designation,dimensions,prix_ht,eco_autre)
                                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                             (pg['catalogue_id'],pg['page'],prod['anchor_line'],prod['text'],normalize(prod['text']),prod['reference'],prod['designation'],prod['dimensions'],prod['prix_ht'],prod['eco_autre']))
        conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('blocks_version','4')")
        conn.commit()


def search_product_blocks(query,limit=80):
    if not query: return pd.DataFrame()
    ensure_product_blocks()
    refm=PRODUCT_REF_RE.search((query or '').upper())
    with db() as conn:
        if refm:
            ref=refm.group(0).upper()
            d=pd.read_sql_query("""SELECT c.name 'Catalogue',b.page 'Page',b.anchor_line 'Ligne',b.reference 'Référence',
                  b.designation 'Désignation',b.dimensions 'Dimensions',b.prix_ht 'Prix HT',b.eco_autre 'Éco./Autre',b.text '_hit',1200 '_score'
                  FROM product_blocks b JOIN catalogues c ON c.id=b.catalogue_id WHERE upper(b.reference)=? AND b.prix_ht IS NOT NULL LIMIT ?""",conn,params=[ref,limit])
            if not d.empty:return d
        fq=fts_query(' '.join(meaningful_terms(query)))
        if not fq:return pd.DataFrame()
        return pd.read_sql_query("""SELECT c.name 'Catalogue',b.page 'Page',b.anchor_line 'Ligne',b.reference 'Référence',
             b.designation 'Désignation',b.dimensions 'Dimensions',b.prix_ht 'Prix HT',b.eco_autre 'Éco./Autre',b.text '_hit',
             round(-bm25(product_blocks_fts),3) '_score'
             FROM product_blocks_fts JOIN product_blocks b ON b.id=product_blocks_fts.rowid JOIN catalogues c ON c.id=b.catalogue_id
             WHERE product_blocks_fts MATCH ? AND b.reference IS NOT NULL AND b.prix_ht IS NOT NULL ORDER BY bm25(product_blocks_fts) LIMIT ?""",conn,params=[fq,limit])

def adaptive_candidates(query,limit=20):
    """V13: historical assistant memory never injects products into retrieval.
    Conversation context is handled explicitly from the verified previous result set.
    This prevents an old bad association (e.g. a family name -> another family) from contaminating answers.
    """
    return pd.DataFrame()

def remember_assistant_result(query,df):
    if df is None or df.empty:return
    key=' '.join(meaningful_terms(query))[:180]
    if not key:return
    with db() as conn:
        for _,r in df.head(5).iterrows():
            ref=r.get('Référence')
            if ref is None or pd.isna(ref) or not str(ref).strip():continue
            conn.execute("""INSERT INTO assistant_memory(query_key,reference,designation,hits,last_used) VALUES(?,?,?,?,?)
                            ON CONFLICT(query_key,reference) DO UPDATE SET hits=hits+1,designation=excluded.designation,last_used=excluded.last_used""",
                         (key,str(ref),str(r.get('Désignation') or ''),1,utcnow()))
        conn.commit()

def expanded_queries(query):
    """Full phrase -> useful phrase -> individual clues -> normalized reference/dimensions."""
    out=[query.strip()]
    terms=meaningful_terms(query)
    if terms: out.append(' '.join(terms))
    if len(terms)>2:
        for n in (3,2):
            out.extend(' '.join(terms[i:i+n]) for i in range(max(0,len(terms)-n+1)))
    out.extend(terms[:8])
    dims=re.findall(r"\d{2,4}\s*[x×X/]\s*\d{2,4}(?:\s*[x×X/]\s*\d{2,4})?",query)
    out.extend(dims)
    ref=PRODUCT_REF_RE.search(query.upper())
    if ref: out.insert(0,ref.group(0))
    seen=[]
    for x in out:
        x=' '.join(str(x).split())
        if x and normalize(x) not in [normalize(y) for y in seen]:seen.append(x)
    return seen[:16]

def v4_candidate_search(query, limit=60):
    """V13 multi-pass retrieval over verified commercial rows; returns a broad candidate pool."""
    if not query:return pd.DataFrame()
    frames=[]
    for q in expanded_queries(query):
        try:
            d=search_products_fast(q,None,min(limit,80))
            if d is not None and not d.empty:frames.append(d)
        except Exception:pass
        try:
            d=search_product_blocks(q,min(limit,80))
            if d is not None and not d.empty:frames.append(d)
        except Exception:pass
        if len(frames)>=8:break
    # Proven line engine remains a safety net, not the first/only source.
    try:
        d=hybrid_search(query,None,limit)
        if d is not None and not d.empty:frames.append(d)
    except Exception:pass
    if not frames:return pd.DataFrame()
    df=pd.concat(frames,ignore_index=True,sort=False)
    df=enrich_results(df)
    if df is not None and not df.empty:
        df=df[df.apply(is_reliable_commercial_result,axis=1)].copy()
        keys=[c for c in ['Catalogue','Page','Référence','_hit'] if c in df.columns]
        if keys:df=df.drop_duplicates(subset=keys,keep='first')
    return df.head(max(limit*4,400))

def v4_score_candidate(request, row):
    """Deterministic business score, including colors/dimensions/codes/prices."""
    q=normalize(request)
    raw=normalize(" ".join(str(row.get(c,"") or "") for c in
        ["Référence","Désignation","Dimensions","Finition","Coloris","Référence / Libellé exact","_hit"]))
    score=0
    ref=normalize(str(row.get("Référence","") or ""))
    if ref and ref in q: score+=1000
    # dimensions are highly discriminating
    dims=re.findall(r"\d{2,4}\s*[x×X/]\s*\d{2,4}(?:\s*[x×X/]\s*\d{2,4})?",request)
    for d in dims:
        nd=_norm_dim(d)
        if nd and (nd==_norm_dim(raw) or all(x in raw for x in re.findall(r"\d+",d))): score+=350
    # explicit colors: candidate must contain a compatible color clue to receive the boost
    for canonical,words in V4_COLOR_WORDS.items():
        if any(normalize(w) in q for w in words):
            if any(normalize(w) in raw for w in words): score+=300
            else: score-=120
    # lexical coverage
    tokens=[t for t in re.findall(r"[a-z0-9-]{3,}",q) if t not in {"avec","pour","dans","moins","plus","cher","chere","trouve","cherche"}]
    matched=sum(1 for t in set(tokens) if t in raw)
    score+=matched*38
    if tokens and matched==len(set(tokens)): score+=180
    if row.get("Référence") is not None and not pd.isna(row.get("Référence")): score+=45
    if row.get("Désignation") is not None and not pd.isna(row.get("Désignation")): score+=35
    if row.get("Prix HT") is not None and not pd.isna(row.get("Prix HT")): score+=35
    if row.get("Dimensions") is not None and not pd.isna(row.get("Dimensions")): score+=20
    return score

def v4_rerank(request, df, top=12):
    if df is None or df.empty: return df
    x=df.copy()
    x["_v4_score"]=[v4_score_candidate(request,r) for _,r in x.iterrows()]
    x=x.sort_values("_v4_score",ascending=False).head(max(top,1))
    return x

def _assistant_previous_pool():
    """Last verified product pool, used for conversational refinement."""
    hist=st.session_state.get("assistant_history",[])
    for m in reversed(hist):
        d=m.get("sources")
        if m.get("role")=="assistant" and isinstance(d,pd.DataFrame) and not d.empty:
            return d.copy()
    return pd.DataFrame()

def _is_refinement(question):
    q=normalize(question or "")
    markers=("moins cher","plus cher","uniquement","seulement","avec ","sans ","rouge","bleu","vert","jaune","noir","blanc","gris","dimension","taille","prix","stratif","melamin","mélamin","epoxy","école","ecole","enseignement","maternelle","montre tout","affiche tout","tous","toutes")
    return len((question or "").split())<=7 or any(x in q for x in markers)

def _filter_previous_pool(question, df):
    if df is None or df.empty:return df
    qn=normalize(question)
    out=df.copy()
    # price sorting is deterministic
    if any(x in qn for x in ("moins cher","moins chere","prix croissant")) and "Prix HT" in out.columns:
        return out.sort_values("Prix HT",na_position="last")
    # explicit dimensions / numbers
    nums=re.findall(r"\b\d{2,4}\b",qn)
    # meaningful qualifiers; ignore conversational control words
    ignore=set(SEARCH_STOPWORDS)|{"montre","affiche","tout","tous","toutes","moins","cher","chere","produit","produits","resultat","resultats"}
    terms=[t for t in meaningful_terms(qn) if t not in ignore and not t.isdigit()]
    mask=[]
    for _,r in out.iterrows():
        blob=normalize(" ".join(str(r.get(c,"") or "") for c in out.columns if c not in {"PDF / Page"}))
        ok=True
        if nums: ok=all(n in blob for n in nums)
        if terms: ok=ok and all(t in blob for t in terms)
        mask.append(ok)
    filtered=out[pd.Series(mask,index=out.index)]
    return filtered if not filtered.empty else out

def v4_assistant(question, limit=200):
    """V13: broad retrieval -> conversational refinement -> deterministic ranking.
    The LLM never decides which database rows exist; it reasons over verified rows.
    """
    intent,status=interpret_question(question)
    previous=_assistant_previous_pool()
    if _is_refinement(question) and not previous.empty:
        candidates=_filter_previous_pool(question,previous)
    else:
        frames=[]
        for qtry in expanded_queries(question):
            d=v4_candidate_search(qtry,250)
            if d is not None and not d.empty: frames.append(d)
            if len(frames)>=10: break
        candidates=pd.concat(frames,ignore_index=True,sort=False) if frames else pd.DataFrame()
        if not candidates.empty:
            dedupe=[c for c in ["Catalogue","Page","Référence"] if c in candidates.columns]
            if dedupe:candidates=candidates.drop_duplicates(subset=dedupe,keep="first")
    if candidates.empty:
        candidates,_,_=natural_catalogue_search(question,250)
    if candidates is None or candidates.empty:
        return pd.DataFrame(),"Je n'ai trouvé aucune correspondance suffisamment exploitable dans le référentiel.",intent,status
    candidates=enrich_results(candidates)
    candidates=candidates[candidates.apply(is_reliable_commercial_result,axis=1)].copy()
    candidates["_v4_score"]=[v4_score_candidate(question,r) for _,r in candidates.iterrows()]
    candidates=candidates.sort_values("_v4_score",ascending=False)
    # explicit color is a real filter, never an LLM guess
    qn=normalize(question)
    for color,words in V4_COLOR_WORDS.items():
        if any(normalize(w) in qn for w in words):
            m=[]
            for _,r in candidates.iterrows():
                blob=normalize(" ".join(str(r.get(c,"") or "") for c in candidates.columns))
                m.append(any(normalize(w) in blob for w in words))
            f=candidates[pd.Series(m,index=candidates.index)]
            if not f.empty:candidates=f
    if intent.get("sort")=="price_asc" or "moins cher" in qn:
        if "Prix HT" in candidates.columns:candidates=candidates.sort_values("Prix HT",na_position="last")
    ranked=add_pdf_links(candidates.head(max(1,min(limit,200))))
    remember_assistant_result(question,ranked)
    return ranked,f"{len(ranked)} référence(s) vérifiée(s) disponible(s) pour cette demande.",intent,status


def v4_merge_same_request_lines(lines):
    """Merge duplicate extracted requests so `2 COL2438` becomes one commercial line, not two candidates."""
    merged={}
    for x in lines:
        key=normalize(str(x.get("reference") or x.get("request") or ""))
        if not key: continue
        if key not in merged:
            merged[key]=dict(x)
        else:
            # Do not sum duplicated parser interpretations of the same phrase.
            merged[key]["quantity"]=max(int(merged[key].get("quantity") or 1),int(x.get("quantity") or 1))
    return list(merged.values())

def v4_explicit_qty_refs(text):
    words={"un":1,"une":1,"deux":2,"trois":3,"quatre":4,"cinq":5,"six":6,"sept":7,"huit":8,"neuf":9,"dix":10,"onze":11,"douze":12}
    found=[]; source=text or ""
    for m in re.finditer(r"\b[A-Z]{2,}[A-Z0-9]*(?:[-_][A-Z0-9]+)*\d[A-Z0-9_-]*\b",source.upper()):
        before=source[max(0,m.start()-100):m.start()]; nums=re.findall(r"\b(\d{1,4})\b",before); qty=int(nums[-1]) if nums else None
        if qty is None:
            nb=re.findall(r"\b("+"|".join(words)+r")\b",normalize(before)); qty=words.get(nb[-1],1) if nb else 1
        found.append({"quantity":max(1,qty),"request":source.strip(),"reference":m.group(0).upper()})
    return found


def v4_client_designation(request, reference=None):
    txt=str(request or "")
    if reference:
        txt=re.sub(rf"\b{re.escape(str(reference))}\b"," ",txt,flags=re.I)
    txt=re.sub(r"(?i)\b(je|nous|cherche|cherchons|veux|voudrais|souhaite|souhaitons|il me faut|merci|bonjour)\b"," ",txt)
    txt=re.sub(r"(?i)\b\d+\s*(?:x|pcs?|pi[eè]ces?|unit[eé]s?)?\b"," ",txt)
    return " ".join(txt.split()).strip(" ,.-") or str(reference or "Article")

def v4_exact_reference_row(reference):
    if not reference: return pd.DataFrame()
    ref=str(reference).upper().strip(); d=v4_candidate_search(ref,80)
    if d is not None and not d.empty:
        if "Référence" in d.columns:
            ex=d[d["Référence"].fillna("").astype(str).str.upper()==ref]
            if not ex.empty: return enrich_results(ex)
    with db() as conn:
        rows=pd.read_sql_query("""SELECT c.name "Catalogue",l.page "Page",l.line_no "Ligne",p.designation "Désignation",p.dimensions "Dimensions",p.finition "Finition",coalesce(p.reference,l.reference) "Référence",p.prix_ht "Prix HT",p.eco_autre "Éco./Autre",p.coloris "Coloris",l.text "_hit" FROM lines l JOIN catalogues c ON c.id=l.catalogue_id LEFT JOIN products p ON p.line_id=l.id WHERE upper(l.text) LIKE ? LIMIT 40""",conn,params=[f"%{ref}%"])
    rows=enrich_results(rows)
    if not rows.empty:
        ex=rows[rows["Référence"].fillna("").astype(str).str.upper()==ref]
        return ex if not ex.empty else rows
    return rows

def v4_resolve_client_mail(text, top_candidates=3):
    lines,mode=v4_extract_mail_lines(text); explicit=v4_explicit_qty_refs(text)
    if explicit: lines=explicit
    lines=v4_merge_same_request_lines(lines); rows=[]
    for item in lines:
        qty=max(1,int(item.get("quantity") or 1)); ref=item.get("reference")
        cand=v4_exact_reference_row(ref) if ref else v4_rerank(item["request"],v4_candidate_search(item["request"],80),top_candidates)
        if cand is None or cand.empty:
            rows.append({"Qté":qty,"Désignation":v4_client_designation(item["request"],ref),"Référence":"Non indexé","Prix HT":None,"Éco-participation":None,"Total HT":None,"Catalogue":None,"Page":None,"Ligne":None,"Statut":"Non indexé"}); continue
        r=enrich_results(cand).iloc[0]; price=r.get("Prix HT") if bool(r.get("_price_verified",False)) else None; eco=r.get("Éco./Autre") if bool(r.get("_price_verified",False)) else None
        try: price=float(price) if price is not None and not pd.isna(price) else None
        except: price=None
        try: eco=float(eco) if eco is not None and not pd.isna(eco) else 0.0
        except: eco=0.0
        des=r.get("Désignation"); des=v4_client_designation(item["request"],ref) if des is None or pd.isna(des) or not str(des).strip() else des
        _verified=parse_product_line(str(r.get("_hit") or "")) or {}
        if _verified.get("price_verified"):
            price=_verified.get("prix_ht")
            eco=_verified.get("eco_autre") or 0.0
        else:
            price=None; eco=None
        total=round(qty*(float(price)+float(eco)),2) if price is not None else None
        rows.append({"Qté":qty,"Désignation":des,"Référence":_verified.get("reference") or r.get("Référence") or ref or "Non indexé",
                     "Prix HT":price,"Éco-participation":eco,"Total HT":total,"Catalogue":r.get("Catalogue"),
                     "Page":r.get("Page"),"Ligne":r.get("Ligne"),"Statut":"Vérifié" if price is not None else "Prix à vérifier"})
    return pd.DataFrame(rows),mode

def v4_find_header_row(ws, scan_rows=30):
    best=(None,{})
    for r in range(1,min(ws.max_row,scan_rows)+1):
        mapping={}
        for c in range(1,ws.max_column+1):
            h=v4_norm_header(ws.cell(r,c).value)
            if not h: continue
            for key,aliases in V4_HEADER_ALIASES.items():
                if h in [v4_norm_header(a) for a in aliases]:
                    mapping[key]=c; break
        if len(mapping)>len(best[1]): best=(r,mapping)
    return best

def v4_fill_excel_template(file_bytes, resolved_df):
    """Fill an existing workbook by detected headers, preserving the workbook/layout."""
    wb=load_workbook(BytesIO(file_bytes))
    # choose sheet with best recognized header row
    choice=None
    for ws in wb.worksheets:
        hr,mp=v4_find_header_row(ws)
        if hr and (choice is None or len(mp)>len(choice[2])): choice=(ws,hr,mp)
    if choice is None or len(choice[2])<2:
        raise ValueError("Je ne reconnais pas les colonnes du modèle Excel. Il faut au moins 2 en-têtes connus (ex. Référence, Prix HT, Quantité, Désignation).")
    ws,header_row,mapping=choice
    # Only primary match per client request goes into the commercial sheet.
    primary=resolved_df[~resolved_df["Statut"].astype(str).str.startswith("Alternative")].copy()
    start=header_row+1
    # find first reasonably empty data row; otherwise append
    row=start
    while row<=ws.max_row and any(ws.cell(row,c).value not in (None,"") for c in mapping.values()):
        row+=1
    fieldmap={"quantity":"Qté","request":"Demande","reference":"Référence","designation":"Désignation",
              "price":"Prix HT","eco":"Éco-participation","total":"Total HT",
              "catalogue":"Catalogue","page":"Page","status":"Statut"}
    for _,rec in primary.iterrows():
        for key,col in mapping.items():
            val=rec.get(fieldmap.get(key,key))
            ws.cell(row,col).value=None if pd.isna(val) else val
            if key in ("price","eco","total") and val is not None and not pd.isna(val):
                ws.cell(row,col).number_format='#,##0.00 [$€-fr-FR]'
        # If the user's template has a Total HT column, use a live Excel formula.
        if all(k in mapping for k in ("quantity","price","total")):
            qcol=get_column_letter(mapping["quantity"])
            pcol=get_column_letter(mapping["price"])
            ecol=get_column_letter(mapping["eco"]) if "eco" in mapping else None
            tcell=ws.cell(row,mapping["total"])
            eco_expr=f'+IF({ecol}{row}="",0,{ecol}{row})' if ecol else ""
            tcell.value=f'=IF(OR({qcol}{row}="",{pcol}{row}=""),"",{qcol}{row}*({pcol}{row}{eco_expr}))'
            tcell.number_format='#,##0.00 [$€-fr-FR]'
        row+=1
    bio=BytesIO(); wb.save(bio); return bio.getvalue(),ws.title,header_row,mapping

def v4_make_quote_excel(resolved_df):
    """Clean commercial workbook: one product per line, no technical/search columns."""
    primary=resolved_df[~resolved_df["Statut"].astype(str).str.startswith("Alternative")].copy()
    cols=["Qté","Désignation","Référence","Prix HT","Éco-participation","Total HT"]
    primary=primary[[c for c in cols if c in primary.columns]]
    bio=BytesIO()
    with pd.ExcelWriter(bio,engine="openpyxl") as writer:
        primary.to_excel(writer,index=False,sheet_name="Devis")
        ws=writer.book["Devis"]
        widths={"A":8,"B":46,"C":22,"D":15,"E":19,"F":17}
        for col,w in widths.items(): ws.column_dimensions[col].width=w
        for row in range(2,ws.max_row+1):
            ws[f"D{row}"].number_format='#,##0.00 [$€-fr-FR]'
            ws[f"E{row}"].number_format='#,##0.00 [$€-fr-FR]'
            ws[f"F{row}"]=f'=IF(OR(D{row}="",A{row}=""),"",ROUND(A{row}*(D{row}+IF(E{row}="",0,E{row})),2))'
            ws[f"F{row}"].number_format='#,##0.00 [$€-fr-FR]'
        total_row=ws.max_row+2
        ws[f"E{total_row}"]="TOTAL HT"
        ws[f"F{total_row}"]=f"=ROUND(SUM(F2:F{ws.max_row}),2)"
        ws[f"F{total_row}"].number_format='#,##0.00 [$€-fr-FR]'
        ws.freeze_panes="A2"
        ws.auto_filter.ref=f"A1:F{max(1,ws.max_row)}"
        _opts=option_warning_text(df)
        if _opts:
            ows=writer.book.create_sheet("Options à valider")
            ows["A1"]="OPTIONS / RÈGLES TARIFAIRES DÉTECTÉES"
            ows["A2"]="Information uniquement : aucune option ci-dessous n'est incluse automatiquement dans le prix du devis."
            ows["A1"].font=Font(bold=True); ows["A2"].font=Font(italic=True)
            for _i,_op in enumerate(_opts,start=4):ows.cell(_i,1,_op)
            ows.column_dimensions["A"].width=120
    return bio.getvalue()

def _option_applicability(option_text, product_text):
    """V10: classify a page/family option against the selected product without changing price."""
    opt=normalize(option_text or "")
    prod=normalize(product_text or "")
    # Explicit catalogue restrictions have priority.
    m=re.search(r"\(([^)]*uniquement[^)]*)\)", opt, re.I)
    restriction=m.group(1).strip() if m else ""
    if restriction:
        words=[w for w in re.findall(r"[a-z0-9]+", restriction) if w not in {"uniquement","seulement","pour","la","le","les","de","du"}]
        if words and not any(w in prod for w in words):
            return "NON_APPLICABLE", restriction
        return "APPLICABLE", restriction
    # Also understand forms such as "chauffeuse uniquement" without parentheses.
    m=re.search(r"\b([a-zà-ÿ0-9 -]{3,45})\s+uniquement\b", opt, re.I)
    if m:
        scope=m.group(1).strip().split()[-3:]
        if scope and not any(w in prod for w in scope if len(w)>3):
            return "NON_APPLICABLE", " ".join(scope)+" uniquement"
        return "APPLICABLE", " ".join(scope)+" uniquement"
    return "A_VALIDER", ""


def _is_dotted_separator(text):
    t=(text or '').strip()
    return bool(re.fullmatch(r'[.·•_\-\s]{12,}',t)) or (len(t)>=18 and t.count('.')/max(1,len(t))>.65)


def _looks_like_section_title(text):
    t=clean_line(text or '')
    if not t or len(t)>100:return False
    if PRODUCT_REF_RE.search(t) or PRODUCT_MONEY_RE.search(t) or PRODUCT_DIM_RE.search(t):return False
    if re.search(r'(?i)\b(description|dimensions|gen\.?\s*lafa|ref\.?|prix|eco|assise/dossier|plateau|panneau|chant)\b',t):return False
    letters=[c for c in t if c.isalpha()]
    return len(letters)>=5 and sum(c.isupper() for c in letters)/max(1,len(letters))>.72


def _nearest_family_title(items, idx):
    """Return the nearest meaningful family title above idx, ignoring table headers."""
    for i in range(min(idx, len(items)-1), -1, -1):
        t=items[i][1]
        if _looks_like_section_title(t):
            return i,t
    return -1,""


def _table_header_before(items, idx):
    header_re=re.compile(r"(?i)\bdescription\b.*\b(dimensions?|ref\.?|prix)\b|\b(dimensions?)\b.*\b(ref\.?|prix)\b")
    for i in range(min(idx, len(items)-1), -1, -1):
        if header_re.search(items[i][1]): return i
    return -1


def _is_product_row(text):
    t=clean_line(text)
    return bool(PRODUCT_REF_RE.search(t) and PRODUCT_MONEY_RE.search(t))

def _clean_option_text(text):
    t=clean_line(text or "")
    # PDF extraction can expose control-code residues such as x000D.
    t=re.sub(r"(?i)\\?x0*0D\b"," ",t)
    t=re.sub(r"\s+"," ",t).strip(" |")
    return t

def _is_option_start(text):
    t=normalize(_clean_option_text(text))
    return bool(re.search(r"\boptions?\b",t))

def _is_option_continuation(text):
    t=_clean_option_text(text)
    if not t or _is_product_row(t): return False
    return bool(re.search(
        r"(?i)\b(eco[- ]?contribution|éco[- ]?contribution|finition|chants?|chrome|roulettes?|"
        r"goulotte|embase|obturateurs?|passe[- ]?c[âa]ble|casier|suppl[eé]ment|plus[- ]?value|"
        r"par rapport [àa]|suivant taille|uniquement)\b",t)
        or re.search(r"(?:\+|-)\s*\d+(?:[,.]\d{1,2})?\s*€",t))

def _option_block_for_product(items, product_idx):
    """Return only an OPTIONS block proven to belong to the same commercial family.

    Boundaries are the nearest family title and/or dotted separator. Accuracy wins over recall:
    if the option zone cannot be proven, no option is attached to the product.
    """
    if not items or product_idx < 0:
        return []
    title_idx, _title = _nearest_family_title(items, product_idx)
    sep_idx = -1
    for i in range(product_idx - 1, max(-1, product_idx - 180), -1):
        if _is_dotted_separator(items[i][1]):
            sep_idx = i
            break
    lower_bound = max(title_idx, sep_idx)
    if lower_bound < 0:
        return []

    start = None
    for i in range(product_idx - 1, lower_bound, -1):
        t = items[i][1]
        if _is_dotted_separator(t):
            break
        if _is_option_start(t):
            start = i
            break
        if _looks_like_section_title(t) and i != title_idx:
            break
    if start is None:
        return []

    for j in range(start + 1, product_idx):
        t = items[j][1]
        if _is_dotted_separator(t):
            return []
        if _is_option_start(t):
            start = j
        elif _looks_like_section_title(t) and j != title_idx:
            return []

    parts = [_clean_option_text(items[start][1])]
    for j in range(start + 1, min(product_idx, start + 10)):
        t = items[j][1]
        nt = normalize(t)
        if _is_dotted_separator(t) or _is_product_row(t):
            break
        if re.search(r"\bdescription\b", nt) and (re.search(r"\bdimensions?\b", nt) or re.search(r"\bprix\b", nt)):
            break
        if _looks_like_section_title(t):
            break
        if _is_option_continuation(t):
            parts.append(_clean_option_text(t))
    return list(dict.fromkeys(x for x in parts if x))

def page_option_context(catalogue, page, line_no, product_text=""):
    """V12.3: exact local option zone. Never applies an option to price automatically."""
    if not catalogue or page is None: return []
    p=_safe_int(page,0); ln=_safe_int(line_no,0)
    if p < 1: return []
    with db() as conn:
        rows=conn.execute(
            """SELECT l.line_no,l.text FROM lines l
               JOIN catalogues c ON c.id=l.catalogue_id
               WHERE c.name=? AND l.page=? ORDER BY l.line_no""",
            (str(catalogue),p)).fetchall()
    items=[(_safe_int(r["line_no"],0),_clean_option_text(r["text"]))
           for r in rows if _clean_option_text(r["text"])]
    if not items: return []
    product_idx=min(range(len(items)),key=lambda i:abs(items[i][0]-ln)) if ln else len(items)-1
    parts=_option_block_for_product(items,product_idx)
    if not parts: return []

    raw=" ".join(parts)
    status,scope=_option_applicability(raw,product_text)
    if status=="NON_APPLICABLE":
        prefix="Non applicable"
    elif status=="APPLICABLE":
        prefix="Disponible"
    else:
        prefix="À confirmer"
    return [f"{prefix} — {raw}"[:1200]]

def option_warning_text(df):
    if df is None or df.empty:return []
    e=enrich_with_options(df); vals=[]
    if "_options" in e.columns:
        for v in e["_options"].dropna().astype(str):
            for part in [x.strip() for x in v.split(" | ") if x.strip()]:
                if part not in vals:vals.append(part)
    return vals[:8]


def page_family_context(catalogue,page,line_no):
    """Read useful family-level text around a product: title, universe and notes such as 'Époxy, livré monté'."""
    if not catalogue or page is None:return {"family":None,"context":None}
    p=_safe_int(page,0); ln=_safe_int(line_no,0)
    if p<1:return {"family":None,"context":None}
    with db() as conn:
        rows=conn.execute("""SELECT l.line_no,l.text FROM lines l JOIN catalogues c ON c.id=l.catalogue_id
                             WHERE c.name=? AND l.page=? ORDER BY l.line_no""",(str(catalogue),p)).fetchall()
    items=[(_safe_int(r["line_no"],0),clean_line(r["text"] or "")) for r in rows if clean_line(r["text"] or "")]
    if not items:return {"family":None,"context":None}
    idx=min(range(len(items)),key=lambda i:abs(items[i][0]-ln)) if ln else len(items)-1
    ti,title=_nearest_family_title(items,idx)
    notes=[]
    lo=max(0,ti if ti>=0 else idx-25)
    for j in range(lo,idx):
        t=_clean_option_text(items[j][1])
        nt=normalize(t)
        if not t or t==title or _is_product_row(t) or detect_reference(t):continue
        if re.search(r"(?i)\b(description|dimensions|plateau|panneau|chant|gen\.?\s*lafa|ref\.?|prix|eco)\b",t):continue
        # retain compact commercial annotations around the family/table
        if len(t)<=140 and (re.search(r"(?i)\b(livr[eé]|mont[eé]|epoxy|[eé]poxy|finition|coloris|option|structure|assise|dossier|garantie|usage|classe|enseignement|maternelle)\b",t) or ':' in t):
            notes.append(t)
    return {"family":title or None,"context":" | ".join(dict.fromkeys(notes[-8:])) or None}

def enrich_with_family_context(df):
    if df is None or df.empty:return df
    out=df.copy(); fam=[]; ctx=[]
    for _,r in out.iterrows():
        z=page_family_context(r.get("Catalogue"),r.get("Page"),r.get("Ligne"))
        fam.append(z.get("family"));ctx.append(z.get("context"))
    out["_family"]=fam;out["_family_context"]=ctx
    return out

def enrich_with_options(df):
    if df is None or df.empty: return df
    out=df.copy()
    vals=[]
    for _,r in out.iterrows():
        opts=page_option_context(r.get('Catalogue'),r.get('Page'),r.get('Ligne'), ' '.join(str(r.get(c) or '') for c in ['Description','Désignation','Référence','_hit']))
        vals.append(' | '.join(opts) if opts else None)
    out['_options']=vals
    return out

def assistant_conversation_answer(question, df, base_answer):
    if df is None or df.empty:return "Je n’ai pas trouvé de produit suffisamment pertinent dans les pages produit indexées. Essayez une référence, un nom de gamme, une dimension ou une caractéristique."
    df=enrich_results(df)
    df=df[df.apply(is_reliable_commercial_result,axis=1)].copy()
    df=enrich_with_family_context(enrich_with_options(df))
    total=len(df)
    qn=normalize(question)
    wants_all=any(x in qn for x in ("affiche tout","afficher tout","montre tout","tous les","toutes les","liste complete","liste complète"))
    facts=[]
    # LLM receives a broad but bounded factual set; UI retains all verified rows.
    llm_df=df.head(60)
    for _,r in llm_df.iterrows():
        def clean(v):
            try:return None if v is None or pd.isna(v) else v
            except:return v
        facts.append({k:clean(r.get(c)) for k,c in {"designation":"Désignation","reference":"Référence","prix_ht":"Prix HT","eco":"Éco./Autre","dimensions":"Dimensions","finition":"Finition","coloris":"Coloris","catalogue":"Catalogue","page":"Page","famille":"_family","contexte_gamme":"_family_context","options":"_options"}.items()})
    # For an explicit 'show all', deterministic output prevents the model from truncating/inventing.
    if wants_all:
        lines=[f"J’ai **{total} référence(s) vérifiée(s)** correspondant au filtre actuel :"]
        for _,r in df.iterrows():
            des=str(r.get("Désignation") or "Produit"); ref=str(r.get("Référence") or "")
            dims=str(r.get("Dimensions") or "").strip(); price=r.get("Prix HT")
            bit=f"- **{ref}** — {des}"
            if dims and dims.lower()!='nan':bit+=f" — {dims}"
            try:
                if price is not None and not pd.isna(price):bit+=f" — **{float(price):.2f} € HT**".replace('.',',')
            except:pass
            lines.append(bit)
        return "\n".join(lines)
    prompt=f"""Vous êtes l'assistant commercial local du catalogue. Votre comportement doit être conversationnel, précis et proche d'un excellent assistant généraliste, mais les faits produits viennent UNIQUEMENT du JSON.
La base a trouvé {total} références vérifiées. Ne dites jamais qu'il n'y en a que 3 ou 4 si total est supérieur. Présentez 5 à 8 choix représentatifs au maximum puis dites clairement que les {total} références restent disponibles et que l'utilisateur peut demander 'affiche tout'.
Comprenez les raffinements successifs (gamme, couleur, école/enseignement, dimension, finition, budget, moins cher) sans repartir arbitrairement de zéro.
Le champ famille et contexte_gamme est essentiel : des mentions comme 'Époxy, livré monté' sont des caractéristiques de gamme à signaler quand elles sont pertinentes.
Les options doivent provenir uniquement du champ options du produit/gamme. Ne mélangez jamais deux familles. Ne modifiez jamais automatiquement le prix avec une option.
N'inventez aucune référence, prix, couleur, disponibilité, compatibilité ou caractéristique. Si le catalogue ne l'affirme pas, dites 'à confirmer'.
Répondez en français, de façon naturelle, structurée et utile.
Question: {question}
Faits JSON: {json.dumps(facts,ensure_ascii=False)}"""
    obj,err=v4_llm_json('Retourne uniquement JSON {"answer":"..."}.\n'+prompt,900)
    if isinstance(obj,dict) and str(obj.get("answer") or "").strip():return str(obj["answer"]).strip()
    lines=[f"J’ai trouvé **{total} référence(s) vérifiée(s)**. Voici les premières :"]
    for f in facts[:8]:
        bits=[f"**{f.get('designation') or 'Produit'}**"]
        if f.get('dimensions'):bits.append(str(f['dimensions']))
        if f.get('reference'):bits.append(f"réf. **{f['reference']}**")
        if f.get('prix_ht') is not None:
            try:bits.append(f"**{float(f['prix_ht']):.2f} € HT**".replace('.',','))
            except:pass
        if f.get('contexte_gamme'):bits.append("gamme : "+str(f['contexte_gamme']))
        if f.get('options'):bits.append("options : "+str(f['options']))
        lines.append(" — ".join(bits))
    if total>8:lines.append(f"\nLes **{total} références** restent disponibles. Dites « affiche tout » ou affinez par gamme, couleur, dimension, finition, usage ou prix.")
    return "\n\n".join(lines)

def assistant_source_links(df):
    if df is None or df.empty:return
    seen=set(); shown=0
    for _,r in enrich_results(df).iterrows():
        if shown>=3:break
        key=(str(r.get("Catalogue")),_safe_int(r.get("Page"),1))
        if key in seen:continue
        seen.add(key); shown+=1; ref=r.get("Référence"); link=r.get("PDF / Page"); label=f"Voir la source · page {key[1]}"
        if ref is not None and not pd.isna(ref):label=f"Voir la source · {ref} · page {key[1]}"
        if link:st.markdown(f"[{label}]({link})")

def assistant_context_question(question):
    hist=st.session_state.get("assistant_history",[])
    users=[m["content"] for m in hist if m.get("role")=="user"][-3:]
    if not users:return question
    qn=normalize(question)
    follow=("moins cher","seulement","uniquement","dimension","prix","lequel","laquelle","montre","avec","sans","autre","alternative","ans","il m en faut","j en veux","couleur","taille")
    refs=[]
    for m in hist[-4:]:
        d=m.get("sources")
        if isinstance(d,pd.DataFrame) and "Référence" in d.columns:
            refs.extend([str(x) for x in d["Référence"].dropna().head(4).tolist()])
    if len(question.split())<=8 or any(x in qn for x in follow):
        extra=("\nRéférences discutées : "+", ".join(dict.fromkeys(refs))) if refs else ""
        return "Demande précédente : "+" | ".join(users)+extra+"\nPrécision actuelle : "+question
    return question

# ======================= FIN V4 IA ASSISTANT ======================


# ========================= FINAL RAG / UX =========================
# Unified product retrieval for Search, Assistant IA and Client -> Excel.
# Product identity (description/family/reference) is intentionally weighted above
# secondary attributes (color, finish, plateau, panel, edging, options).

FINAL_RAG_VERSION = "2026.10-final-2"
UI_PREFS_PATH = DATA_DIR / "ui_preferences.json"
RUNTIME_STATUS_PATH = DATA_DIR / "runtime_status.json"
DEFAULT_COLUMN_ORDER = [
    "Description", "Dimensions", "Plateau", "Panneau", "Chant", "GEN. LAFA",
    "Référence", "Prix HT", "Éco", "Options", "PDF / Page"
]
TECHNICAL_COLUMNS = ["Page", "Ligne", "Catalogue"]

PRODUCT_TYPE_SYNONYMS = {
    "table": ["table", "tables"],
    "chaise": ["chaise", "chaises", "siege", "siège", "sieges", "sièges"],
    "chauffeuse": ["chauffeuse", "chauffeuses"],
    "fauteuil": ["fauteuil", "fauteuils"],
    "bureau": ["bureau", "bureaux"],
    "armoire": ["armoire", "armoires"],
    "caisson": ["caisson", "caissons"],
    "desserte": ["desserte", "dessertes"],
    "banc": ["banc", "bancs"],
    "banquette": ["banquette", "banquettes"],
    "tabouret": ["tabouret", "tabourets"],
    "pouf": ["pouf", "poufs"],
    "canape": ["canape", "canapé", "canapes", "canapés"],
    "lit": ["lit", "lits", "couchage"],
    "meuble": ["meuble", "meubles"],
    "etagere": ["etagere", "étagère", "etageres", "étagères"],
    "rayonnage": ["rayonnage", "rayonnages"],
    "porte-manteaux": ["porte manteaux", "porte-manteaux", "portemanteaux"],
}

UNIVERSE_SYNONYMS = {
    "enseignement": ["enseignement", "ecole", "école", "classe", "scolaire", "maternelle", "college", "collège", "lycee", "lycée"],
    "bureau": ["tertiaire", "bureau", "administratif"],
    "collectivite": ["collectivite", "collectivité", "collectivites", "collectivités"],
}

FINISH_TERMS = ["hnv", "htv", "abs", "stratifie", "stratifié", "melamine", "mélaminé", "epoxy", "époxy", "surmoule", "surmoulé", "compact"]
FINISH_ALIASES = {
    "epoxy": ["epoxy", "époxy", "epoxi", "epoxyl", "epoxyle", "epoxyde"],
    "stratifie": ["stratifie", "stratifié", "stratifiee", "stratifiée"],
    "melamine": ["melamine", "mélaminé", "melaminee", "mélaminée"],
    "surmoule": ["surmoule", "surmoulé", "surmoulee", "surmoulée"],
    "hnv": ["hnv"], "htv": ["htv"], "abs": ["abs"], "compact": ["compact"],
}
SEARCH_FILLER = set(SEARCH_STOPWORDS) | {
    "catalogue", "lafa", "normal", "normale", "possible", "faire", "devis", "article", "il", "an", "ans",
    "garde", "garder", "ceux", "celles", "moui", "faut", "place", "places", "affiche", "afficher", "tout",
    "tous", "toutes", "moins", "plus", "cher", "chere", "chère", "modele", "modèle",
}
NUMBER_WORDS = {"un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6,
                "sept": 7, "huit": 8, "neuf": 9, "dix": 10, "onze": 11, "douze": 12}

_operation_lock = threading.Lock()
_operation_state = {"active": False, "kind": "idle", "message": "Disponible", "progress": None, "updated": time.time()}
_daily_backup_thread = None


def _read_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default.copy() if isinstance(default, dict) else default


def _write_json_atomic(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_ui_preferences() -> dict:
    defaults = {"theme": "Clair", "column_order": DEFAULT_COLUMN_ORDER + TECHNICAL_COLUMNS,
                "visible_columns": DEFAULT_COLUMN_ORDER}
    prefs = _read_json(UI_PREFS_PATH, defaults)
    order = [c for c in prefs.get("column_order", []) if c in DEFAULT_COLUMN_ORDER + TECHNICAL_COLUMNS]
    for c in DEFAULT_COLUMN_ORDER + TECHNICAL_COLUMNS:
        if c not in order:
            order.append(c)
    visible = [c for c in prefs.get("visible_columns", DEFAULT_COLUMN_ORDER) if c in order]
    if not visible:
        visible = DEFAULT_COLUMN_ORDER.copy()
    return {"theme": prefs.get("theme", "Clair"), "column_order": order, "visible_columns": visible}


def save_ui_preferences(prefs: dict) -> None:
    _write_json_atomic(UI_PREFS_PATH, prefs)


def set_operation(kind: str, message: str, progress: float | None = None, active: bool = True) -> None:
    with _operation_lock:
        _operation_state.update({"active": bool(active), "kind": kind, "message": message,
                                 "progress": progress, "updated": time.time()})
        snapshot = dict(_operation_state)
    try:
        _write_json_atomic(RUNTIME_STATUS_PATH, snapshot)
    except Exception:
        pass


def get_operation() -> dict:
    # Read the status file as well: Streamlit re-executes the script on reruns while background threads continue.
    disk = _read_json(RUNTIME_STATUS_PATH, {})
    with _operation_lock:
        mem = dict(_operation_state)
    state = disk if disk.get("updated", 0) >= mem.get("updated", 0) else mem
    if state.get("active") and time.time() - float(state.get("updated", 0) or 0) > 3600:
        state = {"active": False, "kind": "idle", "message": "Disponible", "progress": None, "updated": time.time()}
    return state


def clear_operation(message: str = "Disponible") -> None:
    set_operation("idle", message, None, False)


def ensure_final_schema() -> None:
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS rag_products(
          id INTEGER PRIMARY KEY,
          source_key TEXT NOT NULL UNIQUE,
          catalogue_id INTEGER NOT NULL REFERENCES catalogues(id) ON DELETE CASCADE,
          page INTEGER NOT NULL,
          line_no INTEGER NOT NULL,
          description TEXT,
          description_norm TEXT,
          product_type TEXT,
          family TEXT,
          family_norm TEXT,
          universe TEXT,
          dimensions TEXT,
          dim_norm TEXT,
          plateau TEXT,
          panneau TEXT,
          chant TEXT,
          gen_lafa TEXT,
          finition TEXT,
          coloris TEXT,
          reference TEXT NOT NULL,
          prix_ht REAL NOT NULL,
          eco REAL,
          family_context TEXT,
          options TEXT,
          attributes TEXT,
          raw_text TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_rag_ref ON rag_products(reference COLLATE NOCASE);
        CREATE INDEX IF NOT EXISTS idx_rag_type ON rag_products(product_type);
        CREATE INDEX IF NOT EXISTS idx_rag_family ON rag_products(family_norm);
        CREATE INDEX IF NOT EXISTS idx_rag_dims ON rag_products(dim_norm);
        CREATE INDEX IF NOT EXISTS idx_rag_price ON rag_products(prix_ht);
        CREATE INDEX IF NOT EXISTS idx_rag_cat ON rag_products(catalogue_id,page,line_no);
        CREATE VIRTUAL TABLE IF NOT EXISTS rag_products_fts USING fts5(
          description,family,product_type,universe,dimensions,reference,attributes,family_context,options,raw_text,
          content='rag_products',content_rowid='id',tokenize='unicode61 remove_diacritics 2'
        );
        CREATE TRIGGER IF NOT EXISTS rag_ai AFTER INSERT ON rag_products BEGIN
          INSERT INTO rag_products_fts(rowid,description,family,product_type,universe,dimensions,reference,attributes,family_context,options,raw_text)
          VALUES(new.id,coalesce(new.description,''),coalesce(new.family,''),coalesce(new.product_type,''),coalesce(new.universe,''),
                 coalesce(new.dimensions,''),coalesce(new.reference,''),coalesce(new.attributes,''),coalesce(new.family_context,''),
                 coalesce(new.options,''),new.raw_text);
        END;
        CREATE TRIGGER IF NOT EXISTS rag_ad AFTER DELETE ON rag_products BEGIN
          INSERT INTO rag_products_fts(rag_products_fts,rowid,description,family,product_type,universe,dimensions,reference,attributes,family_context,options,raw_text)
          VALUES('delete',old.id,coalesce(old.description,''),coalesce(old.family,''),coalesce(old.product_type,''),coalesce(old.universe,''),
                 coalesce(old.dimensions,''),coalesce(old.reference,''),coalesce(old.attributes,''),coalesce(old.family_context,''),
                 coalesce(old.options,''),old.raw_text);
        END;
        CREATE TRIGGER IF NOT EXISTS rag_au AFTER UPDATE ON rag_products BEGIN
          INSERT INTO rag_products_fts(rag_products_fts,rowid,description,family,product_type,universe,dimensions,reference,attributes,family_context,options,raw_text)
          VALUES('delete',old.id,coalesce(old.description,''),coalesce(old.family,''),coalesce(old.product_type,''),coalesce(old.universe,''),
                 coalesce(old.dimensions,''),coalesce(old.reference,''),coalesce(old.attributes,''),coalesce(old.family_context,''),
                 coalesce(old.options,''),old.raw_text);
          INSERT INTO rag_products_fts(rowid,description,family,product_type,universe,dimensions,reference,attributes,family_context,options,raw_text)
          VALUES(new.id,coalesce(new.description,''),coalesce(new.family,''),coalesce(new.product_type,''),coalesce(new.universe,''),
                 coalesce(new.dimensions,''),coalesce(new.reference,''),coalesce(new.attributes,''),coalesce(new.family_context,''),
                 coalesce(new.options,''),new.raw_text);
        END;
        CREATE TABLE IF NOT EXISTS document_decisions(
          path TEXT PRIMARY KEY,size_bytes INTEGER NOT NULL,mtime_ns INTEGER NOT NULL,
          decision TEXT NOT NULL,decided_at TEXT NOT NULL
        );
        """)
        conn.commit()


def _source_signature() -> str:
    with db() as conn:
        r = conn.execute("SELECT count(*) n,coalesce(max(id),0) mx,coalesce(sum(size_bytes),0) sz,coalesce(max(updated_at),'') up FROM catalogues").fetchone()
        l = conn.execute("SELECT count(*) n,coalesce(max(id),0) mx FROM lines").fetchone()
        b = conn.execute("SELECT count(*) n,coalesce(max(id),0) mx FROM product_blocks").fetchone()
    raw = f"{r['n']}:{r['mx']}:{r['sz']}:{r['up']}:{l['n']}:{l['mx']}:{b['n']}:{b['mx']}:{FINAL_RAG_VERSION}"
    return __import__('hashlib').sha256(raw.encode()).hexdigest()


def infer_product_type(text: str) -> str | None:
    n = normalize(text)
    # Specific types must win over generic words such as 'siège'.
    priority = ["chauffeuse", "fauteuil", "banquette", "canape", "chaise", "table", "bureau", "armoire",
                "caisson", "desserte", "tabouret", "pouf", "banc", "lit", "etagere", "rayonnage", "porte-manteaux", "meuble"]
    for canonical in priority:
        for word in PRODUCT_TYPE_SYNONYMS.get(canonical, []):
            nw = normalize(word)
            if re.search(rf"(?<!\w){re.escape(nw)}(?!\w)", n):
                return canonical
    return None


def detect_universe(text: str) -> str | None:
    n = normalize(text)
    for canonical, words in UNIVERSE_SYNONYMS.items():
        if any(re.search(rf"(?<!\w){re.escape(normalize(w))}(?!\w)", n) for w in words):
            return canonical
    return None


def _page_section_context(items: list[tuple[int, str]], product_line: int) -> dict:
    if not items:
        return {"family": None, "context": None, "options": None, "universe": None}
    idx = min(range(len(items)), key=lambda i: abs(items[i][0] - product_line))
    ti, title = _nearest_family_title(items, idx)
    sep_idx = -1
    for i in range(idx - 1, max(-1, idx - 180), -1):
        if _is_dotted_separator(items[i][1]):
            sep_idx = i
            break
    lo = max(0, ti if ti >= 0 else sep_idx if sep_idx >= 0 else idx - 20)
    notes = []
    for j in range(lo, idx):
        t = _clean_option_text(items[j][1])
        if not t or t == title or _is_dotted_separator(t) or detect_reference(t) or _is_product_row(t) or _is_option_start(t):
            continue
        if re.search(r"(?i)^(description|dimensions|plateau|panneau|chant|gen\.?\s*lafa|ref\.?|prix|eco)\b", t):
            continue
        if len(t) <= 180 and (':' in t or re.search(r"(?i)\b(livr[eé]|mont[eé]|epoxy|[eé]poxy|finition|coloris|structure|assise|dossier|garantie|usage|classe|enseignement|maternelle|rouge|jaune|bleu|vert|noir|blanc|gris)\b", t)):
            notes.append(t)
    option_parts = _option_block_for_product(items, idx)
    universe = None
    for _, t in reversed(items[lo:idx + 1]):
        universe = detect_universe(t)
        if universe:
            break
    return {
        "family": title or None,
        "context": " | ".join(dict.fromkeys(notes[-8:])) or None,
        "options": " ".join(option_parts) if option_parts else None,
        "universe": universe,
    }

def rebuild_rag_projection(force: bool = False) -> int:
    """Build a denormalized, fast product RAG projection from the existing SQLite index.
    No supplier document is reread. Description/family/reference are identity fields;
    plateau/panel/edge/finish/color/options remain secondary attributes.
    """
    ensure_final_schema()
    ensure_product_blocks(force=False)
    signature = _source_signature()
    with db() as conn:
        old = conn.execute("SELECT value FROM app_meta WHERE key='final_rag_signature'").fetchone()
        count = conn.execute("SELECT count(*) FROM rag_products").fetchone()[0]
        if not force and old and old[0] == signature and count:
            return int(count)
        blocks = conn.execute("""SELECT b.catalogue_id,b.page,b.anchor_line line_no,b.reference,b.designation,b.dimensions,
                                      b.prix_ht,b.eco_autre,b.text raw_text
                               FROM product_blocks b LEFT JOIN page_meta pm ON pm.catalogue_id=b.catalogue_id AND pm.page=b.page
                               WHERE b.reference IS NOT NULL AND b.prix_ht IS NOT NULL AND coalesce(pm.searchable_product,1)=1
                               ORDER BY b.catalogue_id,b.page,b.anchor_line""").fetchall()
        exact_rows = conn.execute("""SELECT p.catalogue_id,p.page,p.line_no,p.reference,p.designation,p.dimensions,p.prix_ht,p.eco_autre,p.raw_text
                                   FROM products p LEFT JOIN page_meta pm ON pm.catalogue_id=p.catalogue_id AND pm.page=p.page
                                   WHERE p.reference IS NOT NULL AND p.prix_ht IS NOT NULL AND coalesce(pm.searchable_product,1)=1
                                   ORDER BY p.catalogue_id,p.page,p.line_no""").fetchall()

    exact_map = {}
    for r in exact_rows:
        key = (int(r['catalogue_id']), str(r['reference']).upper())
        exact_map.setdefault(key, dict(r))

    candidates = []
    seen = set()
    for r in list(blocks) + list(exact_rows):
        d = dict(r)
        ref = str(d.get('reference') or '').strip()
        if not ref:
            continue
        key = (int(d['catalogue_id']), ref.upper())
        if key in seen:
            continue
        seen.add(key)
        ex = exact_map.get(key)
        if ex:
            # Exact one-row extraction is the best source for secondary columns.
            d['_exact_raw'] = ex.get('raw_text')
            if not d.get('designation'):
                d['designation'] = ex.get('designation')
            if not d.get('dimensions'):
                d['dimensions'] = ex.get('dimensions')
            if d.get('prix_ht') is None:
                d['prix_ht'] = ex.get('prix_ht')
            if d.get('eco_autre') is None:
                d['eco_autre'] = ex.get('eco_autre')
        candidates.append(d)

    pages_by_cat: dict[int, set[int]] = {}
    for d in candidates:
        pages_by_cat.setdefault(int(d['catalogue_id']), set()).add(int(d['page']))
    page_items: dict[tuple[int, int], list[tuple[int, str]]] = {}
    with db() as conn:
        for cat_id, pages in pages_by_cat.items():
            pgs = sorted(pages)
            for start in range(0, len(pgs), 150):
                chunk = pgs[start:start + 150]
                qs = ','.join('?' for _ in chunk)
                rows = conn.execute(f"SELECT page,line_no,text FROM lines WHERE catalogue_id=? AND page IN ({qs}) ORDER BY page,line_no",
                                    [cat_id, *chunk]).fetchall()
                for row in rows:
                    page_items.setdefault((cat_id, int(row['page'])), []).append((int(row['line_no']), clean_line(row['text'] or '')))

    inserts = []
    for d in candidates:
        cat_id, page, line_no = int(d['catalogue_id']), int(d['page']), int(d['line_no'])
        raw = str(d.get('_exact_raw') or d.get('raw_text') or '')
        parsed = parse_product_line(raw) or {}
        # The exact row is the identity source of truth. product_blocks can contain neighbouring
        # annotations such as "appui sur table", colors or options and must not redefine the product.
        exact_identity = bool(d.get('_exact_raw')) and bool(parsed.get('price_verified'))
        description = str((parsed.get('designation') if exact_identity else None) or d.get('designation') or parsed.get('designation') or '').strip() or None
        dimensions = str((parsed.get('dimensions') if exact_identity else None) or d.get('dimensions') or parsed.get('dimensions') or '').strip() or None
        section = _page_section_context(page_items.get((cat_id, page), []), line_no)
        family = section.get('family')
        context = section.get('context')
        options = section.get('options')
        universe = section.get('universe') or detect_universe(' '.join(x for x in [description, family, context] if x))
        product_type = infer_product_type(description or '') or infer_product_type(family or '')
        plateau = parsed.get('plateau')
        panneau = parsed.get('panneau')
        chant = parsed.get('chant')
        gen_lafa = parsed.get('gen_lafa')
        finition = parsed.get('finition')
        coloris = parsed.get('coloris')
        attributes = ' | '.join(str(x) for x in [plateau, panneau, chant, gen_lafa, finition, coloris] if x)
        ref = str(d.get('reference') or parsed.get('reference') or '').strip()
        try:
            price = float(d.get('prix_ht'))
        except Exception:
            continue
        try:
            eco = float(d.get('eco_autre')) if d.get('eco_autre') is not None else None
        except Exception:
            eco = None
        source_key = f"{cat_id}:{ref.upper()}"
        inserts.append((source_key, cat_id, page, line_no, description, normalize(description or ''), product_type,
                        family, normalize(family or ''), universe, dimensions, _norm_dim(dimensions or ''), plateau,
                        panneau, chant, gen_lafa, finition, coloris, ref, price, eco, context, options, attributes,
                        str(d.get('raw_text') or raw), utcnow()))

    with db() as conn:
        conn.execute("DELETE FROM rag_products")
        conn.executemany("""INSERT OR REPLACE INTO rag_products(
            source_key,catalogue_id,page,line_no,description,description_norm,product_type,family,family_norm,universe,
            dimensions,dim_norm,plateau,panneau,chant,gen_lafa,finition,coloris,reference,prix_ht,eco,family_context,options,attributes,raw_text,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", inserts)
        conn.execute("INSERT INTO rag_products_fts(rag_products_fts) VALUES('rebuild')")
        conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('final_rag_signature',?)", (signature,))
        conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('final_rag_version',?)", (FINAL_RAG_VERSION,))
        conn.execute("ANALYZE")
        conn.execute("PRAGMA optimize")
        conn.commit()
    return len(inserts)


def ensure_rag_projection(force: bool = False) -> int:
    try:
        return rebuild_rag_projection(force=force)
    except Exception:
        if force:
            raise
        return 0


def _find_product_type(qn: str) -> str | None:
    return infer_product_type(qn)


def _find_color(qn: str) -> str | None:
    for canonical, words in V4_COLOR_WORDS.items():
        if any(re.search(rf"(?<!\w){re.escape(normalize(w))}(?!\w)", qn) for w in words):
            return canonical
    return None


def _find_finish(qn: str) -> str | None:
    """Recognise finishes robustly, including common typing variants such as 'epoxyl'."""
    n = normalize(qn)
    for canonical, aliases in FINISH_ALIASES.items():
        for alias in aliases:
            a = normalize(alias)
            if re.search(rf"(?<!\w){re.escape(a)}(?!\w)", n):
                return canonical
    if any(tok.startswith("epox") for tok in re.findall(r"[a-z0-9]+", n)):
        return "epoxy"
    return None


def _find_universe(qn: str) -> str | None:
    return detect_universe(qn)


def _extract_places(qn: str) -> int | None:
    m = re.search(r"\b(\d{1,2})\s*(?:place|places|pl)\b", qn)
    if m:
        return int(m.group(1))
    for w, n in NUMBER_WORDS.items():
        if re.search(rf"\b{re.escape(w)}\s+places?\b", qn):
            return n
    if "biplace" in qn:
        return 2
    return None


def _extract_age(qn: str) -> int | None:
    m = re.search(r"\b(\d{1,2})\s*ans?\b", qn)
    return int(m.group(1)) if m else None


def _extract_quantity(qn: str) -> int | None:
    m = re.search(r"\b(?:il m[ '\u2019]en faut|j[ '\u2019]en veux|quantite|quantité|qte|qté)\s*(\d{1,4})\b", qn)
    if m:
        return int(m.group(1))
    return None


def _query_has_search_verb(qn: str) -> bool:
    return any(x in qn for x in ("cherche", "recherche", "trouve", "trouver", "montre moi", "montrez moi", "je veux", "je voudrais", "besoin de", "nouvelle recherche"))


def parse_rag_intent(question: str, previous: dict | None = None, allow_llm: bool = True) -> dict:
    q = str(question or '').strip()
    qn = normalize(q)
    refm = PRODUCT_REF_RE.search(q.upper())
    dm = re.search(r"(?<!\d)(\d{2,4})\s*[x×X/]\s*(\d{2,4})(?:\s*[x×X/]\s*(\d{2,4}))?", q)
    pmax = re.search(r"(?:moins de|max(?:imum)?|sous|jusqu.?a)\s*(\d+(?:[.,]\d+)?)\s*€?", qn)
    pmin = re.search(r"(?:plus de|min(?:imum)?|a partir de)\s*(\d+(?:[.,]\d+)?)\s*€?", qn)
    product_type = _find_product_type(qn)
    color = _find_color(qn)
    universe = _find_universe(qn)
    places = _extract_places(qn)
    age = _extract_age(qn)
    quantity = _extract_quantity(qn)
    show_all = any(x in qn for x in ("affiche tout", "afficher tout", "montre tout", "liste complete", "liste complète", "tous les", "toutes les"))
    sort = None
    if any(x in qn for x in ("moins cher", "moins chere", "moins chère", "prix croissant")):
        sort = "price_asc"
    elif any(x in qn for x in ("plus cher", "plus chere", "plus chère", "prix decroissant", "prix décroissant")):
        sort = "price_desc"
    finish = _find_finish(qn)

    remove_tokens = set()
    for words in PRODUCT_TYPE_SYNONYMS.values():
        remove_tokens.update(normalize(w) for phrase in words for w in normalize(phrase).split())
    for words in UNIVERSE_SYNONYMS.values():
        remove_tokens.update(normalize(w) for phrase in words for w in normalize(phrase).split())
    for words in V4_COLOR_WORDS.values():
        remove_tokens.update(normalize(w) for phrase in words for w in normalize(phrase).split())
    remove_tokens.update(normalize(x) for x in FINISH_TERMS)
    remove_tokens |= SEARCH_FILLER
    if places or age or quantity:
        remove_tokens.update(NUMBER_WORDS.keys())
    words = [w for w in re.findall(r"[a-z0-9_-]{2,}", qn) if w not in remove_tokens]
    dim_nums = set(re.findall(r"\d+", dm.group(0))) if dm else set()
    core_terms = []
    for w in words:
        if w in dim_nums:
            continue
        if w.isdigit() and (len(w) >= 3 or places or age or quantity):
            continue
        if w not in core_terms:
            core_terms.append(w)

    previous = previous or {}
    mode = "new"
    if previous:
        if show_all:
            mode = "refine"
        elif _query_has_search_verb(qn):
            mode = "new"
        elif product_type and previous.get("product_type") and product_type != previous.get("product_type"):
            mode = "new"
        elif refm:
            mode = "new"
        elif len(q.split()) <= 8 or any(x in qn for x in ("seulement", "uniquement", "garde", "avec", "sans", "moins cher", "plus cher")):
            mode = "refine"

    intent = {
        "mode": mode,
        "product_type": product_type,
        "reference": refm.group(0).upper() if refm else None,
        "dimensions": _norm_dim('x'.join(x for x in dm.groups() if x)) if dm else None,
        "color": color,
        "finish": finish,
        "universe": universe,
        "places": places,
        "age": age,
        "quantity": quantity,
        "price_min": float(pmin.group(1).replace(',', '.')) if pmin else None,
        "price_max": float(pmax.group(1).replace(',', '.')) if pmax else None,
        "sort": sort,
        "show_all": show_all,
        "core_terms": core_terms[:8],
        "raw": q,
    }

    if allow_llm and len(q.split()) >= 4 and not intent["reference"]:
        allowed_types = sorted(PRODUCT_TYPE_SYNONYMS)
        prompt = f"""Analyse une demande de recherche de mobilier. Retourne UNIQUEMENT JSON avec les champs:
product_type, family, universe, color, finish, dimensions, places, mode.
product_type doit être null ou l'une de: {allowed_types}.
mode vaut new si l'utilisateur change de produit/recherche, refine s'il affine le résultat précédent.
N'invente aucune référence, prix ou caractéristique.
Demande: {q}
Contexte précédent (peut être vide): {json.dumps(previous,ensure_ascii=False)}"""
        obj, _ = v4_llm_json(prompt, 220)
        if isinstance(obj, dict):
            pt = normalize(str(obj.get("product_type") or ""))
            if not intent["product_type"] and pt in PRODUCT_TYPE_SYNONYMS:
                intent["product_type"] = pt
            fam = normalize(str(obj.get("family") or "")).strip()
            if fam and fam not in ("null", "none") and not intent["core_terms"]:
                intent["core_terms"] = [x for x in re.findall(r"[a-z0-9_-]{2,}", fam) if x not in SEARCH_FILLER][:4]
            uni = normalize(str(obj.get("universe") or ""))
            if not intent["universe"] and uni in UNIVERSE_SYNONYMS:
                intent["universe"] = uni
            col = normalize(str(obj.get("color") or ""))
            if not intent["color"] and col in V4_COLOR_WORDS:
                intent["color"] = col
            if not intent["finish"] and obj.get("finish"):
                intent["finish"] = normalize(str(obj.get("finish")))
            if not intent["dimensions"] and obj.get("dimensions"):
                intent["dimensions"] = _norm_dim(str(obj.get("dimensions")))
            if not intent["places"]:
                try:
                    intent["places"] = int(obj.get("places")) if obj.get("places") is not None else None
                except Exception:
                    pass
            if previous and not _query_has_search_verb(qn) and str(obj.get("mode") or "").lower() == "refine":
                intent["mode"] = "refine"
    return intent


def _rag_fts_or_query(terms: list[str]) -> str:
    safe = []
    for t in terms:
        t = re.sub(r'[^\w.-]+', '', normalize(t)).replace('"', '')
        if t:
            safe.append(f'"{t}"*')
    return " OR ".join(safe[:12])


def _row_blob(row, fields) -> str:
    return normalize(" ".join(str(row.get(c) or '') for c in fields))


def _place_match(n: int, blob: str) -> bool:
    # Never match a bare digit: references such as COLT2 or dimensions would create false positives.
    if n == 1:
        words = ["1 place", "une place", "monoplace"]
    elif n == 2:
        words = ["2 places", "2 place", "deux places", "biplace"]
    else:
        words = [f"{n} places", f"{n} place"]
    b=normalize(blob)
    return any(normalize(w) in b for w in words)


def rag_score_candidate(intent: dict, row) -> float:
    desc = normalize(str(row.get("Description") or row.get("Désignation") or ''))
    fam = normalize(str(row.get("_family") or ''))
    ident = f"{desc} {fam} {normalize(str(row.get('Référence') or ''))}".strip()
    attrs = _row_blob(row, ["Dimensions", "Plateau", "Panneau", "Chant", "GEN. LAFA", "Finition", "Coloris", "_family_context", "_options", "_hit"])
    score = 0.0
    ref = normalize(str(row.get("Référence") or ''))
    if intent.get("reference"):
        ir = normalize(intent["reference"])
        if ref == ir:
            score += 5000
        elif ref.startswith(ir):
            score += 4000
        else:
            return -100000
    ptype = intent.get("product_type")
    if ptype:
        actual = normalize(str(row.get("_product_type") or infer_product_type(desc) or infer_product_type(fam) or ''))
        if actual == ptype:
            score += 1400
        else:
            return -100000
    for term in intent.get("core_terms") or []:
        nt = normalize(term)
        if nt in desc:
            score += 520
        elif nt in fam:
            score += 440
        elif nt in attrs:
            score += 110
        else:
            fuzz_identity = max(fuzz.partial_ratio(nt, desc), fuzz.partial_ratio(nt, fam))
            if fuzz_identity >= 90:
                score += 320
            elif fuzz_identity >= 78:
                score += 150
            else:
                score -= 160
    if intent.get("dimensions"):
        if str(row.get("_dim_norm") or _norm_dim(str(row.get("Dimensions") or ''))) == intent["dimensions"]:
            score += 900
        else:
            score -= 450
    if intent.get("universe"):
        uni = normalize(str(row.get("_universe") or ''))
        if uni == intent["universe"] or any(normalize(w) in attrs + ' ' + fam + ' ' + desc for w in UNIVERSE_SYNONYMS.get(intent["universe"], [])):
            score += 300
    if intent.get("color"):
        words = V4_COLOR_WORDS.get(intent["color"], [intent["color"]])
        if any(normalize(w) in attrs for w in words):
            score += 190
    if intent.get("finish") and normalize(intent["finish"]) in attrs:
        score += 180
    if intent.get("places") and _place_match(int(intent["places"]), ident + ' ' + attrs):
        score += 300
    # Description is the primary free-text match. Secondary fields cannot compensate for a wrong product identity.
    q_identity = ' '.join(([intent.get("product_type")] if intent.get("product_type") else []) + list(intent.get("core_terms") or []))
    if q_identity:
        score += 2.5 * fuzz.token_set_ratio(normalize(q_identity), desc + ' ' + fam)
    try:
        if row.get("Prix HT") is not None and not pd.isna(row.get("Prix HT")):
            score += 25
    except Exception:
        pass
    return score


def _rag_df_from_sql(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    x = df.rename(columns={
        "description": "Description", "dimensions": "Dimensions", "plateau": "Plateau", "panneau": "Panneau",
        "chant": "Chant", "gen_lafa": "GEN. LAFA", "reference": "Référence", "prix_ht": "Prix HT",
        "eco": "Éco", "page": "Page", "line_no": "Ligne", "catalogue": "Catalogue",
        "finition": "Finition", "coloris": "Coloris", "family": "_family", "family_context": "_family_context",
        "options": "_options", "raw_text": "_hit", "product_type": "_product_type", "universe": "_universe", "dim_norm": "_dim_norm"
    }).copy()
    return x


def rag_retrieve(question: str, limit: int = 500, catalogue: str | None = None,
                 previous_intent: dict | None = None, mode: str | None = None) -> tuple[pd.DataFrame, dict]:
    ensure_rag_projection(False)
    intent = parse_rag_intent(question, previous_intent, allow_llm=True)
    if mode:
        intent["mode"] = mode
    with db() as conn:
        base_select = """SELECT r.description,r.product_type,r.family,r.universe,r.dimensions,r.dim_norm,r.plateau,r.panneau,r.chant,
            r.gen_lafa,r.finition,r.coloris,r.reference,r.prix_ht,r.eco,r.page,r.line_no,c.name catalogue,
            r.family_context,r.options,r.raw_text FROM rag_products r JOIN catalogues c ON c.id=r.catalogue_id"""
        params = []
        wh = ["r.reference IS NOT NULL", "r.prix_ht IS NOT NULL"]
        if catalogue:
            wh.append("c.name=?")
            params.append(catalogue)
        if intent.get("reference"):
            ir = re.sub(r'[^A-Z0-9]', '', str(intent['reference']).upper())
            wh.append("replace(replace(upper(r.reference),'-',''),' ','') LIKE ?")
            params.append(ir + '%')
            sql = base_select + " WHERE " + " AND ".join(wh) + " ORDER BY r.reference LIMIT ?"
            params.append(max(limit, 200))
            raw = pd.read_sql_query(sql, conn, params=params)
        elif intent.get("product_type"):
            ptype = intent["product_type"]
            # Identity is a hard filter. "Chaise ... appui sur table" remains a chair.
            wh.append("r.product_type=?")
            params.append(ptype)
            sql = base_select + " WHERE " + " AND ".join(wh) + " LIMIT 5000"
            raw = pd.read_sql_query(sql, conn, params=params)
        else:
            fterms = list(intent.get("core_terms") or [])
            if intent.get("universe"):
                fterms += UNIVERSE_SYNONYMS.get(intent["universe"], [])[:2]
            if intent.get("color"):
                fterms += V4_COLOR_WORDS.get(intent["color"], [])[:1]
            fq = _rag_fts_or_query(fterms or meaningful_terms(question))
            if fq:
                cat_clause = " AND c.name=?" if catalogue else ""
                vals = [fq] + ([catalogue] if catalogue else []) + [5000]
                raw = pd.read_sql_query("""SELECT r.description,r.product_type,r.family,r.universe,r.dimensions,r.dim_norm,r.plateau,r.panneau,r.chant,
                    r.gen_lafa,r.finition,r.coloris,r.reference,r.prix_ht,r.eco,r.page,r.line_no,c.name catalogue,
                    r.family_context,r.options,r.raw_text
                    FROM rag_products_fts f JOIN rag_products r ON r.id=f.rowid JOIN catalogues c ON c.id=r.catalogue_id
                    WHERE rag_products_fts MATCH ?""" + cat_clause + " ORDER BY bm25(rag_products_fts,12,10,10,3,8,15,2,1,1,1) LIMIT ?", conn, params=vals)
            else:
                sql = base_select + (" WHERE c.name=?" if catalogue else "") + " LIMIT 5000"
                raw = pd.read_sql_query(sql, conn, params=[catalogue] if catalogue else [])

    df = _rag_df_from_sql(raw)
    if df.empty:
        return df, intent

    # Product type is an identity constraint, never a ranking hint.
    if intent.get("product_type"):
        wanted = normalize(intent["product_type"])
        type_mask = []
        for _, r in df.iterrows():
            actual = normalize(str(r.get("_product_type") or infer_product_type(str(r.get("Description") or "")) or ""))
            type_mask.append(actual == wanted)
        df = df[pd.Series(type_mask, index=df.index)]
        if df.empty:
            return df, intent

    # Price constraints are hard facts.
    if intent.get("price_min") is not None:
        df = df[pd.to_numeric(df["Prix HT"], errors="coerce") >= float(intent["price_min"])]
    if intent.get("price_max") is not None:
        df = df[pd.to_numeric(df["Prix HT"], errors="coerce") <= float(intent["price_max"])]
    if df.empty:
        return df, intent

    # Dimensions and number of places are primary discriminators when explicitly requested.
    if intent.get("dimensions"):
        m = df["_dim_norm"].fillna("").astype(str) == str(intent["dimensions"])
        if not m.any():
            return pd.DataFrame(), intent
        df = df[m]
    if intent.get("places"):
        masks = []
        for _, r in df.iterrows():
            blob = _row_blob(r, ["Description", "_family", "_family_context", "_options", "_hit"])
            masks.append(_place_match(int(intent["places"]), blob))
        m = pd.Series(masks, index=df.index)
        if not m.any():
            return pd.DataFrame(), intent
        df = df[m]

    # Color is secondary: filter when the catalogue explicitly supports it, otherwise retain core products and flag it.
    if intent.get("color"):
        words = V4_COLOR_WORDS.get(intent["color"], [intent["color"]])
        cmask = []
        for _, r in df.iterrows():
            blob = _row_blob(r, ["Coloris", "Finition", "_family_context", "_options", "_hit"])
            cmask.append(any(normalize(w) in blob for w in words))
        cmask = pd.Series(cmask, index=df.index)
        if cmask.any():
            df = df[cmask]
            intent["color_verified"] = True
        else:
            intent["color_verified"] = False
            if intent.get("mode") == "refine":
                return pd.DataFrame(), intent

    if intent.get("universe"):
        umask=[]
        for _, r in df.iterrows():
            blob=_row_blob(r,["Description","_family","_family_context","_options","_hit"])
            umask.append(normalize(str(r.get("_universe") or ""))==intent["universe"] or any(normalize(w) in blob for w in UNIVERSE_SYNONYMS.get(intent["universe"],[])))
        umask=pd.Series(umask,index=df.index)
        if umask.any(): df=df[umask]
    if intent.get("finish"):
        fmask=[]
        for _, r in df.iterrows():
            blob=_row_blob(r,["Finition","Plateau","Panneau","Chant","_family_context","_options","_hit"])
            fmask.append(normalize(intent["finish"]) in blob)
        fmask=pd.Series(fmask,index=df.index)
        if fmask.any(): df=df[fmask]
        elif intent.get("mode")=="refine": return pd.DataFrame(), intent

    scores = [rag_score_candidate(intent, r) for _, r in df.iterrows()]
    df = df.copy()
    df["_rag_score"] = scores
    df = df[df["_rag_score"] > -50000]
    if df.empty:
        return df, intent

    # Family/core terms are identity constraints if the corpus contains explicit matches.
    terms = intent.get("core_terms") or []
    if terms:
        strong = []
        for _, r in df.iterrows():
            identity = normalize(' '.join(str(r.get(c) or '') for c in ["Description", "_family", "Référence"]))
            ok = all((normalize(t) in identity) or max(fuzz.partial_ratio(normalize(t), normalize(str(r.get("Description") or ''))),
                                                       fuzz.partial_ratio(normalize(t), normalize(str(r.get("_family") or '')))) >= 82 for t in terms)
            strong.append(ok)
        strong = pd.Series(strong, index=df.index)
        if strong.any():
            df = df[strong]
        elif intent.get("product_type"):
            # Keep same product type only; low-scoring secondary matches cannot bring another family to the top.
            df = df.sort_values("_rag_score", ascending=False)
        else:
            df = df[df["_rag_score"] >= 150]

    if intent.get("sort") == "price_asc":
        df = df.sort_values(["Prix HT", "_rag_score"], ascending=[True, False], na_position="last")
    elif intent.get("sort") == "price_desc":
        df = df.sort_values(["Prix HT", "_rag_score"], ascending=[False, False], na_position="last")
    else:
        df = df.sort_values("_rag_score", ascending=False)

    df = df.drop_duplicates(subset=["Catalogue", "Référence"], keep="first").head(max(1, min(limit, 500)))
    return add_pdf_links(df), intent


def filter_rag_pool(question: str, pool: pd.DataFrame, previous_intent: dict) -> tuple[pd.DataFrame, dict]:
    intent = parse_rag_intent(question, previous_intent, allow_llm=True)
    intent["mode"] = "refine"
    if pool is None or pool.empty:
        return pd.DataFrame(), intent
    if intent.get("show_all") and not any([intent.get("product_type"), intent.get("dimensions"), intent.get("color"), intent.get("finish"), intent.get("places"), intent.get("core_terms")]):
        return pool.copy(), intent
    df = pool.copy()
    # New product type inside a refinement request is actually a new search.
    if intent.get("product_type") and previous_intent.get("product_type") and intent["product_type"] != previous_intent.get("product_type"):
        intent["mode"] = "new"
        return rag_retrieve(question, 500, previous_intent=previous_intent, mode="new")

    masks = []
    for _, r in df.iterrows():
        ident = normalize(' '.join(str(r.get(c) or '') for c in ["Description", "_family", "Référence"]))
        attrs = _row_blob(r, ["Dimensions", "Plateau", "Panneau", "Chant", "GEN. LAFA", "Finition", "Coloris", "_family_context", "_options", "_hit"])
        ok = True
        if intent.get("product_type"):
            actual = normalize(str(r.get("_product_type") or infer_product_type(ident) or ''))
            ok = ok and actual == intent["product_type"]
        if intent.get("dimensions"):
            ok = ok and str(r.get("_dim_norm") or _norm_dim(str(r.get("Dimensions") or ''))) == intent["dimensions"]
        if intent.get("places"):
            ok = ok and _place_match(int(intent["places"]), ident + ' ' + attrs)
        if intent.get("color"):
            ok = ok and any(normalize(w) in attrs for w in V4_COLOR_WORDS.get(intent["color"], [intent["color"]]))
        if intent.get("finish"):
            ok = ok and normalize(intent["finish"]) in attrs
        if intent.get("universe"):
            universe_match = normalize(str(r.get("_universe") or '')) == intent["universe"] or any(normalize(w) in attrs + ' ' + ident for w in UNIVERSE_SYNONYMS.get(intent["universe"], []))
            ok = ok and universe_match
        for term in intent.get("core_terms") or []:
            nt = normalize(term)
            ok = ok and (nt in ident or nt in attrs or fuzz.partial_ratio(nt, ident) >= 85)
        try:
            price = float(r.get("Prix HT"))
        except Exception:
            price = None
        if intent.get("price_min") is not None:
            ok = ok and price is not None and price >= float(intent["price_min"])
        if intent.get("price_max") is not None:
            ok = ok and price is not None and price <= float(intent["price_max"])
        masks.append(ok)
    out = df[pd.Series(masks, index=df.index)]
    if out.empty:
        return out, intent
    if intent.get("sort") == "price_asc":
        out = out.sort_values("Prix HT", ascending=True, na_position="last")
    elif intent.get("sort") == "price_desc":
        out = out.sort_values("Prix HT", ascending=False, na_position="last")
    return out, intent


def v4_assistant(question, limit=200):
    state = st.session_state.get("assistant_rag_state") or {}
    previous_pool = state.get("pool") if isinstance(state.get("pool"), pd.DataFrame) else pd.DataFrame()
    previous_intent = state.get("intent") or {}
    pre = parse_rag_intent(question, previous_intent, allow_llm=False)
    if previous_pool is not None and not previous_pool.empty and pre.get("mode") == "refine":
        df, intent = filter_rag_pool(question, previous_pool, previous_intent)
    else:
        df, intent = rag_retrieve(question, max(limit, 500), previous_intent=previous_intent, mode="new")
    # Never silently restore an old pool after a failed refinement.
    if df is None:
        df = pd.DataFrame()
    st.session_state["assistant_rag_state"] = {"pool": df.copy(), "intent": intent, "base_query": question}
    base = f"{len(df)} référence(s) vérifiée(s) dans le pool actif." if not df.empty else "Aucune référence suffisamment pertinente dans le pool actif."
    return df.head(max(1, min(limit, 500))), base, intent, "RAG SQLite + IA locale"


def assistant_conversation_answer(question, df, base_answer, intent=None):
    intent = intent or (st.session_state.get("assistant_rag_state") or {}).get("intent") or {}
    if df is None or df.empty:
        qualifiers = []
        if intent.get("dimensions"): qualifiers.append("dimensions " + str(intent["dimensions"]))
        if intent.get("places"): qualifiers.append(f"{intent['places']} place(s)")
        if intent.get("color"): qualifiers.append("coloris " + str(intent["color"]))
        suffix = (" avec " + ", ".join(qualifiers)) if qualifiers else ""
        return "Je n’ai trouvé **aucune référence suffisamment pertinente**" + suffix + ". Je préfère ne pas proposer un article hors sujet. Modifiez un critère ou donnez une dimension/référence plus précise."
    total = len(df)
    if intent.get("show_all"):
        return f"Le pool actif contient **{total} référence(s) vérifiée(s)**. Je les affiche dans le tableau ci-dessous sans réintroduire les résultats éliminés par les filtres précédents."

    # Detect ambiguity by distinct dimensions/references. Ask rather than choosing arbitrarily.
    dims = [str(x) for x in df.get("Dimensions", pd.Series(dtype=str)).dropna().astype(str).unique().tolist() if str(x).strip()]
    quantity = intent.get("quantity")
    if total == 1:
        r = df.iloc[0]
        parts = [f"J’ai isolé **{r.get('Description') or 'le produit'}**", f"réf. **{r.get('Référence')}**"]
        if r.get("Dimensions") and not pd.isna(r.get("Dimensions")): parts.append(str(r.get("Dimensions")))
        try:
            price = float(r.get("Prix HT")); parts.append(f"**{price:.2f} € HT**".replace('.', ','))
            eco = r.get("Éco")
            if eco is not None and not pd.isna(eco): parts.append(f"éco {float(eco):.2f} €".replace('.', ','))
            if quantity:
                total_ht = quantity * (price + (float(eco) if eco is not None and not pd.isna(eco) else 0.0))
                parts.append(f"pour {quantity} : **{total_ht:.2f} € HT éco incluse**".replace('.', ','))
        except Exception:
            pass
        if intent.get("color") and intent.get("color_verified") is False:
            parts.append(f"coloris {intent['color']} : **à confirmer dans la gamme**")
        if r.get("_family_context") and not pd.isna(r.get("_family_context")): parts.append("gamme : " + str(r.get("_family_context")))
        if r.get("_options") and not pd.isna(r.get("_options")): parts.append("options : " + str(r.get("_options")))
        return " — ".join(parts) + "."

    facts = []
    for _, r in df.head(12).iterrows():
        facts.append({
            "description": None if pd.isna(r.get("Description")) else r.get("Description"),
            "dimensions": None if pd.isna(r.get("Dimensions")) else r.get("Dimensions"),
            "reference": None if pd.isna(r.get("Référence")) else r.get("Référence"),
            "prix_ht": None if pd.isna(r.get("Prix HT")) else r.get("Prix HT"),
            "eco": None if pd.isna(r.get("Éco")) else r.get("Éco"),
            "famille": None if pd.isna(r.get("_family")) else r.get("_family"),
            "contexte": None if pd.isna(r.get("_family_context")) else r.get("_family_context"),
            "options": None if pd.isna(r.get("_options")) else r.get("_options"),
        })
    prompt = f"""Tu es un assistant commercial local connecté à un RAG de catalogue.
La base de données est la source de vérité. Description et dimensions sont prioritaires; plateau, panneau, chant, finition, coloris et options sont secondaires.
Ne propose jamais un type de produit différent de la demande. Si plusieurs variantes restent possibles, pose UNE question utile (souvent la dimension, le nombre de places ou la finition) au lieu de choisir arbitrairement.
N'invente aucune référence, prix, disponibilité ou option. Les options ne modifient jamais automatiquement le prix.
Réponds en français, naturellement, en 4 à 8 lignes. Il y a {total} références dans le pool actif; n'affirme pas qu'il n'y en a que quelques-unes.
Intention: {json.dumps(intent,ensure_ascii=False)}
Produits vérifiés: {json.dumps(facts,ensure_ascii=False)}
Question: {question}"""
    obj, _ = v4_llm_json('Retourne uniquement JSON {"answer":"..."}.\n' + prompt, 650)
    if isinstance(obj, dict) and str(obj.get("answer") or '').strip():
        ans = str(obj["answer"]).strip()
    else:
        first = df.iloc[0]
        ans = f"J’ai trouvé **{total} référence(s) pertinentes**. Les meilleurs résultats appartiennent à **{first.get('Description') or first.get('_family') or 'la famille demandée'}**."
        if len(dims) > 1 and not intent.get("dimensions"):
            ans += " Plusieurs dimensions existent : précisez la dimension souhaitée pour sélectionner la bonne référence."
        else:
            ans += " Vous pouvez affiner par dimension, finition, couleur, nombre de places ou prix."
    if intent.get("color") and intent.get("color_verified") is False:
        ans += f" Le coloris **{intent['color']}** n’est pas explicitement confirmé dans les données rattachées à ces références : **à confirmer**."
    return ans


def _mail_quantity_from_text(text: str) -> int:
    n = normalize(text)
    # Explicit quantity markers first; bare model/dimension numbers must not become quantities.
    for pat in (r"\b(?:qte|qté|quantite|quantité)\s*[:=]?\s*(\d{1,4})\b",
                r"\b(\d{1,4})\s*(?:x|pcs?|pieces?|pi[eè]ces?|unit[eé]s?)\b"):
        m = re.search(pat, n)
        if m:
            return max(1, min(999, int(m.group(1))))
    # Natural phrasing: 'je cherche deux tables', 'il me faut trois chaises'.
    product_words = sorted({normalize(w) for words in PRODUCT_TYPE_SYNONYMS.values() for w in words}, key=len, reverse=True)
    for w, v in NUMBER_WORDS.items():
        if any(re.search(rf"\b{re.escape(w)}\s+(?:[a-z-]+\s+)?{re.escape(pw)}\b", n) for pw in product_words):
            return v
    m = re.search(r"(?:je cherche|je voudrais|il me faut|nous souhaitons)\s+(\d{1,3})\s+[a-zà-ÿ-]+", n)
    if m:
        return max(1, int(m.group(1)))
    return 1


def v4_resolve_client_mail(text, top_candidates=3):
    lines, mode = v4_extract_mail_lines(text)
    explicit = v4_explicit_qty_refs(text)
    if explicit:
        lines = explicit
    if not lines:
        lines = [{"quantity": _mail_quantity_from_text(text), "request": text, "reference": None}]
    lines = v4_merge_same_request_lines(lines)
    rows = []
    for item in lines:
        request = str(item.get("request") or item.get("reference") or '').strip()
        qty = max(1, int(item.get("quantity") or 1), _mail_quantity_from_text(request))
        if item.get("reference"):
            request = (request + " " + str(item.get("reference"))).strip()
        cand, intent = rag_retrieve(request, 50, previous_intent=None, mode="new")
        if cand.empty:
            rows.append({"Qté": qty, "Désignation": v4_client_designation(request, item.get("reference")), "Référence": "Non indexé",
                         "Prix HT": None, "Éco-participation": None, "Total HT": None, "Catalogue": None, "Page": None,
                         "Ligne": None, "Statut": "Non trouvé", "Confiance": 0, "Pourquoi": "Aucun produit de même identité suffisamment pertinent"})
            continue
        cand = cand.sort_values("_rag_score", ascending=False) if "_rag_score" in cand.columns else cand
        top = cand.iloc[0]
        top_score = float(top.get("_rag_score") or 0)
        second_score = float(cand.iloc[1].get("_rag_score") or 0) if len(cand) > 1 else -9999
        distinct_dims = [str(x) for x in cand.get("Dimensions", pd.Series(dtype=str)).dropna().astype(str).unique() if str(x).strip()]
        exact_ref = bool(intent.get("reference") and normalize(str(top.get("Référence"))) == normalize(str(intent.get("reference"))))
        strong_identity = bool(intent.get("product_type") or intent.get("core_terms")) and top_score >= 1000
        ambiguous_variant = len(cand) > 1 and (top_score - second_score < 120) and not intent.get("dimensions") and not exact_ref
        if len(distinct_dims) > 1 and not intent.get("dimensions") and not exact_ref:
            ambiguous_variant = True
        verified = exact_ref or (strong_identity and not ambiguous_variant and not (intent.get("color") and intent.get("color_verified") is False))
        status = "Vérifié" if verified else "À confirmer"
        reason = "Référence exacte" if exact_ref else ("Identité produit/gamme cohérente" if verified else "Plusieurs variantes ou caractéristique non confirmée")
        try: price = float(top.get("Prix HT"))
        except Exception: price = None
        try: eco = float(top.get("Éco")) if top.get("Éco") is not None and not pd.isna(top.get("Éco")) else 0.0
        except Exception: eco = 0.0
        total = round(qty * (price + eco), 2) if price is not None and verified else None
        rows.append({"Qté": qty, "Désignation": top.get("Description") or v4_client_designation(request, item.get("reference")),
                     "Référence": top.get("Référence"), "Prix HT": price if verified else None,
                     "Éco-participation": eco if verified else None, "Total HT": total,
                     "Catalogue": top.get("Catalogue"), "Page": top.get("Page"), "Ligne": top.get("Ligne"),
                     "Statut": status, "Confiance": round(top_score, 1), "Pourquoi": reason,
                     "PDF / Page": top.get("PDF / Page")})
        if not verified:
            for alt_i, (_, alt) in enumerate(cand.head(max(2, top_candidates)).iterrows(), start=1):
                try: ap = float(alt.get("Prix HT"))
                except Exception: ap = None
                try: ae = float(alt.get("Éco")) if alt.get("Éco") is not None and not pd.isna(alt.get("Éco")) else None
                except Exception: ae = None
                rows.append({"Qté": qty, "Désignation": alt.get("Description"), "Référence": alt.get("Référence"),
                             "Prix HT": ap, "Éco-participation": ae, "Total HT": None, "Catalogue": alt.get("Catalogue"),
                             "Page": alt.get("Page"), "Ligne": alt.get("Ligne"), "Statut": f"Alternative {alt_i}",
                             "Confiance": round(float(alt.get("_rag_score") or 0), 1), "Pourquoi": "À valider avant devis",
                             "PDF / Page": alt.get("PDF / Page")})
    return pd.DataFrame(rows), "RAG produit + IA locale"


def _verified_quote_rows(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty or "Statut" not in df.columns:
        return pd.DataFrame()
    return df[df["Statut"].astype(str) == "Vérifié"].copy()


def v4_make_quote_excel(resolved_df):
    primary = _verified_quote_rows(resolved_df)
    cols = ["Qté", "Désignation", "Référence", "Prix HT", "Éco-participation", "Total HT"]
    primary = primary[[c for c in cols if c in primary.columns]]
    bio = BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        primary.to_excel(writer, index=False, sheet_name="Devis")
        ws = writer.book["Devis"]
        widths = {"A": 8, "B": 46, "C": 22, "D": 15, "E": 19, "F": 17}
        for col, w in widths.items(): ws.column_dimensions[col].width = w
        for row in range(2, ws.max_row + 1):
            ws[f"D{row}"].number_format = '#,##0.00 [$€-fr-FR]'
            ws[f"E{row}"].number_format = '#,##0.00 [$€-fr-FR]'
            ws[f"F{row}"] = f'=IF(OR(D{row}="",A{row}=""),"",ROUND(A{row}*(D{row}+IF(E{row}="",0,E{row})),2))'
            ws[f"F{row}"].number_format = '#,##0.00 [$€-fr-FR]'
        total_row = ws.max_row + 2
        ws[f"E{total_row}"] = "TOTAL HT"
        ws[f"F{total_row}"] = f"=ROUND(SUM(F2:F{ws.max_row}),2)"
        ws[f"F{total_row}"].number_format = '#,##0.00 [$€-fr-FR]'
        ws.freeze_panes = "A2"
        if ws.max_row >= 1: ws.auto_filter.ref = f"A1:F{max(1, ws.max_row)}"
        opts = option_warning_text(resolved_df)
        if opts:
            ows = writer.book.create_sheet("Options à valider")
            ows["A1"] = "OPTIONS / RÈGLES TARIFAIRES DÉTECTÉES"
            ows["A2"] = "Information uniquement : aucune option ci-dessous n'est incluse automatiquement dans le prix du devis."
            ows["A1"].font = Font(bold=True); ows["A2"].font = Font(italic=True)
            for i, op in enumerate(opts, start=4): ows.cell(i, 1, op)
            ows.column_dimensions["A"].width = 120
    return bio.getvalue()


def v4_fill_excel_template(file_bytes, resolved_df):
    # Same safe rule as generated quote: only verified lines may populate a customer template.
    return _v4_fill_excel_template_verified(file_bytes, _verified_quote_rows(resolved_df))


def _v4_fill_excel_template_verified(file_bytes, verified_df):
    wb = load_workbook(BytesIO(file_bytes))
    choice = None
    for ws in wb.worksheets:
        hr, mp = v4_find_header_row(ws)
        if hr and (choice is None or len(mp) > len(choice[2])): choice = (ws, hr, mp)
    if choice is None or len(choice[2]) < 2:
        raise ValueError("Je ne reconnais pas les colonnes du modèle Excel. Il faut au moins 2 en-têtes connus.")
    ws, header_row, mapping = choice
    row = header_row + 1
    while row <= ws.max_row and any(ws.cell(row, c).value not in (None, "") for c in mapping.values()): row += 1
    fieldmap = {"quantity": "Qté", "request": "Demande", "reference": "Référence", "designation": "Désignation",
                "price": "Prix HT", "eco": "Éco-participation", "total": "Total HT", "catalogue": "Catalogue",
                "page": "Page", "status": "Statut"}
    for _, rec in verified_df.iterrows():
        for key, col in mapping.items():
            val = rec.get(fieldmap.get(key, key))
            ws.cell(row, col).value = None if pd.isna(val) else val
            if key in ("price", "eco", "total") and val is not None and not pd.isna(val):
                ws.cell(row, col).number_format = '#,##0.00 [$€-fr-FR]'
        if all(k in mapping for k in ("quantity", "price", "total")):
            qcol = get_column_letter(mapping["quantity"]); pcol = get_column_letter(mapping["price"])
            ecol = get_column_letter(mapping["eco"]) if "eco" in mapping else None
            eco_expr = f'+IF({ecol}{row}="",0,{ecol}{row})' if ecol else ""
            tcell = ws.cell(row, mapping["total"])
            tcell.value = f'=IF(OR({qcol}{row}="",{pcol}{row}=""),"",{qcol}{row}*({pcol}{row}{eco_expr}))'
            tcell.number_format = '#,##0.00 [$€-fr-FR]'
        row += 1
    bio = BytesIO(); wb.save(bio)
    return bio.getvalue(), ws.title, header_row, mapping


def safe_recalculate_prices() -> tuple[int, int]:
    """Recalculate only prices physically present on the same raw line; never borrow a neighbour price."""
    pages_done = updated = 0
    with db() as conn:
        pages = conn.execute("SELECT DISTINCT catalogue_id,page FROM lines ORDER BY catalogue_id,page").fetchall()
    for pr in pages:
        with db() as conn:
            rows = conn.execute("SELECT id,text,price FROM lines WHERE catalogue_id=? AND page=?", (pr["catalogue_id"], pr["page"])).fetchall()
            for r in rows:
                price = detect_price(clean_line(r["text"] or ''))
                if r["price"] != price:
                    conn.execute("UPDATE lines SET price=? WHERE id=?", (price, r["id"])); updated += 1
            conn.commit(); pages_done += 1
    rebuild_products()
    ensure_product_blocks(force=True)
    rebuild_rag_projection(force=True)
    return pages_done, updated


# Override historical unsafe maintenance function.
recalculate_prices = safe_recalculate_prices


def db_size() -> int:
    total = 0
    for p in DATA_DIR.glob("catalogue_fts.db*"):
        try:
            if p.is_file(): total += p.stat().st_size
        except (FileNotFoundError, OSError):
            continue
    return total


def create_backup(prefix: str = "manual") -> Path:
    ensure_dirs()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = BACKUP_DIR / f"{prefix}_catalogue_fts_{stamp}.db"
    src = sqlite3.connect(DB_PATH, timeout=60)
    dst = sqlite3.connect(target)
    try:
        src.execute("PRAGMA busy_timeout=60000")
        src.backup(dst, pages=1000, sleep=0.05)
        ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok": raise RuntimeError(f"Backup invalide: {ok}")
    finally:
        dst.close(); src.close()
    return target


def cleanup_auto_backups(keep: int = 14) -> None:
    files = sorted(BACKUP_DIR.glob("auto_catalogue_fts_*.db"), reverse=True)
    for p in files[keep:]:
        try: p.unlink()
        except OSError: pass


DAILY_BACKUP_LOCK = DATA_DIR / ".daily_backup.lock"

def _daily_backup_worker() -> None:
    try:
        set_operation("backup", "Sauvegarde quotidienne en cours…", None, True)
        b = create_backup("auto")
        cleanup_auto_backups(14)
        with db() as conn:
            conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('last_daily_backup',?)", (datetime.now().date().isoformat(),))
            conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('last_backup_name',?)", (b.name,))
            conn.commit()
        clear_operation(f"Sauvegarde terminée — {datetime.now().strftime('%H:%M')}")
    except Exception as exc:
        clear_operation(f"Erreur sauvegarde : {exc}")
    finally:
        try: DAILY_BACKUP_LOCK.unlink(missing_ok=True)
        except OSError: pass


def maybe_start_daily_backup() -> None:
    global _daily_backup_thread
    if not DB_PATH.exists() or get_operation().get("active"):
        return
    today = datetime.now().date().isoformat()
    with db() as conn:
        row = conn.execute("SELECT value FROM app_meta WHERE key='last_daily_backup'").fetchone()
    if row and row[0] == today:
        return
    if _daily_backup_thread is not None and _daily_backup_thread.is_alive():
        return
    try:
        if DAILY_BACKUP_LOCK.exists() and time.time() - DAILY_BACKUP_LOCK.stat().st_mtime > 7200:
            DAILY_BACKUP_LOCK.unlink(missing_ok=True)
        fd = os.open(str(DAILY_BACKUP_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(time.time()).encode()); os.close(fd)
    except FileExistsError:
        return
    _daily_backup_thread = threading.Thread(target=_daily_backup_worker, name="daily-db-backup", daemon=True)
    _daily_backup_thread.start()


def ignored_source_signature(path: Path) -> bool:
    try: size, mtime = catalogue_signature(path)
    except OSError: return False
    with db() as conn:
        r = conn.execute("SELECT size_bytes,mtime_ns,decision FROM document_decisions WHERE path=?", (str(path),)).fetchone()
    return bool(r and r["decision"] == "ignore" and int(r["size_bytes"]) == size and int(r["mtime_ns"]) == mtime)


def mark_source_ignored(path: Path) -> None:
    size, mtime = catalogue_signature(path)
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO document_decisions(path,size_bytes,mtime_ns,decision,decided_at) VALUES(?,?,?,?,?)",
                     (str(path), size, mtime, "ignore", utcnow()))
        conn.commit()


def detect_source_changes() -> list[dict]:
    files = source_files(CATALOGUE_DIR)
    with db() as conn:
        known = {r["path"]: r for r in conn.execute("SELECT path,size_bytes,mtime_ns,status FROM catalogues").fetchall()}
    changes = []
    for p in files:
        if ignored_source_signature(p):
            continue
        size, mtime = catalogue_signature(p)
        old = known.get(str(p))
        if old is None:
            changes.append({"kind": "new", "path": p, "label": "Nouveau document"})
        elif int(old["size_bytes"]) != size or int(old["mtime_ns"]) != mtime:
            changes.append({"kind": "modified", "path": p, "label": "Nouvelle version / document modifié"})
    return changes


def update_index(only_path: Path | None = None) -> dict[str, int]:
    if only_path is not None:
        only_path = Path(only_path)
        files = [only_path] if only_path.exists() and only_path.is_file() and only_path.suffix.lower() in SUPPORTED_CATALOGUE_EXTENSIONS and not ignored_source_signature(only_path) else []
    else:
        files = [p for p in source_files(CATALOGUE_DIR) if not ignored_source_signature(p)]
    seen = {str(p) for p in files}
    stats = {"indexed": 0, "unchanged": 0, "removed": 0, "errors": 0}
    set_operation("index", "Indexation en cours…", 0.0, True)
    # A targeted watcher action must never treat all other catalogues as deleted.
    if only_path is None:
        with db() as conn:
            for row in conn.execute("SELECT id,path FROM catalogues").fetchall():
                if row["path"] not in seen:
                    conn.execute("DELETE FROM catalogues WHERE id=?", (row["id"],)); stats["removed"] += 1
            conn.commit()
    outer = st.progress(0, text="Préparation de l'indexation")
    status = st.empty()
    try:
        for i, path in enumerate(files):
            size, mtime = catalogue_signature(path)
            with db() as conn:
                old = conn.execute("SELECT size_bytes,mtime_ns,status,index_version FROM catalogues WHERE path=?", (str(path),)).fetchone()
            if old and old["size_bytes"] == size and old["mtime_ns"] == mtime and str(old["status"]).startswith("ready") and old["index_version"] == INDEX_VERSION:
                stats["unchanged"] += 1
            else:
                status.info(f"Document {i+1}/{len(files)} : {path.name}")
                pp = st.progress(0, text=path.name)
                try:
                    index_catalogue(path, pp, status); stats["indexed"] += 1
                    with db() as conn:
                        conn.execute("DELETE FROM document_decisions WHERE path=?", (str(path),)); conn.commit()
                except Exception as exc:
                    stats["errors"] += 1; status.warning(f"Ignoré : {path.name} — {exc}")
                pp.empty()
            prog = (i + 1) / max(len(files), 1)
            outer.progress(prog, text=f"Documents {i+1}/{len(files)}")
            set_operation("index", f"Indexation — document {i+1}/{len(files)} : {path.name}", prog, True)
        if stats["indexed"] or stats["removed"]:
            status.info("Optimisation du moteur RAG…")
            ensure_product_blocks(force=True)
            rebuild_rag_projection(force=True)
        with db() as conn:
            conn.execute("PRAGMA optimize"); conn.commit()
        clear_operation(f"Indexation terminée — {stats['indexed']} document(s) mis à jour")
        return stats
    except Exception as exc:
        clear_operation(f"Erreur indexation : {exc}")
        raise
    finally:
        outer.empty()


def _table_available_columns(df: pd.DataFrame) -> list[str]:
    cols = []
    for c in DEFAULT_COLUMN_ORDER + TECHNICAL_COLUMNS:
        if c in df.columns and c not in cols:
            cols.append(c)
    return cols


def render_table(df: pd.DataFrame, key_prefix: str = "search", compact: bool = False) -> None:
    if df is None or df.empty:
        st.info("Aucun résultat."); return
    x = df.copy()
    if "Description" not in x.columns and "Désignation" in x.columns:
        x["Description"] = x["Désignation"]
    if "Éco" not in x.columns and "Éco./Autre" in x.columns:
        x["Éco"] = x["Éco./Autre"]
    if "Options" not in x.columns:
        if "_options" in x.columns:
            def opt(v):
                if v is None or (isinstance(v, float) and pd.isna(v)): return None
                return str(v) if str(v).startswith(("Disponible", "À confirmer", "Non applicable")) else ("À confirmer — " + str(v))
            x["Options"] = [opt(v) for v in x["_options"]]
        else:
            x["Options"] = None
    available = _table_available_columns(x)
    prefs = load_ui_preferences()
    order = [c for c in prefs["column_order"] if c in available] + [c for c in available if c not in prefs["column_order"]]
    visible_default = [c for c in prefs["visible_columns"] if c in order]
    if not visible_default:
        visible_default = [c for c in DEFAULT_COLUMN_ORDER if c in order]

    if not compact:
        with st.expander("⚙️ Colonnes affichées", expanded=False):
            widget_key = f"{key_prefix}_visible_columns"
            current = st.session_state.get(widget_key, visible_default)
            current = [c for c in current if c in order]
            selected = st.multiselect("Colonnes visibles", order, default=current or visible_default, key=widget_key)
            if not selected: selected = visible_default
            if selected != prefs["visible_columns"]:
                prefs["visible_columns"] = selected; save_ui_preferences(prefs)
            move_candidates = [c for c in order if c in selected]
            if move_candidates:
                c1, c2, c3, c4 = st.columns([3, 1, 1, 1.4])
                move = c1.selectbox("Réordonner", move_candidates, key=f"{key_prefix}_move_col")
                if c2.button("←", key=f"{key_prefix}_left", help="Déplacer la colonne vers la gauche"):
                    vidx = move_candidates.index(move)
                    if vidx > 0:
                        other = move_candidates[vidx-1]
                        i, j = order.index(move), order.index(other)
                        order[i], order[j] = order[j], order[i]
                        prefs["column_order"] = order + [c for c in prefs["column_order"] if c not in order]
                        save_ui_preferences(prefs); st.rerun()
                if c3.button("→", key=f"{key_prefix}_right", help="Déplacer la colonne vers la droite"):
                    vidx = move_candidates.index(move)
                    if vidx < len(move_candidates)-1:
                        other = move_candidates[vidx+1]
                        i, j = order.index(move), order.index(other)
                        order[i], order[j] = order[j], order[i]
                        prefs["column_order"] = order + [c for c in prefs["column_order"] if c not in order]
                        save_ui_preferences(prefs); st.rerun()
                if c4.button("Réinitialiser", key=f"{key_prefix}_reset_cols"):
                    prefs["column_order"] = DEFAULT_COLUMN_ORDER + TECHNICAL_COLUMNS
                    prefs["visible_columns"] = DEFAULT_COLUMN_ORDER.copy()
                    save_ui_preferences(prefs)
                    st.session_state.pop(widget_key, None)
                    st.rerun()
    else:
        selected = visible_default

    selected = [c for c in order if c in selected]
    shown = x[selected].copy()
    h = 360 if compact else min(720, 88 + 36 * min(len(shown), 18))
    st.dataframe(shown, use_container_width=True, hide_index=True, height=h, column_config={
        "Description": st.column_config.TextColumn("Description", width="large"),
        "Dimensions": st.column_config.TextColumn("Dimensions", width="medium"),
        "Plateau": st.column_config.TextColumn("Plateau", width="small"),
        "Panneau": st.column_config.TextColumn("Panneau", width="small"),
        "Chant": st.column_config.TextColumn("Chant", width="small"),
        "GEN. LAFA": st.column_config.TextColumn("GEN. LAFA", width="small"),
        "Référence": st.column_config.TextColumn("Référence", width="medium"),
        "Prix HT": st.column_config.NumberColumn("Prix HT", format="%.2f €", width="small"),
        "Éco": st.column_config.NumberColumn("Éco", format="%.2f €", width="small"),
        "Options": st.column_config.TextColumn("Options de gamme", width="large"),
        "Page": st.column_config.NumberColumn("Page", format="%d", width="small"),
        "Ligne": st.column_config.NumberColumn("Ligne", format="%d", width="small"),
        "Catalogue": st.column_config.TextColumn("Catalogue", width="large"),
        "PDF / Page": st.column_config.LinkColumn("Source", display_text="Ouvrir", width="small")
    })


def auto_scroll_chat() -> None:
    try:
        import streamlit.components.v1 as components
        components.html("""<script>setTimeout(()=>{window.parent.scrollTo({top:window.parent.document.body.scrollHeight,behavior:'smooth'});},120);</script>""", height=0)
    except Exception:
        pass

# ======================= FIN FINAL RAG / UX =======================


ensure_dirs()
init_db()
ensure_final_schema()
with db() as _meta_conn:
    ensure_page_meta(_meta_conn)
    _meta_conn.execute("CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY,value TEXT)")
    if not _meta_conn.execute("SELECT 1 FROM app_meta WHERE key='v6_price_repair'").fetchone():
        _fixed = repair_commercial_values_v6(_meta_conn)
        _meta_conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('v6_price_repair',?)", (str(_fixed),))
        _meta_conn.commit()

maybe_start_daily_backup()

# Keep the daily backup schedule alive even if the application remains open across midnight.
try:
    @st.fragment(run_every="60s")
    def _daily_backup_tick():
        maybe_start_daily_backup()
    _daily_backup_tick()
except Exception:
    pass

# Deep-link from a result: open the exact supplier page and locate the matching row.
_pdf_q = st.query_params.get("pdf")
_page_q = st.query_params.get("page")
_hit_q = st.query_params.get("hit")
_line_q = st.query_params.get("line")
if _pdf_q:
    candidate = (CATALOGUE_DIR / str(_pdf_q)).resolve()
    root = CATALOGUE_DIR.resolve()
    if candidate.is_file() and root in candidate.parents:
        page_no = max(1, int(_page_q or 1))
        st.info(f"Document : {candidate.name} — page {page_no} — ligne {_line_q or '?'}")
        try:
            if candidate.suffix.lower() != ".pdf":
                raise RuntimeError("Aperçu graphique réservé aux PDF ; utilisez le bouton source ci-dessous.")
            with fitz.open(candidate) as doc:
                if page_no <= doc.page_count:
                    page = doc.load_page(page_no - 1)
                    rects = []
                    if _hit_q:
                        rects = page.search_for(str(_hit_q), quads=False)
                        if not rects:
                            words = [w for w in re.findall(r"[\w.-]+", str(_hit_q)) if len(w) >= 4]
                            phrase = " ".join(words[:4])
                            if phrase: rects = page.search_for(phrase, quads=False)
                    if rects:
                        seed = rects[0]
                        words = page.get_text("words")
                        same = [fitz.Rect(w[:4]) for w in words if not (w[3] < seed.y0 - 5 or w[1] > seed.y1 + 5)]
                        if same:
                            y0 = min(r.y0 for r in same) - 2.5; y1 = max(r.y1 for r in same) + 2.5
                            x0 = max(page.rect.x0 + 3, min(r.x0 for r in same) - 5)
                            x1 = min(page.rect.x1 - 3, max(r.x1 for r in same) + 5)
                            row_rect = fitz.Rect(x0, y0, x1, y1)
                        else:
                            row_rect = fitz.Rect(max(page.rect.x0 + 3, seed.x0 - 8), seed.y0 - 3,
                                                 min(page.rect.x1 - 3, seed.x1 + 20), seed.y1 + 3)
                        page.draw_rect(row_rect, color=(1, 0, 0), width=1.25, overlay=True)
                        rects = [row_rect]
                    clip = None
                    if rects:
                        r = rects[0]
                        clip = fitz.Rect(page.rect.x0, max(page.rect.y0, r.y0 - 270), page.rect.x1, min(page.rect.y1, r.y1 + 300))
                    pix = page.get_pixmap(matrix=fitz.Matrix(2.35, 2.35), clip=clip, alpha=False)
                    st.image(pix.tobytes("png"), caption=("Zone localisée automatiquement" if rects else "Page cible"), use_container_width=True)
        except Exception as exc:
            st.warning(f"Aperçu impossible : {exc}")
        with candidate.open("rb") as fh:
            _mime = {".pdf": "application/pdf", ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12", ".csv": "text/csv", ".txt": "text/plain",
                     ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}.get(candidate.suffix.lower(), "application/octet-stream")
            st.download_button("📄 Ouvrir / télécharger la source", fh.read(), file_name=candidate.name, mime=_mime)
        if st.button("← Retour aux résultats"):
            st.query_params.clear(); st.rerun()

_prefs = load_ui_preferences()
_dark = _prefs.get("theme") == "Bleu nuit"
_BG = "#080d1a" if _dark else "#ffffff"
_SIDE = "#0d1424" if _dark else "#ffffff"
_PANEL = "#121c30" if _dark else "#f5f7fb"
_PANEL2 = "#17233a" if _dark else "#eef2f7"
_TEXT = "#f4f7ff" if _dark else "#111827"
_MUTED = "#aebbd2" if _dark else "#6b7280"
_BORDER = "#263754" if _dark else "#e5e7eb"
_ACCENT = "#5b7cfa" if _dark else "#2563eb"
_USER_BUBBLE = "#2449a8" if _dark else "#27364f"

st.markdown(f"""
<style>
.stApp, [data-testid="stAppViewContainer"] {{background:{_BG};color:{_TEXT};}}
[data-testid="stSidebar"] {{background:{_SIDE};color:{_TEXT};border-right:1px solid {_BORDER};}}
html, body, [class*="css"], p, label, span {{color:{_TEXT};}}
[data-testid="stSidebar"] p, [data-testid="stSidebar"] label {{color:{_TEXT};}}
h1,h2,h3,h4 {{color:{_TEXT};letter-spacing:-0.02em;}}
hr {{border-color:{_BORDER};}}
.stTextInput input, .stTextArea textarea, [data-baseweb="select"] > div,
[data-testid="stFileUploader"], [data-testid="stDataFrame"], [data-testid="stExpander"] {{
  background:{_PANEL} !important;color:{_TEXT} !important;border-color:{_BORDER} !important;border-radius:8px !important;
}}
.stButton>button, .stDownloadButton>button {{border:1px solid {_BORDER};border-radius:8px;background:{_PANEL};color:{_TEXT};font-weight:600;}}
.stButton>button:hover, .stDownloadButton>button:hover {{border-color:{_ACCENT};color:{_TEXT};}}
[data-testid="stToolbar"] {{opacity:0;transition:opacity .15s;}} [data-testid="stToolbar"]:hover {{opacity:1;}}
/* Chat layout: scrollable thread + input kept below the thread. */
[data-testid="stChatInput"] {{position:sticky;bottom:0.6rem;z-index:50;background:{_BG};padding-top:.45rem;padding-bottom:.3rem;}}
[data-testid="stChatInput"] textarea {{background:{_PANEL2} !important;color:{_TEXT} !important;border:1px solid {_BORDER} !important;}}
[data-testid="stChatMessage"] {{border-radius:14px;margin:.35rem 0;padding:.15rem .35rem;}}
[data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarUser"]) {{
  margin-left:18%;background:{_USER_BUBBLE};color:white;
}}
[data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarUser"]) p,
[data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarUser"]) span {{color:white !important;}}
[data-testid="stChatMessage"]:has([data-testid="stChatMessageAvatarAssistant"]) {{
  margin-right:8%;background:{_PANEL};border:1px solid {_BORDER};
}}
[data-testid="stDataFrame"] [role="grid"], [data-testid="stDataFrame"] [role="gridcell"],
[data-testid="stDataFrame"] [role="columnheader"] {{background:{_PANEL} !important;color:{_TEXT} !important;border-color:{_BORDER} !important;}}
[data-testid="stCaptionContainer"] p {{color:{_MUTED} !important;}}
a {{color:{_ACCENT} !important;}}
</style>
""", unsafe_allow_html=True)

try:
    @st.fragment(run_every="2s")
    def _operation_banner():
        op = get_operation()
        if op.get("active"):
            msg = op.get("message") or "Opération en cours…"
            prog = op.get("progress")
            st.info("⏳ " + msg)
            if isinstance(prog, (int, float)):
                st.progress(max(0.0, min(1.0, float(prog))))
        elif op.get("message") not in (None, "", "Disponible") and time.time()-float(op.get("updated",0) or 0) < 12:
            st.success("✓ " + str(op.get("message")))
    _operation_banner()
except Exception:
    op = get_operation()
    if op.get("active"): st.info("⏳ " + str(op.get("message") or "Opération en cours…"))

st.title("Identification Documentaire")

with st.sidebar:
    _logo = APP_DIR / "assets" / "logo.png"
    if _logo.exists():
        st.image(str(_logo), width=115)

    theme_choice = st.radio("Affichage", ["Clair", "Bleu nuit"], horizontal=True,
                            index=1 if _dark else 0, key="theme_choice")
    if theme_choice != _prefs.get("theme"):
        _prefs["theme"] = theme_choice; save_ui_preferences(_prefs); st.rerun()

    cats = source_files(CATALOGUE_DIR)
    c1, c2 = st.columns(2)
    c1.metric("Catalogues", len(cats))
    c2.metric("Index disque", human_size(db_size()))
    st.caption(str(CATALOGUE_DIR))

    try:
        @st.fragment(run_every="10s")
        def _watch_documents():
            if st.session_state.get("watch_snooze_until", 0) > time.time():
                return
            changes = detect_source_changes()
            if not changes:
                return
            st.warning(f"📄 {len(changes)} document(s) nouveau(x) ou modifié(s) détecté(s).")
            for ch in changes[:4]:
                st.caption(f"{ch['label']} : {ch['path'].name}")
            if len(changes) > 4: st.caption(f"… et {len(changes)-4} autre(s)")
            selected_path = st.selectbox("Document détecté", [str(x['path']) for x in changes], format_func=lambda x: Path(x).name, key="watch_selected")
            a, b, c = st.columns(3)
            if a.button("Indexer", key="watch_index", use_container_width=True):
                stats = update_index(Path(selected_path))
                st.success(f"{stats['indexed']} document(s) indexé(s).")
                try: st.rerun(scope="app")
                except Exception: st.rerun()
            if b.button("Plus tard", key="watch_later", use_container_width=True):
                st.session_state["watch_snooze_until"] = time.time() + 3600
            if c.button("Ignorer", key="watch_ignore", use_container_width=True):
                mark_source_ignored(Path(selected_path)); st.rerun()
        _watch_documents()
    except Exception:
        changes = detect_source_changes()
        if changes: st.warning(f"📄 {len(changes)} document(s) à indexer détecté(s).")

    if st.button("⚡ Indexer / Mettre à jour le référentiel", type="primary", use_container_width=True):
        stats = update_index()
        st.success(f"Terminé — {stats['indexed']} indexé(s), {stats['unchanged']} inchangé(s), {stats['removed']} supprimé(s), {stats['errors']} erreur(s).")
        st.rerun()

    with st.expander("État de l'indexation / erreurs"):
        with db() as conn:
            pending = conn.execute("SELECT count(*) FROM catalogues WHERE status NOT LIKE 'ready%'").fetchone()[0]
            errs = conn.execute("SELECT count(*) FROM index_errors").fetchone()[0]
            last = conn.execute("SELECT c.name,e.page,e.error FROM index_errors e JOIN catalogues c ON c.id=e.catalogue_id ORDER BY e.id DESC LIMIT 10").fetchall()
            lb = conn.execute("SELECT value FROM app_meta WHERE key='last_backup_name'").fetchone()
        st.caption(f"Documents à reprendre : {pending} · Pages ignorées : {errs}")
        if lb: st.caption("Dernier backup automatique : " + str(lb[0]))
        if last: st.dataframe(pd.DataFrame([dict(x) for x in last]), hide_index=True, use_container_width=True)

    with st.expander("Maintenance / Sauvegardes"):
        if st.button("💶 Vérifier / recalculer les prix", use_container_width=True):
            with st.spinner("Vérification stricte des prix présents sur leurs lignes…"):
                pages_done, updated = recalculate_prices()
            st.success(f"{updated} ligne(s) mise(s) à jour sur {pages_done} page(s).")
        if st.button("🧠 Reconstruire le moteur RAG", use_container_width=True):
            set_operation("optimize", "Optimisation du moteur RAG…", None, True)
            try:
                with st.spinner("Reconstruction de la base produit / contexte / options…"):
                    rebuild_products(); ensure_product_blocks(force=True); nrag = rebuild_rag_projection(force=True)
                st.success(f"Moteur RAG reconstruit : {nrag} référence(s).")
            finally:
                clear_operation("Optimisation terminée")
        if st.button("💾 Sauvegarder la base maintenant", use_container_width=True):
            try:
                set_operation("backup", "Sauvegarde manuelle en cours…", None, True)
                b = create_backup("manual"); st.success(f"Backup créé : {b.name}")
            except Exception as e: st.error(f"Backup impossible : {e}")
            finally: clear_operation("Sauvegarde terminée")
        backups = sorted(BACKUP_DIR.glob("*.db"), reverse=True)
        choice = st.selectbox("Restaurer", ["—"] + [p.name for p in backups])
        if st.button("♻️ Restaurer la sauvegarde", disabled=choice == "—", use_container_width=True):
            try:
                restore_backup(BACKUP_DIR / choice); rebuild_rag_projection(force=True)
                st.success("Base restaurée et vérifiée."); st.rerun()
            except Exception as e: st.error(f"Restauration refusée : {e}")

    st.markdown("---")
    st.markdown("**Asvind**")
    if st.button("Optimiser l’index IA", help="Reconstruit la projection RAG depuis SQLite sans relire les PDF.", use_container_width=True):
        with st.spinner("Optimisation du moteur de recherche…"):
            nrag = rebuild_rag_projection(force=True)
        st.success(f"{nrag} références optimisées")

st.markdown("""<style>
.id-chat-empty{margin:.65rem 0 .55rem 0;padding:1rem 1.1rem;border:1px solid rgba(128,128,128,.22);border-radius:16px;background:rgba(128,128,128,.055)}
</style>""", unsafe_allow_html=True)

search_tab, ai_tab, email_tab = st.tabs(["🔎 Recherche", "🤖 Assistant IA", "📧 Demande client + Excel"])

with search_tab:
    options = ["Tous les catalogues"] + catalogue_options()
    c1, c2 = st.columns([3, 1])
    query = c1.text_input("Recherche", placeholder="table Norma, table de classe, COL1038, 1200 x 600…")
    selected = c2.selectbox("Catalogue", options)
    cat = None if selected == "Tous les catalogues" else selected
    if st.button("Rechercher", key="search_btn", type="primary"):
        if not query.strip() and not cat:
            st.warning("Saisissez un terme ou sélectionnez un catalogue pour un listing global.")
        else:
            with st.spinner("Recherche dans le référentiel…"):
                _sdf, _sintent = rag_retrieve(query, SEARCH_LIMIT, cat, mode="new")
                st.session_state["search_df"] = _sdf
                st.session_state["search_intent"] = _sintent
    if "search_df" in st.session_state:
        df = st.session_state["search_df"]
        st.caption(f"{len(df)} référence(s) affichée(s), maximum {SEARCH_LIMIT}. Description et dimensions sont prioritaires ; les attributs/options affinent ensuite.")
        render_table(df, key_prefix="search")

with ai_tab:
    st.subheader("Assistant IA")
    st.caption("Assistant RAG local : il distingue une nouvelle recherche d’un affinage, conserve le pool actif et n’utilise que les faits vérifiés du référentiel.")
    if "assistant_history" not in st.session_state:
        st.session_state["assistant_history"] = []
    if "assistant_rag_state" not in st.session_state:
        st.session_state["assistant_rag_state"] = {"pool": pd.DataFrame(), "intent": {}, "base_query": None}

    _has_chat = bool(st.session_state["assistant_history"] or st.session_state.get("assistant_pending"))
    _needs_rerun = False
    if not _has_chat:
        # Empty state stays compact so the input is visible immediately without scrolling.
        st.markdown("""<div class="id-chat-empty">
        <div style="font-size:1.15rem;font-weight:650;margin-bottom:.25rem">Que recherchez-vous ?</div>
        <div style="opacity:.72">Ex. « table rouge époxy », « table de classe deux places », « COL1038-T6E ».</div>
        </div>""", unsafe_allow_html=True)
    else:
        _chat_box = st.container(height=620, border=False)
        with _chat_box:
            for _msg_idx, _m in enumerate(st.session_state["assistant_history"]):
                with st.chat_message(_m["role"]):
                    st.markdown(_m["content"])
                    if _m["role"] == "assistant" and isinstance(_m.get("sources"), pd.DataFrame) and not _m["sources"].empty:
                        expanded = bool(_m.get("expanded"))
                        with st.expander(f"Résultats vérifiés · {len(_m['sources'])} référence(s)", expanded=expanded):
                            render_table(_m["sources"], key_prefix=f"assistant_history_{_msg_idx}", compact=True)

            _pending = st.session_state.get("assistant_pending")
            if _pending:
                with st.chat_message("assistant"):
                    with st.spinner("Je consulte le référentiel et j’affine le pool actif…"):
                        _df, _base, _intent, _mode = v4_assistant(_pending, 500)
                        _answer = assistant_conversation_answer(_pending, _df, _base, _intent)
                    st.markdown(_answer)
                    if not _df.empty:
                        _expand = bool(_intent.get("show_all"))
                        with st.expander(f"Résultats vérifiés · {len(_df)} référence(s)", expanded=_expand):
                            render_table(_df, key_prefix="assistant_pending_results", compact=True)
                st.session_state["assistant_history"].append({"role": "assistant", "content": _answer, "sources": _df.copy(), "expanded": bool(_intent.get("show_all"))})
                st.session_state.pop("assistant_pending", None)
                _needs_rerun = True

    if _needs_rerun:
        auto_scroll_chat(); st.rerun()

    _q = st.chat_input("Demandez un produit ou affinez : « deux places », « rouge », « moins chère », « affiche tout »…", key="assistant_chat_input")
    if _q:
        st.session_state["assistant_history"].append({"role": "user", "content": _q})
        st.session_state["assistant_pending"] = _q
        auto_scroll_chat(); st.rerun()

    c1, c2 = st.columns([1, 5])
    if c1.button("Nouvelle discussion", key="assistant_new"):
        st.session_state["assistant_history"] = []
        st.session_state["assistant_rag_state"] = {"pool": pd.DataFrame(), "intent": {}, "base_query": None}
        st.session_state.pop("assistant_pending", None)
        st.rerun()

with email_tab:
    st.subheader("Demande client → références → Excel")
    st.caption("Le même moteur RAG que Recherche et Assistant IA analyse d’abord l’identité du produit (description/gamme), puis les dimensions et seulement ensuite les attributs/options.")
    email_text = st.text_area("E-mail / demande client", height=180, key="v4_mail",
        placeholder="Bonjour, je cherche 2 tables Norma LAFA en jaune…")
    excel_template = st.file_uploader("Modèle Excel à compléter (optionnel)", type=["xlsx"], key="v4_excel_template")
    with st.form("v4_mail_form"):
        mail_submit = st.form_submit_button("🧩 Analyser et chiffrer", type="primary")
    if mail_submit and email_text.strip():
        with st.spinner("Compréhension de la demande et recherche RAG…"):
            _rdf, _mode = v4_resolve_client_mail(email_text, 4)
            if not _rdf.empty and "PDF / Page" not in _rdf.columns:
                try: _rdf = add_pdf_links(_rdf)
                except Exception: pass
            st.session_state["v4_mail_df"] = _rdf
            st.session_state["v4_mail_mode"] = _mode
    if "v4_mail_df" in st.session_state:
        _rdf = st.session_state["v4_mail_df"]
        st.caption("Analyse : " + st.session_state.get("v4_mail_mode", "RAG local"))
        if _rdf.empty:
            st.warning("Aucune ligne exploitable détectée.")
        else:
            unresolved = _rdf[~_rdf["Statut"].astype(str).isin(["Vérifié"]) & ~_rdf["Statut"].astype(str).str.startswith("Alternative")]
            if not unresolved.empty:
                st.warning("Une ou plusieurs lignes sont ambiguës. L’application ne les marque pas comme vérifiées et ne les chiffre pas automatiquement. Précisez la dimension, la finition ou la référence puis relancez l’analyse.")
            _opts = option_warning_text(_rdf)
            if _opts:
                with st.expander("⚠️ Options / informations de gamme", expanded=False):
                    for _op in _opts: st.markdown("• " + _op)
                    st.caption("Ces informations sont rattachées à la gamme et ne sont jamais ajoutées automatiquement au prix.")
            st.dataframe(_rdf, use_container_width=True, hide_index=True, column_config={
                "Prix HT": st.column_config.NumberColumn("Prix HT", format="%.2f €"),
                "Éco-participation": st.column_config.NumberColumn("Éco-participation", format="%.2f €"),
                "Total HT": st.column_config.NumberColumn("Total HT", format="%.2f €"),
                "PDF / Page": st.column_config.LinkColumn("Source", display_text="Ouvrir"),
            })
            verified_n = len(_verified_quote_rows(_rdf))
            if verified_n:
                _quote_xlsx = v4_make_quote_excel(_rdf)
                label = "⬇️ Télécharger le devis Excel" if verified_n == len(_rdf[~_rdf["Statut"].astype(str).str.startswith("Alternative")]) else f"⬇️ Télécharger les {verified_n} ligne(s) vérifiée(s)"
                st.download_button(label, _quote_xlsx, "devis_client.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                if excel_template is not None:
                    try:
                        _filled, _sheet, _hr, _map = v4_fill_excel_template(excel_template.getvalue(), _rdf)
                        st.success(f"Modèle reconnu : feuille « {_sheet} », en-têtes ligne {_hr}. Seules les lignes vérifiées sont complétées.")
                        st.download_button("⬇️ Télécharger votre Excel complété", _filled, "devis_complete.xlsx",
                                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary")
                    except Exception as _e:
                        st.error(f"Complétion du modèle Excel : {_e}")
            else:
                st.info("Aucun devis final n’est généré tant qu’une variante n’est pas suffisamment identifiée.")

