from __future__ import annotations
import argparse,csv,json,re,subprocess,tempfile
from pathlib import Path
import fitz
from openpyxl import load_workbook
from docx import Document

OCR_MIN_CHARS=40
OCR_DPI=120
def useful(s): return len(re.sub(r"\W+","",s or "",flags=re.UNICODE))
def ext(p): return p.suffix.lower()

def page_count(path):
    if ext(path)==".pdf":
        with fitz.open(path) as d:return d.page_count
    if ext(path) in {".xlsx",".xlsm"}:
        wb=load_workbook(path,read_only=True,data_only=True)
        try:return max(1,len(wb.sheetnames))
        finally:wb.close()
    return 1

def excel_text(path,idx):
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        if idx>=len(wb.sheetnames):return ""
        ws=wb[wb.sheetnames[idx]]
        out=[f"FEUILLE {ws.title}"]
        for row in ws.iter_rows(values_only=True):
            vals=[str(v).strip() for v in row if v is not None and str(v).strip()]
            if vals:out.append(" | ".join(vals))
        return "\n".join(out)
    finally:wb.close()

def docx_text(path):
    d=Document(path);out=[]
    out += [p.text.strip() for p in d.paragraphs if p.text.strip()]
    for table in d.tables:
        for row in table.rows:
            vals=[c.text.strip().replace("\n"," ") for c in row.cells if c.text.strip()]
            if vals:out.append(" | ".join(vals))
    return "\n".join(out)

def extract(path,page_idx):
    e=ext(path)
    if e==".pdf":
        with fitz.open(path) as d:
            p=d.load_page(page_idx)
            try:text=p.get_text("text",sort=True) or ""
            except:text=""
            if useful(text)>=OCR_MIN_CHARS:return {"text":text,"ocr":False}
            pix=p.get_pixmap(matrix=fitz.Matrix(OCR_DPI/72,OCR_DPI/72),colorspace=fitz.csGRAY,alpha=False)
            with tempfile.TemporaryDirectory(prefix="idxocr_") as td:
                img=Path(td)/"page.png";pix.save(img)
                cp=subprocess.run(["tesseract",str(img),"stdout","-l","fra+eng","--oem","1","--psm","6"],
                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=75,check=False)
                ocr=cp.stdout or ""
            return {"text":ocr if useful(ocr)>useful(text) else text,"ocr":useful(ocr)>useful(text)}
    if e in {".xlsx",".xlsm"}:return {"text":excel_text(path,page_idx),"ocr":False}
    if e==".csv":
        raw=path.read_text(encoding="utf-8-sig",errors="replace")
        try:
            dialect=csv.Sniffer().sniff(raw[:4096],delimiters=",;\\t|")
            text="\n".join(" | ".join(c.strip() for c in r if c.strip()) for r in csv.reader(raw.splitlines(),dialect))
        except:text=raw
        return {"text":text,"ocr":False}
    if e==".txt":return {"text":path.read_text(encoding="utf-8-sig",errors="replace"),"ocr":False}
    if e==".docx":return {"text":docx_text(path),"ocr":False}
    raise ValueError(f"Format non supporté: {e}")

def main():
    ap=argparse.ArgumentParser();ap.add_argument("path");ap.add_argument("--count",action="store_true");ap.add_argument("--page",type=int)
    a=ap.parse_args();p=Path(a.path)
    if a.count:print(json.dumps({"pages":page_count(p)}));return
    if a.page is None:raise SystemExit(2)
    print(json.dumps(extract(p,a.page),ensure_ascii=False))
if __name__=="__main__":main()
