# Correctif FINAL RAG 2

- Le type de produit est une contrainte dure : une chaise contenant « appui sur table » ne peut plus entrer dans une recherche TABLE.
- La projection RAG préfère la ligne commerciale exacte pour Description/Dimensions afin d’éviter la contamination par le texte voisin.
- Tolérance aux fautes usuelles de finition : epoxyl / epoxyle / epoxi -> epoxy.
- Les OPTIONS sont bornées par la famille et les séparateurs ; une option +prix voisine ne doit plus fuiter sur une autre gamme.
- Au premier affichage de l’Assistant IA, la saisie est visible immédiatement : plus de grand espace vide de 620 px.
- La projection RAG est reconstruite automatiquement une fois depuis SQLite (pas de réindexation PDF).
