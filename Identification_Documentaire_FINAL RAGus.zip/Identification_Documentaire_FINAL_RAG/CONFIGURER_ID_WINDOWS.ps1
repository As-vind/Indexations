# Exécuter une fois en tant qu'administrateur.
$ErrorActionPreference = "Stop"
$hosts = "$env:SystemRoot\System32\drivers\etc\hosts"
$entry = "127.0.0.1 ID"
$content = Get-Content $hosts -ErrorAction Stop
if (-not ($content | Where-Object { $_ -match '^\s*127\.0\.0\.1\s+ID\s*$' })) {
    Add-Content -Path $hosts -Value "`r`n$entry"
    Write-Host "Nom local ID ajouté au fichier hosts." -ForegroundColor Green
} else {
    Write-Host "Le nom local ID est déjà configuré." -ForegroundColor Green
}
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = Join-Path $desktop 'Identification Documentaire.url'
@"
[InternetShortcut]
URL=http://ID:1979
IconFile=$env:SystemRoot\System32\shell32.dll
IconIndex=14
"@ | Set-Content -Path $shortcut -Encoding ASCII
ipconfig /flushdns | Out-Null
Write-Host "Raccourci créé : $shortcut" -ForegroundColor Green
Write-Host "Adresse : http://ID:1979" -ForegroundColor Cyan
