# Identification Documentaire V2.5 — par Asvind

Application locale Streamlit/Docker pour indexer et rechercher des catalogues PDF fournisseurs.

## Démarrage Windows / Docker Desktop
1. Décompresser ce dossier.
2. Copier les PDF (et leurs sous-dossiers) dans `data/catalogues/`.
3. Ouvrir PowerShell dans ce dossier.
4. Lancer : `docker compose up --build -d`
5. Ouvrir : http://localhost:8501
6. Cliquer sur `Indexer / Mettre à jour le référentiel`.

## V2.5
- parcours récursif de `data/catalogues/`
- SQLite FTS5 + recherche préfixe + RapidFuzz
- OCR local automatique FR+EN uniquement si le texte natif d'une page est insuffisant
- extraction de prix avec contexte autour de la ligne produit
- lien PDF/page depuis les résultats
- sauvegarde SQLite cohérente avec contrôle d'intégrité
- restauration avec contrôle d'intégrité + sauvegarde de sécurité avant remplacement
- purge des documents clients
- index persistant dans `data/catalogue_fts.db`
- sauvegardes dans `data/backups/`

## Commandes
Démarrer/reconstruire : `docker compose up --build -d`
Logs : `docker compose logs -f --tail=100`
Arrêter : `docker compose down`
