from __future__ import annotations

import gc
import hashlib
import io
import os
import re
import sqlite3
import shutil
import threading
from urllib.parse import quote
import time
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator

import pandas as pd
import streamlit as st
from openpyxl.styles import Font, PatternFill
from pypdf import PdfReader
import fitz
import pytesseract
from PIL import Image
from rapidfuzz import fuzz, process

APP_DIR = Path("/app")
DATA_DIR = APP_DIR / "data"
CATALOGUE_DIR = DATA_DIR / "catalogues"
QUOTE_DIR = DATA_DIR / "devis"
DB_PATH = DATA_DIR / "catalogue_fts.db"
BACKUP_DIR = DATA_DIR / "backups"
APP_VERSION = "2.5"
INDEX_VERSION = 25
OCR_MIN_CHARS = 40
OCR_DPI = 150

SEARCH_LIMIT = 500
FUZZY_CANDIDATE_LIMIT = 20_000
FUZZY_RESULT_LIMIT = 250
COMMIT_EVERY_PAGES = 10
MIN_FUZZY_SCORE = 75

PRICE_RE = re.compile(r"(?<!\d)(\d{1,6}(?:[ .]\d{3})*(?:[,.]\d{2})?)\s*(?:€|EUR|euros?|HT|TTC)\b", re.I)
REF_RE = re.compile(r"\b(?=[A-Z0-9._/-]{4,}\b)(?=[A-Z0-9._/-]*\d)[A-Z0-9][A-Z0-9._/-]{2,}[A-Z0-9]\b", re.I)
QTY_RE = re.compile(r"(?<!\w)(\d{1,4})\s*(?:x|×|pcs?\.?|pi[eè]ces?|unit[eé]s?)?\b", re.I)
STOPWORDS = {
    "bonjour", "bonsoir", "merci", "cordialement", "svp", "besoin", "faudrait", "voudrais", "souhaite",
    "nous", "vous", "avec", "pour", "dans", "des", "les", "une", "un", "du", "de", "la", "le", "et",
    "ainsi", "que", "est", "sont", "client", "demande", "prix", "quantite", "quantité", "article", "articles",
}

st.set_page_config(page_title="Identification documentaire", page_icon="🔎", layout="wide")


def ensure_dirs() -> None:
    CATALOGUE_DIR.mkdir(parents=True, exist_ok=True)
    QUOTE_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower().replace("’", "'")
    return re.sub(r"\s+", " ", text).strip()


def clean_line(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").replace("\x00", " ")).strip()


def detect_price(text: str) -> float | None:
    vals = PRICE_RE.findall(text or "")
    if not vals:
        return None
    raw = vals[-1].replace(" ", "").replace(",", ".")
    try:
        return float(raw)
    except ValueError:
        return None


def detect_reference(text: str) -> str | None:
    refs = REF_RE.findall(text or "")
    if not refs:
        return None
    refs.sort(key=len, reverse=True)
    return refs[0][:128]


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def db() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH, timeout=60)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=FILE")
    conn.execute("PRAGMA cache_size=-32768")  # ~32 MiB
    conn.execute("PRAGMA mmap_size=0")         # keep RAM predictable
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()


def init_db() -> None:
    ensure_dirs()
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS catalogues (
            id INTEGER PRIMARY KEY,
            path TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            mtime_ns INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            indexed_pages INTEGER NOT NULL DEFAULT 0,
            total_pages INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            error TEXT
        );
        CREATE TABLE IF NOT EXISTS lines (
            id INTEGER PRIMARY KEY,
            catalogue_id INTEGER NOT NULL REFERENCES catalogues(id) ON DELETE CASCADE,
            page INTEGER NOT NULL,
            line_no INTEGER NOT NULL,
            text TEXT NOT NULL,
            norm_text TEXT NOT NULL,
            reference TEXT,
            price REAL
        );
        CREATE INDEX IF NOT EXISTS idx_lines_catalogue ON lines(catalogue_id, page, line_no);
        CREATE INDEX IF NOT EXISTS idx_lines_reference ON lines(reference);
        CREATE VIRTUAL TABLE IF NOT EXISTS lines_fts USING fts5(
            text, norm_text, reference,
            content='lines', content_rowid='id',
            tokenize='unicode61 remove_diacritics 2'
        );
        CREATE TRIGGER IF NOT EXISTS lines_ai AFTER INSERT ON lines BEGIN
            INSERT INTO lines_fts(rowid,text,norm_text,reference)
            VALUES (new.id,new.text,new.norm_text,coalesce(new.reference,''));
        END;
        CREATE TRIGGER IF NOT EXISTS lines_ad AFTER DELETE ON lines BEGIN
            INSERT INTO lines_fts(lines_fts,rowid,text,norm_text,reference)
            VALUES('delete',old.id,old.text,old.norm_text,coalesce(old.reference,''));
        END;
        CREATE TRIGGER IF NOT EXISTS lines_au AFTER UPDATE ON lines BEGIN
            INSERT INTO lines_fts(lines_fts,rowid,text,norm_text,reference)
            VALUES('delete',old.id,old.text,old.norm_text,coalesce(old.reference,''));
            INSERT INTO lines_fts(rowid,text,norm_text,reference)
            VALUES (new.id,new.text,new.norm_text,coalesce(new.reference,''));
        END;
        """)
        cols = {r[1] for r in conn.execute("PRAGMA table_info(catalogues)")}
        if "index_version" not in cols:
            conn.execute("ALTER TABLE catalogues ADD COLUMN index_version INTEGER NOT NULL DEFAULT 0")
        if "ocr_pages" not in cols:
            conn.execute("ALTER TABLE catalogues ADD COLUMN ocr_pages INTEGER NOT NULL DEFAULT 0")
        conn.commit()


def pdf_files(folder: Path) -> list[Path]:
    return sorted((p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf"), key=lambda p: str(p.relative_to(folder)).lower())


def catalogue_signature(path: Path) -> tuple[int, int]:
    s = path.stat()
    return s.st_size, s.st_mtime_ns


def native_extract_page(reader: PdfReader, page_idx: int) -> str:
    try:
        return reader.pages[page_idx].extract_text(extraction_mode="layout") or ""
    except Exception:
        try:
            return reader.pages[page_idx].extract_text() or ""
        except Exception:
            return ""


def ocr_page(path: Path, page_idx: int) -> str:
    """OCR one page only; pixmap/image are released immediately to bound RAM."""
    doc = fitz.open(str(path))
    try:
        page = doc.load_page(page_idx)
        scale = OCR_DPI / 72.0
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        try:
            return pytesseract.image_to_string(img, lang="fra+eng", config="--oem 1 --psm 6") or ""
        finally:
            img.close(); del img, pix, page
    finally:
        doc.close(); gc.collect()


def extract_page(path: Path, reader: PdfReader, page_idx: int) -> tuple[str, bool]:
    text = native_extract_page(reader, page_idx)
    useful = re.sub(r"\W+", "", text, flags=re.UNICODE)
    if len(useful) >= OCR_MIN_CHARS:
        return text, False
    try:
        ocr = ocr_page(path, page_idx)
        if len(re.sub(r"\W+", "", ocr, flags=re.UNICODE)) > len(useful):
            return ocr, True
    except Exception:
        pass
    return text, False


def page_rows_with_context(text: str, cat_id: int, page_no: int):
    lines = [(i, clean_line(x)) for i, x in enumerate(text.splitlines(), 1)]
    lines = [(i, x) for i, x in lines if len(x) >= 2]
    out = []
    for pos, (line_no, line) in enumerate(lines):
        price = detect_price(line)
        if price is None:
            # Supplier layouts often put designation/reference and price on adjacent lines.
            for radius in (1, 2, 3):
                candidates=[]
                for j in (pos+radius, pos-radius):
                    if 0 <= j < len(lines):
                        v=detect_price(lines[j][1])
                        if v is not None: candidates.append(v)
                if candidates:
                    price=candidates[0]; break
        out.append((cat_id, page_no, line_no, line, normalize(line), detect_reference(line), price))
    return out


def index_catalogue(path: Path, progress=None, status=None) -> tuple[int, int]:
    size, mtime = catalogue_signature(path)
    with db() as conn:
        old = conn.execute("SELECT * FROM catalogues WHERE path=?", (str(path),)).fetchone()
        if old and old["size_bytes"] == size and old["mtime_ns"] == mtime and old["status"] == "ready" and old["index_version"] == INDEX_VERSION:
            return old["indexed_pages"], old["total_pages"]

        if old:
            cat_id = old["id"]
            conn.execute("DELETE FROM lines WHERE catalogue_id=?", (cat_id,))
            conn.execute("UPDATE catalogues SET name=?,size_bytes=?,mtime_ns=?,status='indexing',indexed_pages=0,total_pages=0,ocr_pages=0,index_version=?,updated_at=?,error=NULL WHERE id=?",
                         (path.name, size, mtime, INDEX_VERSION, utcnow(), cat_id))
        else:
            cur = conn.execute("INSERT INTO catalogues(path,name,size_bytes,mtime_ns,status,index_version,updated_at) VALUES(?,?,?,?,?,?,?)",
                               (str(path), path.name, size, mtime, "indexing", INDEX_VERSION, utcnow()))
            cat_id = cur.lastrowid
        conn.commit()

    try:
        # strict=False tolerates imperfect supplier PDFs. Reader itself is kept one file at a time.
        reader = PdfReader(str(path), strict=False)
        total = len(reader.pages)
        with db() as conn:
            conn.execute("UPDATE catalogues SET total_pages=?,updated_at=? WHERE id=?", (total, utcnow(), cat_id))
            conn.commit()
            ocr_count = 0
            for page_idx in range(total):
                text, used_ocr = extract_page(path, reader, page_idx)
                if used_ocr:
                    ocr_count += 1
                rows = page_rows_with_context(text, cat_id, page_idx + 1)
                if rows:
                    conn.executemany("INSERT INTO lines(catalogue_id,page,line_no,text,norm_text,reference,price) VALUES(?,?,?,?,?,?,?)", rows)
                conn.execute("UPDATE catalogues SET indexed_pages=?,ocr_pages=?,updated_at=? WHERE id=?", (page_idx + 1, ocr_count, utcnow(), cat_id))
                if (page_idx + 1) % COMMIT_EVERY_PAGES == 0 or page_idx + 1 == total:
                    conn.commit()
                del text, rows
                if page_idx % 5 == 0:
                    gc.collect()
                if progress:
                    progress.progress((page_idx + 1) / max(total, 1), text=f"{path.name} — page {page_idx + 1}/{total}")
        del reader
        gc.collect()
        with db() as conn:
            conn.execute("UPDATE catalogues SET status='ready',updated_at=?,error=NULL WHERE id=?", (utcnow(), cat_id))
            conn.commit()
        return total, total
    except Exception as exc:
        with db() as conn:
            conn.execute("UPDATE catalogues SET status='error',updated_at=?,error=? WHERE id=?", (utcnow(), str(exc)[:2000], cat_id))
            conn.commit()
        if status:
            status.error(f"Échec {path.name}: {exc}")
        raise


def update_index() -> dict[str, int]:
    files = pdf_files(CATALOGUE_DIR)
    seen = {str(p) for p in files}
    stats = {"indexed": 0, "unchanged": 0, "removed": 0, "errors": 0}
    with db() as conn:
        for row in conn.execute("SELECT id,path FROM catalogues").fetchall():
            if row["path"] not in seen:
                conn.execute("DELETE FROM catalogues WHERE id=?", (row["id"],))
                stats["removed"] += 1
        conn.commit()

    outer = st.progress(0, text="Préparation de l'indexation")
    status = st.empty()
    for i, path in enumerate(files):
        size, mtime = catalogue_signature(path)
        with db() as conn:
            old = conn.execute("SELECT size_bytes,mtime_ns,status,index_version FROM catalogues WHERE path=?", (str(path),)).fetchone()
        if old and old["size_bytes"] == size and old["mtime_ns"] == mtime and old["status"] == "ready" and old["index_version"] == INDEX_VERSION:
            stats["unchanged"] += 1
        else:
            status.info(f"Indexation : {path.name}")
            page_progress = st.progress(0, text=path.name)
            try:
                index_catalogue(path, page_progress, status)
                stats["indexed"] += 1
            except Exception:
                stats["errors"] += 1
            page_progress.empty()
        outer.progress((i + 1) / max(len(files), 1), text=f"Catalogues {i + 1}/{len(files)}")
    outer.empty()
    return stats


def fts_query(q: str) -> str:
    tokens = re.findall(r"[\w.-]+", normalize(q), flags=re.UNICODE)
    tokens = [t.replace('"', '') for t in tokens if t]
    return " AND ".join(f'"{t}"*' for t in tokens[:12])


def catalogue_options() -> list[str]:
    with db() as conn:
        return [r[0] for r in conn.execute("SELECT name FROM catalogues WHERE status='ready' ORDER BY name COLLATE NOCASE")]


def search_fts(query: str, catalogue: str | None = None, limit: int = SEARCH_LIMIT) -> pd.DataFrame:
    where_cat = " AND c.name=?" if catalogue else ""
    params: list[object] = []
    if query.strip():
        match = fts_query(query)
        if not match:
            return pd.DataFrame()
        sql = f"""
        SELECT c.name Catalogue,l.page Page,l.line_no Ligne,l.price "Prix détecté",
               l.text "Référence / Libellé exact", round(-bm25(lines_fts),3) "Score & Correspondance"
        FROM lines_fts JOIN lines l ON l.id=lines_fts.rowid JOIN catalogues c ON c.id=l.catalogue_id
        WHERE lines_fts MATCH ? {where_cat}
        ORDER BY bm25(lines_fts) LIMIT ?
        """
        params.append(match)
    else:
        sql = f"""
        SELECT c.name Catalogue,l.page Page,l.line_no Ligne,l.price "Prix détecté",
               l.text "Référence / Libellé exact", 'listing' "Score & Correspondance"
        FROM lines l JOIN catalogues c ON c.id=l.catalogue_id
        WHERE c.status='ready' {where_cat}
        ORDER BY c.name,l.page,l.line_no LIMIT ?
        """
    if catalogue:
        params.append(catalogue)
    params.append(limit)
    with db() as conn:
        return pd.read_sql_query(sql, conn, params=params)


def fuzzy_search(query: str, catalogue: str | None = None, limit: int = FUZZY_RESULT_LIMIT) -> pd.DataFrame:
    qn = normalize(query)
    if not qn:
        return pd.DataFrame()
    # Bound candidate set: prefix/LIKE terms first; only if empty use a capped sequential sample.
    terms = [t for t in re.findall(r"\w+", qn) if len(t) >= 3][:5]
    clauses, params = [], []
    for t in terms:
        clauses.append("l.norm_text LIKE ?")
        params.append(f"%{t[:max(3, len(t)-2)]}%")
    cat_clause = " AND c.name=?" if catalogue else ""
    if catalogue:
        params.append(catalogue)
    where = " OR ".join(clauses) if clauses else "1=1"
    sql = f"""
        SELECT l.id,c.name,l.page,l.line_no,l.price,l.text,l.norm_text
        FROM lines l JOIN catalogues c ON c.id=l.catalogue_id
        WHERE c.status='ready' AND ({where}) {cat_clause}
        LIMIT {FUZZY_CANDIDATE_LIMIT}
    """
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
        if not rows:
            p = [catalogue] if catalogue else []
            rows = conn.execute(f"""SELECT l.id,c.name,l.page,l.line_no,l.price,l.text,l.norm_text
                FROM lines l JOIN catalogues c ON c.id=l.catalogue_id WHERE c.status='ready' {cat_clause}
                ORDER BY l.id DESC LIMIT {FUZZY_CANDIDATE_LIMIT}""", p).fetchall()
    if not rows:
        return pd.DataFrame()
    choices = {r["id"]: r["norm_text"] for r in rows}
    rowmap = {r["id"]: r for r in rows}
    matches = process.extract(qn, choices, scorer=fuzz.token_set_ratio, score_cutoff=MIN_FUZZY_SCORE, limit=limit)
    out = []
    for _, score, row_id in matches:
        r = rowmap[row_id]
        out.append({"Catalogue": r["name"], "Page": r["page"], "Ligne": r["line_no"], "Prix détecté": r["price"],
                    "Référence / Libellé exact": r["text"], "Score & Correspondance": f"fuzzy {score:.0f}%"})
    return pd.DataFrame(out)


def hybrid_search(query: str, catalogue: str | None = None, limit: int = SEARCH_LIMIT) -> pd.DataFrame:
    df = search_fts(query, catalogue, limit)
    # FTS prefix solves artens -> artense. Fuzzy is fallback for actual typos/transpositions.
    if query.strip() and (df.empty or len(df) < 3):
        fuzzy = fuzzy_search(query, catalogue, min(limit, FUZZY_RESULT_LIMIT))
        if not fuzzy.empty:
            if df.empty:
                return fuzzy
            seen = set(df["Référence / Libellé exact"].astype(str))
            fuzzy = fuzzy[~fuzzy["Référence / Libellé exact"].astype(str).isin(seen)]
            return pd.concat([df, fuzzy], ignore_index=True).head(limit)
    return df


def extract_pdf_lines(path: Path) -> list[dict]:
    reader = PdfReader(str(path), strict=False)
    result = []
    for pidx in range(len(reader.pages)):
        text = safe_extract_page(reader, pidx)
        for lno, raw in enumerate(text.splitlines(), 1):
            line = clean_line(raw)
            if len(line) < 3:
                continue
            price = detect_price(line)
            ref = detect_reference(line)
            # Keep probable item lines: reference, price, or sufficiently descriptive text.
            if ref or price is not None or len(line.split()) >= 3:
                result.append({"page": pidx + 1, "line": lno, "text": line, "price": price, "reference": ref})
        del text
        if pidx % 5 == 0:
            gc.collect()
    del reader
    gc.collect()
    return result


def item_query(text: str) -> str:
    n = normalize(text)
    n = PRICE_RE.sub(" ", n)
    words = [w for w in re.findall(r"[\w./-]+", n) if len(w) > 1 and w not in STOPWORDS and not w.isdigit()]
    refs = REF_RE.findall(text)
    if refs:
        return " ".join(refs[:2] + words[:6])
    return " ".join(words[:8])


def best_match(text: str) -> dict | None:
    q = item_query(text)
    if not q:
        return None
    df = hybrid_search(q, limit=10)
    if df.empty:
        return None
    qn = normalize(text)
    best_i, best_score = 0, -1
    for i, row in df.iterrows():
        score = fuzz.token_set_ratio(qn, normalize(str(row["Référence / Libellé exact"])))
        if score > best_score:
            best_i, best_score = i, score
    r = df.loc[best_i].to_dict()
    r["confidence"] = best_score
    return r


def split_email_items(text: str) -> list[dict]:
    chunks = re.split(r"[\n;•]+|(?<=[.!?])\s+", text or "")
    items = []
    for chunk in chunks:
        chunk = clean_line(chunk)
        if len(chunk) < 3:
            continue
        # Split coordinated requests conservatively; preserve dimensions such as 120x60.
        parts = re.split(r"\s*,\s*|\s+et\s+(?=(?:\d+\s+)?[a-zà-ÿ])", chunk, flags=re.I)
        for part in parts:
            part = clean_line(part)
            qmatch = QTY_RE.search(part)
            qty = int(qmatch.group(1)) if qmatch else 1
            cleaned = re.sub(r"^(bonjour|bonsoir|merci)[, ]*", "", part, flags=re.I)
            cleaned = re.sub(r"\b(?:il me faudrait|je voudrais|nous souhaitons|j'ai besoin de|de|du|des)\b", " ", cleaned, flags=re.I)
            cleaned = clean_line(cleaned)
            if len(item_query(cleaned)) >= 2:
                items.append({"Quantité": qty, "Demande détectée": cleaned})
    return items[:200]


def analyze_email(text: str) -> pd.DataFrame:
    out = []
    for item in split_email_items(text):
        match = best_match(item["Demande détectée"])
        row = dict(item)
        if match:
            row.update({"Référence Catalogue": match["Référence / Libellé exact"], "Catalogue": match["Catalogue"],
                        "Page": match["Page"], "Ligne": match["Ligne"], "Prix Officiel": match["Prix détecté"],
                        "Confiance": round(match["confidence"], 1), "Statut": "Identifié" if match["confidence"] >= 80 else "À vérifier"})
        else:
            row.update({"Référence Catalogue": None, "Catalogue": None, "Page": None, "Ligne": None,
                        "Prix Officiel": None, "Confiance": 0, "Statut": "Non trouvé"})
        out.append(row)
    return pd.DataFrame(out)


def analyze_quote(path: Path) -> pd.DataFrame:
    rows = []
    for item in extract_pdf_lines(path):
        match = best_match(item["text"])
        official = match.get("Prix détecté") if match else None
        client = item["price"]
        diff = (client - official) if client is not None and official is not None else None
        confidence = match.get("confidence", 0) if match else 0
        rows.append({
            "Désignation Devis": item["text"], "Prix Client": client,
            "Référence Catalogue identifiée": match.get("Référence / Libellé exact") if match else None,
            "Catalogue Source": match.get("Catalogue") if match else None,
            "Page": match.get("Page") if match else None, "Ligne": match.get("Ligne") if match else None,
            "Prix Officiel": official, "Écart (€)": diff,
            "Statut": "Identifié" if confidence >= 80 else ("À vérifier" if match else "Non trouvé")
        })
    return pd.DataFrame(rows)


def dataframe_xlsx(df: pd.DataFrame, sheet="Résultats") -> bytes:
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet[:31])
        ws = writer.book[sheet[:31]]
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="E5E7EB")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            width = min(max((len(str(c.value or "")) for c in col), default=10) + 2, 60)
            ws.column_dimensions[col[0].column_letter].width = width
    return bio.getvalue()


def checkpoint_db() -> None:
    with db() as conn:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def create_backup() -> Path:
    ensure_dirs(); checkpoint_db()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = BACKUP_DIR / f"catalogue_fts_{stamp}.db"
    src = sqlite3.connect(DB_PATH, timeout=60)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst, pages=1000, sleep=0.05)
        ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok": raise RuntimeError(f"Backup invalide: {ok}")
    finally:
        dst.close(); src.close()
    return target


def restore_backup(source: Path) -> None:
    test = sqlite3.connect(source)
    try:
        ok = test.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok": raise RuntimeError(f"Sauvegarde corrompue: {ok}")
    finally: test.close()
    safety = BACKUP_DIR / f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    if DB_PATH.exists():
        src=sqlite3.connect(DB_PATH); dst=sqlite3.connect(safety)
        try: src.backup(dst)
        finally: dst.close(); src.close()
    for ext in ("-wal", "-shm"):
        Path(str(DB_PATH)+ext).unlink(missing_ok=True)
    shutil.copy2(source, DB_PATH)
    init_db()


def purge_client_docs() -> int:
    n=0
    for p in QUOTE_DIR.rglob("*"):
        if p.is_file(): p.unlink(missing_ok=True); n+=1
    for k in ("quote_path","quote_df"):
        st.session_state.pop(k, None)
    return n


def catalogue_relpath(abs_path: str) -> str:
    try: return str(Path(abs_path).relative_to(CATALOGUE_DIR))
    except Exception: return Path(abs_path).name

def db_size() -> int:
    return sum(p.stat().st_size for p in DATA_DIR.glob("catalogue_fts.db*") if p.is_file())


def human_size(n: int) -> str:
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if n < 1024 or unit == "To":
            return f"{n:.1f} {unit}" if unit != "o" else f"{n} {unit}"
        n /= 1024
    return str(n)


def save_upload(uploaded) -> Path:
    safe = Path(uploaded.name).name
    digest = hashlib.sha256(uploaded.getvalue()).hexdigest()[:12]
    path = QUOTE_DIR / f"{digest}_{safe}"
    if not path.exists():
        path.write_bytes(uploaded.getvalue())
    return path



def add_pdf_links(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty: return df
    # Resolve duplicate filenames deterministically; path remains persisted in DB.
    with db() as conn:
        paths={r["name"]:r["path"] for r in conn.execute("SELECT name,path FROM catalogues")}
    df=df.copy()
    df["PDF / Page"]=[f"?pdf={quote(catalogue_relpath(paths.get(str(n), str(n))))}&page={int(p)}" for n,p in zip(df["Catalogue"],df["Page"])]
    return df
def render_table(df: pd.DataFrame) -> None:
    if df.empty:
        st.info("Aucun résultat.")
    else:
        st.dataframe(df, use_container_width=True, hide_index=True, height=min(700, 80 + 35 * len(df)), column_config={"PDF / Page": st.column_config.LinkColumn("PDF / Page", display_text="Ouvrir")})


ensure_dirs()
init_db()

# Deep-link from result table: safe relative path only.
_pdf_q = st.query_params.get("pdf")
_page_q = st.query_params.get("page")
if _pdf_q:
    candidate=(CATALOGUE_DIR / str(_pdf_q)).resolve()
    root=CATALOGUE_DIR.resolve()
    if candidate.is_file() and root in candidate.parents:
        st.info(f"Document : {candidate.name} — page {_page_q or '?'}")
        with candidate.open("rb") as fh:
            st.download_button("📄 Ouvrir / télécharger le PDF source", fh.read(), file_name=candidate.name, mime="application/pdf")

st.markdown("""
<style>
.stApp, [data-testid="stAppViewContainer"], [data-testid="stSidebar"] {background:#ffffff;color:#111827;}
html, body, [class*="css"] {color:#111827;}
[data-testid="stSidebar"] {border-right:1px solid #e5e7eb;}
div[data-testid="stMetric"], div[data-testid="stDataFrame"], .stTextInput input, .stTextArea textarea,
[data-testid="stFileUploader"] {border-color:#e5e7eb !important; border-radius:4px !important;}
.stButton>button, .stDownloadButton>button {border:1px solid #d1d5db;border-radius:4px;background:#fff;color:#111827;font-weight:600;}
.stButton>button:hover, .stDownloadButton>button:hover {border-color:#111827;color:#111827;}
h1,h2,h3 {color:#111827; letter-spacing:-0.02em;}
hr {border-color:#e5e7eb;}
/* Native Streamlit chrome hidden; application controls stay explicit in sidebar. */
[data-testid="stToolbar"] {opacity:0; transition:opacity .15s;}
[data-testid="stToolbar"]:hover {opacity:1;}
</style>
""", unsafe_allow_html=True)

st.title("Identification documentaire V2.5")
st.caption("Référentiel fournisseur local · SQLite FTS5 + recherche tolérante aux fautes · aucune API externe")

with st.sidebar:
    st.subheader("Référentiel Fournisseur")
    cats = pdf_files(CATALOGUE_DIR)
    c1, c2 = st.columns(2)
    c1.metric("Catalogues", len(cats))
    c2.metric("Index disque", human_size(db_size()))
    st.caption(str(CATALOGUE_DIR))
    if st.button("⚡ Indexer / Mettre à jour le référentiel", type="primary", use_container_width=True):
        stats = update_index()
        st.success(f"Terminé — {stats['indexed']} indexé(s), {stats['unchanged']} inchangé(s), {stats['removed']} supprimé(s), {stats['errors']} erreur(s).")
        st.rerun()

    with st.expander("Maintenance / Sauvegardes"):
        if st.button("💾 Sauvegarder la base", use_container_width=True):
            try:
                b=create_backup(); st.success(f"Backup créé : {b.name}")
            except Exception as e: st.error(f"Backup impossible : {e}")
        backups=sorted(BACKUP_DIR.glob("*.db"), reverse=True)
        choice=st.selectbox("Restaurer", ["—"]+[p.name for p in backups])
        if st.button("♻️ Restaurer la sauvegarde", disabled=choice=="—", use_container_width=True):
            try:
                restore_backup(BACKUP_DIR/choice); st.success("Base restaurée et vérifiée."); st.rerun()
            except Exception as e: st.error(f"Restauration refusée : {e}")

    st.divider()
    st.subheader("Dossier Client & Devis")
    uploaded = st.file_uploader("Déposer un devis PDF", type=["pdf"], accept_multiple_files=False)
    if uploaded:
        st.session_state["quote_path"] = str(save_upload(uploaded))
        st.caption(f"Fichier : {uploaded.name}")
    if st.button("📑 Analyser le devis PDF", use_container_width=True, disabled=not st.session_state.get("quote_path")):
        with st.spinner("Analyse et rapprochement en cours…"):
            st.session_state["quote_df"] = analyze_quote(Path(st.session_state["quote_path"]))
        st.success("Analyse terminée.")
    if st.button("🧹 Purger les documents clients", use_container_width=True):
        n=purge_client_docs(); st.success(f"{n} document(s) client supprimé(s).")

    st.divider()
    st.caption("Identification Documentaire V2.5 · par Asvind")
    st.markdown("[GitHub · As-vind/Indexations](https://github.com/As-vind/Indexations)")

search_tab, email_tab, quote_tab = st.tabs(["🔎 Recherche & Listing", "✉️ Analyse d'E-mail Client (Copier-Coller)", "📑 Rapprochement Devis PDF"])

with search_tab:
    options = ["Tous les catalogues"] + catalogue_options()
    c1, c2 = st.columns([3, 1])
    query = c1.text_input("Recherche", placeholder="artens, table basse 120x60, référence partielle…")
    selected = c2.selectbox("Catalogue", options)
    cat = None if selected == "Tous les catalogues" else selected
    if st.button("Rechercher", key="search_btn", type="primary"):
        if not query.strip() and not cat:
            st.warning("Saisissez un terme ou sélectionnez un catalogue pour un listing global.")
        else:
            with st.spinner("Recherche…"):
                st.session_state["search_df"] = add_pdf_links(hybrid_search(query, cat))
    if "search_df" in st.session_state:
        df = st.session_state["search_df"]
        st.caption(f"{len(df)} ligne(s) affichée(s), maximum {SEARCH_LIMIT} par recherche.")
        render_table(df)

with email_tab:
    email_text = st.text_area("Corps de l'e-mail / demande client", height=220,
                              placeholder="Bonjour, il me faudrait 4 chaises empilables noires, 2 tables artense en 140 et du joint étanche 50mm")
    if st.button("🧩 Extraire et identifier les références du message", type="primary"):
        if not email_text.strip():
            st.warning("Collez d'abord le message client.")
        else:
            with st.spinner("Extraction et résolution…"):
                st.session_state["email_df"] = analyze_email(email_text)
    if "email_df" in st.session_state:
        df = st.session_state["email_df"]
        render_table(df)
        if not df.empty:
            c1, c2 = st.columns(2)
            c1.download_button("Exporter CSV", df.to_csv(index=False).encode("utf-8-sig"), "analyse_email.csv", "text/csv", use_container_width=True)
            c2.download_button("Exporter Excel", dataframe_xlsx(df, "Analyse email"), "analyse_email.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)

with quote_tab:
    df = st.session_state.get("quote_df")
    if df is None:
        st.info("Déposez un devis PDF dans la barre latérale puis lancez son analyse.")
    else:
        render_table(df)
        if not df.empty:
            c1, c2 = st.columns(2)
            c1.download_button("Exporter CSV", df.to_csv(index=False).encode("utf-8-sig"), "rapprochement_devis.csv", "text/csv", use_container_width=True)
            c2.download_button("Exporter Excel", dataframe_xlsx(df, "Rapprochement"), "rapprochement_devis.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
